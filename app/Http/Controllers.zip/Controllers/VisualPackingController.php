<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\BatchNumber;
use App\Models\EmployeeBioData;
use App\Models\Location;
use App\Models\ShiftEntry;
use App\Models\VisualPacking;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use PDF;

class VisualPackingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');

        $this->middleware('permission:visual_packing-list|visual_packing-create|visual_packing-edit|visual_packing-delete', ['only' => ['index', 'store']]);
        $this->middleware('permission:visual_packing-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:visual_packing-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:visual_packing-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        $batch_no = isset($_GET['batch_no']) ? $_GET['batch_no'] : '';
        $location = isset($_GET['location']) ? $_GET['location'] : '';
        $shift = isset($_GET['shift']) ? $_GET['shift'] : '';
        $part_name = isset($_GET['part_name']) ? $_GET['part_name'] : '';
        $customer = isset($_GET['customer']) ? $_GET['customer'] : '';
        $packed_qty = isset($_GET['packed_qty']) ? $_GET['packed_qty'] : '';
        $box_qty = isset($_GET['box_qty']) ? $_GET['box_qty'] : '';
        $visual_inspected_qty = isset($_GET['visual_inspected_qty']) ? $_GET['visual_inspected_qty'] : '';
        $total_rejection = isset($_GET['total_rejection']) ? $_GET['total_rejection'] : '';
        $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
        $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
        $visual_packing = VisualPacking::orderBy('id', 'desc');

        if (!empty($batch_no)) {
            $visual_packing->where('batch_no', 'like', '%' . $batch_no . '%');
        }
        if (!empty($location)) {
            $visual_packing->where('location', 'like', '%' . $location . '%');
        }
        if (!empty($shift)) {
            $visual_packing->where('shift', 'like', '%' . $shift . '%');
        }
        if (!empty($part_name)) {
            $visual_packing->where('part_name', 'like', '%' . $part_name . '%');
        }
        if (!empty($customer)) {
            $visual_packing->where('customer', 'like', '%' . $customer . '%');
        }
        if (!empty($packed_qty)) {
            $visual_packing->where('packed_qty', 'like', '%' . $packed_qty . '%');
        }
        if (!empty($box_qty)) {
            $visual_packing->where('box_qty', 'like', '%' . $box_qty . '%');
        }
        if (!empty($visual_inspected_qty)) {
            $visual_packing->where('visual_inspected_qty', 'like', '%' . $visual_inspected_qty . '%');
        }
        if (!empty($total_rejection)) {
            $visual_packing->where('total_rejection', 'like', '%' . $total_rejection . '%');
        }
        if (!empty($start_date && $end_date)) {
            $visual_packing->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
        }
        $data['batch_no'] = $batch_no;
        $data['location'] = $location;
        $data['shift'] = $shift;
        $data['part_name'] = $part_name;
        $data['customer'] = $customer;
        $data['packed_qty'] = $packed_qty;
        $data['box_qty'] = $box_qty;
        $data['visual_inspected_qty'] = $visual_inspected_qty;
        $data['total_rejection'] = $total_rejection;
        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $visual_packing = $visual_packing->paginate(10);
        if ($request->pdf == 'pdf') {
            $data = VisualPacking::select("*")
                ->where('batch_no', 'like', '%' . $batch_no . '%')
                ->where('location', 'like', '%' . $location . '%')
                ->where('shift', 'like', '%' . $shift . '%')
                ->where('part_name', 'like', '%' . $part_name . '%')
                ->where('customer', 'like', '%' . $customer . '%')
                ->where('packed_qty', 'like', '%' . $packed_qty . '%')
                ->where('box_qty', 'like', '%' . $box_qty . '%')
                ->where('visual_inspected_qty', 'like', '%' . $visual_inspected_qty . '%')
                ->where('total_rejection', 'like', '%' . $total_rejection . '%')
                ->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))])
                ->get();
            $return_data = [
                'title' => 'Ravi Technoforge Pvt Ltd',
                'date' => date('m/d/Y'),
                'data' => $data,
            ];

            $pdf = PDF::loadView('visual_packing.daily_report', $return_data);

            return $pdf->download('visual & packing report.pdf');
        }
        $incharge = EmployeeBioData::where('Oemcname', 'LIKE', '%VISUAL%')->get();
        $shift = ShiftEntry::all();
        $location = Location::all();
        return view('visual_packing.index', compact('visual_packing', 'data', 'shift', 'location','incharge'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        $batch_number = BatchNumber::all();
        $incharge = EmployeeBioData::where('Oemcname', 'LIKE', '%VISUAL%')->get();
        $shift = ShiftEntry::all();
        $location = Location::all();
        return view('visual_packing.create', compact('incharge', 'batch_number', 'shift', 'location'));
    }
    public function store(Request $request)
    {
        // dd($request);
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));
        VisualPacking::create($input);

        return redirect()->route('visual_packing.index')->with('success', 'Data Saved Successfully');
    }
    public function edit($id)
    {
        $visual_packing = VisualPacking::with('batch_number')->where('id', $id)->first();
        $incharge = EmployeeBioData::where('Oemcname', 'LIKE', '%VISUAL%')->get();
        $batch_number = BatchNumber::all();
        $shift = ShiftEntry::all();
        $location = Location::all();
        return view('visual_packing.edit', compact('visual_packing', 'incharge', 'batch_number', 'shift', 'location'));
    }
    public function update(Request $request, $id)
    {
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));
        $visual_packing = VisualPacking::find($id);
        $visual_packing->update($input);
        return redirect()->route('visual_packing.index')->with('success', 'Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = VisualPacking::find($id);
        $data->delete();
        return redirect()->route('visual_packing.index')->with('success', 'Data Deleted Successfully');
    }
    public function daily_visual_and_pack_report()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))
            ->get();
        // dd($data);
        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('visual_packing.daily_report', $return_data);

        return $pdf->download('daily visual & packing report.pdf');
    }
    public function daily_visual_and_pack_report_view()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))
            ->get();
        // dd($data);
        return view('visual_packing.daily_visual_and_pack_report_view', compact('data'));
    }
    public function daily_packing_unit1_report()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT1')
            ->get();
        // dd($data);
        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'sub_title' => 'Daily Packing Report - Pipaliya Unit-Maldebhai',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('visual_packing.daily_packing_unit1_report', $return_data);

        return $pdf->download('daily unitwise packing report- pipaliya unit-maldebhai vala.pdf');
    }

    public function daily_packing_unit2_report()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT2')
            ->get();

        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'sub_title' => 'Daily Packing Report - Pipaliya Unit- Maheshbhai',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('visual_packing.daily_packing_unit1_report', $return_data);

        return $pdf->download('daily unitwise packing report-pipaliya unit -maheshbhai.pdf');
    }
    public function daily_packing_unit3_report()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT3')
            ->get();

        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'sub_title' => 'Daily Packing Report - PipaliyaUnit Manu N Jadav',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('visual_packing.daily_packing_unit1_report', $return_data);

        return $pdf->download('daily unitwise packing report-pipaliya unit-manu n. jadav.pdf');
    }
    public function daily_packing_unit4_report()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT4')
            ->get();

        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'sub_title' => 'Daily Packing Report - Pipaliya Unit K.K. Eng. Works',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('visual_packing.daily_packing_unit1_report', $return_data);

        return $pdf->download('daily unitwise packing report-pipaliya unit -k.k. eng. works.pdf');
    }
    public function daily_packing_unit5_report()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT5')
            ->get();

        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'sub_title' => 'Daily Packing Report - Shapar Kushal Eng. Work-Unit-04',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('visual_packing.daily_packing_unit1_report', $return_data);

        return $pdf->download('daily unitwise packing report-charbhuja unit shapar-04-kushal e.w.pdf');
    }
    public function daily_packing_unit6_report()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT6')
            ->get();

        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'sub_title' => 'Daily Packing Report - Shapar Singh Eng. Works Unit-04',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('visual_packing.daily_packing_unit1_report', $return_data);

        return $pdf->download('daily unitwise packing report-charbhuja unit shapar-04-singh eng. works.pdf');
    }
    public function daily_packing_unit7_report()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT7')
            ->get();

        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'sub_title' => 'Daily Packing Report - Pipaliya Kinjal Eng. Works',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('visual_packing.daily_packing_unit1_report', $return_data);

        return $pdf->download('daily unitwise packing report-piapaliya unit-kinjal eng. works.pdf');
    }
    public function daily_packing_unit1_report_view()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT1')
            ->get();
        // dd($data);
        $return_data = [
            'route_data' => route('visual_packing.daily_packing_unit1_report'),
            'data' => $data,
        ];
        return view('visual_packing.daily_packing_unit1_report_view', $return_data);
    }
    public function daily_packing_unit2_report_view()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT2')
            ->get();
        // dd($data);
        $return_data = [
            'route_data' => route('visual_packing.daily_packing_unit2_report'),
            'data' => $data,
        ];
        return view('visual_packing.daily_packing_unit1_report_view', $return_data);
    }
    public function daily_packing_unit3_report_view()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT3')
            ->get();
        // dd($data);
        $return_data = [
            'route_data' => route('visual_packing.daily_packing_unit3_report'),
            'data' => $data,
        ];
        return view('visual_packing.daily_packing_unit1_report_view', $return_data);
    }
    public function daily_packing_unit4_report_view()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT4')
            ->get();
        // dd($data);
        $return_data = [
            'route_data' => route('visual_packing.daily_packing_unit4_report'),
            'data' => $data,
        ];
        return view('visual_packing.daily_packing_unit1_report_view', $return_data);
    }
    public function daily_packing_unit5_report_view()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT5')
            ->get();
        // dd($data);
        $return_data = [
            'route_data' => route('visual_packing.daily_packing_unit5_report'),
            'data' => $data,
        ];
        return view('visual_packing.daily_packing_unit1_report_view', $return_data);
    }
    public function daily_packing_unit6_report_view()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT6')
            ->get();
        // dd($data);
        $return_data = [
            'route_data' => route('visual_packing.daily_packing_unit6_report'),
            'data' => $data,
        ];
        return view('visual_packing.daily_packing_unit1_report_view', $return_data);
    }
    public function daily_packing_unit7_report_view()
    {
        $data = VisualPacking::where('date', Carbon::today()->format('m/d/Y'))->where('location', 'UNIT7')
            ->get();
        // dd($data);
        $return_data = [
            'route_data' => route('visual_packing.daily_packing_unit7_report'),
            'data' => $data,
        ];
        return view('visual_packing.daily_packing_unit1_report_view', $return_data);
    }
}
