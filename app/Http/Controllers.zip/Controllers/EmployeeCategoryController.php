<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\EmployeeCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class EmployeeCategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
       
         $this->middleware('permission:employee_category-list|employee_category-create|employee_category-edit|employee_category-delete', ['only' => ['index','store']]);
         $this->middleware('permission:employee_category-create', ['only' => ['create','store']]);
         $this->middleware('permission:employee_category-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:employee_category-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $employee_category=EmployeeCategory::orderBy('id','desc')->paginate(10);
        return view('employee_category.index',compact('employee_category'))
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        return view('employee_category.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'employee_category' => 'required|unique:employee_categories',
        ]);
        $input = $request->all();

        EmployeeCategory::create($input);

        return redirect()->route('employee_category.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $employee_category=EmployeeCategory::find($id);
        return view('employee_category.edit',compact('employee_category'));
    }
    public function update(Request $request,$id)
    {
        $request->validate([
            'employee_category' => 'required',
        ]);
        
        $input = $request->all();
       
        $employee_category = EmployeeCategory::find($id);
        $employee_category->update($input);
        return redirect()->route('employee_category.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = EmployeeCategory::find($id);
        $data->delete();
        return redirect()->route('employee_category.index')->with('success','Data Deleted Successfully');
    }

}
