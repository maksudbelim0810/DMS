<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\InsertConsumptionEntry;
use App\Models\BatchNumber;
use App\Models\InsertEntry;
use App\Models\MachineEntry;
use App\Models\MachineOperation;
use App\Models\PartTypeCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class InsertConsumptionEntryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');

        $this->middleware('permission:insert_consumption_entry-list|insert_consumption_entry-create|insert_consumption_entry-edit|insert_consumption_entry-delete', ['only' => ['index', 'store']]);
        $this->middleware('permission:insert_consumption_entry-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:insert_consumption_entry-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:insert_consumption_entry-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        $batch_no = isset($_GET['batch_no']) ? $_GET['batch_no'] : '';
        $part_name = isset($_GET['part_name']) ? $_GET['part_name'] : '';
        $customer_name = isset($_GET['customer_name']) ? $_GET['customer_name'] : '';
        $mc_no = isset($_GET['mc_no']) ? $_GET['mc_no'] : '';
        $insert_name = isset($_GET['insert_name']) ? $_GET['insert_name'] : '';
        $insert_rate_rs = isset($_GET['insert_rate_rs']) ? $_GET['insert_rate_rs'] : '';
        $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
        $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
        $insert_consumption_entry = InsertConsumptionEntry::orderBy('id', 'desc');
        if (!empty($batch_no)) {
            $insert_consumption_entry->where('batch_no', 'like', '%' . $batch_no . '%');
        }
        if (!empty($part_name)) {

            $insert_consumption_entry->where('part_name', 'like', '%' . $part_name . '%');
        }
        if (!empty($customer_name)) {
            $insert_consumption_entry->where('customer_name', 'like', '%' . $customer_name . '%');
        }
        if (!empty($mc_no)) {
            $insert_consumption_entry->where('mc_no', 'like', '%' . $mc_no . '%');
        }
        if (!empty($insert_name)) {
            $insert_consumption_entry->where('insert_name', 'like', '%' . $insert_name . '%');
        }
        if (!empty($insert_rate_rs)) {
            $insert_consumption_entry->where('insert_rate_rs', 'like', '%' . $insert_rate_rs . '%');
        }
        if (!empty($start_date && $end_date)) {
            $insert_consumption_entry->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
        }
        $data['batch_no'] = $batch_no;
        $data['part_name'] = $part_name;
        $data['customer_name'] = $customer_name;
        $data['mc_no'] = $mc_no;
        $data['insert_name'] = $insert_name;
        $data['insert_rate_rs'] = $insert_rate_rs;
        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $insert_consumption_entry = $insert_consumption_entry->paginate(10);
        if ($request->pdf == 'pdf') {
            $data = InsertConsumptionEntry::select("*")
                ->where('batch_no', 'like', '%' . $batch_no . '%')
                ->where('part_name', 'like', '%' . $part_name . '%')
                ->where('customer_name', 'like', '%' . $customer_name . '%')
                ->where('mc_no', 'like', '%' . $mc_no . '%')
                ->where('insert_name', 'like', '%' . $insert_name . '%')
                ->where('insert_rate_rs', 'like', '%' . $insert_rate_rs . '%')
                ->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))])
                ->get();
            $return_data = [
                'title' => 'Ravi Technoforge Pvt Ltd',
                'date' => date('m/d/Y'),
                'data' => $data,
            ];

            $pdf = PDF::loadView('cnc_production.daily_report', $return_data);

            return $pdf->download('CNC_daily_report.pdf');
        }
        $mc_no =MachineEntry::where('machine_department', 'like', '%Machining%')->orWhere('machine_department', 'like', '%CNC%')->get();
        return view('insert_consumption_entry.index', compact('insert_consumption_entry', 'data','mc_no'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        $batch_number = BatchNumber::all();
        $insert_short = InsertEntry::all();
        $mc_no = MachineEntry::where('machine_department', 'like', '%Machining%')->orWhere('machine_department', 'like', '%CNC%')->get();
        $opration_name = MachineOperation::all();
        $part_type_category = PartTypeCategory::all();
        return view('insert_consumption_entry.create', compact('batch_number', 'insert_short', 'mc_no', 'opration_name', 'part_type_category'));
    }
    public function store(Request $request)
    {
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));
        InsertConsumptionEntry::create($input);

        return redirect()->route('insert_consumption_entry.index')->with('success', 'Data Saved Successfully');
    }
    public function edit($id)
    {
        $insert_consumption_entry = InsertConsumptionEntry::with('batch_number')->where('id', $id)->first();
        $insert_short = InsertEntry::all();
        $batch_number = BatchNumber::all();
        $mc_no = MachineEntry::where('machine_department', 'like', '%Machining%')->orWhere('machine_department', 'like', '%CNC%')->get();
        $opration_name = MachineOperation::all();
        $part_type_category = PartTypeCategory::all();
        return view('insert_consumption_entry.edit', compact('insert_consumption_entry', 'batch_number', 'insert_short', 'mc_no', 'opration_name', 'part_type_category'));
    }
    public function update(Request $request, $id)
    {
        $input = $request->all();

        $insert_consumption_entry = InsertConsumptionEntry::find($id);
        $insert_consumption_entry->update($input);
        return redirect()->route('insert_consumption_entry.index')->with('success', 'Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = InsertConsumptionEntry::find($id);
        $data->delete();
        return redirect()->route('insert_consumption_entry.index')->with('success', 'Data Deleted Successfully');
    }
}
