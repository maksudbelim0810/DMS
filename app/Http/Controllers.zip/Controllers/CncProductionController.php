<?php

namespace App\Http\Controllers;

use App\Exports\CncProductionsExport;
use App\Http\Controllers\Controller;
use App\Models\CncProduction;
use App\Models\BreakDownCategory;
use App\Models\Setup;
use Illuminate\Http\Request;
use App\Models\MachineEntry;
use App\Models\BatchNumber;
use App\Models\EmployeeBioData;
use App\Models\ShiftEntry;
use Carbon\Carbon;
use PDF;
use Maatwebsite\Excel\Facades\Excel;

class CncProductionController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');

        $this->middleware('permission:cnc_production-list|cnc_production-create|cnc_production-edit|cnc_production-delete', ['only' => ['index', 'store']]);
        $this->middleware('permission:cnc_production-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:cnc_production-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:cnc_production-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        // dd($request);
        $batch_no = isset($_GET['batch_no']) ? $_GET['batch_no'] : '';
        $mc_no = isset($_GET['mc_no']) ? $_GET['mc_no'] : '';
        $shift = isset($_GET['shift']) ? $_GET['shift'] : '';
        $setup = isset($_GET['setup']) ? $_GET['setup'] : '';
        $part_name = isset($_GET['part_name']) ? $_GET['part_name'] : '';
        $customer = isset($_GET['customer']) ? $_GET['customer'] : '';
        $cycle_time = isset($_GET['cycle_time']) ? $_GET['cycle_time'] : '';
        $total_rejection = isset($_GET['total_rejection']) ? $_GET['total_rejection'] : '';
        $no_opration = isset($_GET['no_opration']) ? $_GET['no_opration'] : '';
        $no_power = isset($_GET['no_power']) ? $_GET['no_power'] : '';
        $job_setting = isset($_GET['job_setting']) ? $_GET['job_setting'] : '';
        $job_fault = isset($_GET['job_fault']) ? $_GET['job_fault'] : '';
        $no_load = isset($_GET['no_load']) ? $_GET['no_load'] : '';
        $operator_name = isset($_GET['operator_name']) ? $_GET['operator_name'] : '';
        $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
        $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
        $cnc_production = CncProduction::orderBy('id', 'desc');
        if (!empty($batch_no)) {
            $cnc_production->where('batch_no', 'like', '%' . $batch_no . '%');
        }
        if (!empty($mc_no)) {
            $cnc_production->where('mc_no', 'like', '%' . $mc_no . '%');
        }
        if (!empty($shift)) {
            $cnc_production->where('shift', 'like', '%' . $shift . '%');
        }
        if (!empty($setup)) {
            $cnc_production->where('setup', 'like', '%' . $setup . '%');
        }
        if (!empty($part_name)) {
            $cnc_production->where('part_name', 'like', '%' . $part_name . '%');
        }
        if (!empty($customer)) {
            $cnc_production->where('customer', 'like', '%' . $customer . '%');
        }
        if (!empty($cycle_time)) {
            $cnc_production->where('cycle_time', 'like', '%' . $cycle_time . '%');
        }
        if (!empty($total_rejection)) {
            $cnc_production->where('total_rejection', 'like', '%' . $total_rejection . '%');
        }
        if (!empty($no_opration)) {
            $cnc_production->where('no_opration', 'like', '%' . $no_opration . '%');
        }
        if (!empty($no_power)) {
            $cnc_production->where('no_power', 'like', '%' . $no_power . '%');
        }
        if (!empty($job_setting)) {
            $cnc_production->where('job_setting', 'like', '%' . $job_setting . '%');
        }
        if (!empty($job_fault)) {
            $cnc_production->where('job_fault', 'like', '%' . $job_fault . '%');
        }
        if (!empty($no_load)) {
            $cnc_production->where('no_load', 'like', '%' . $no_load . '%');
        }
        if (!empty($operator_name)) {
            $cnc_production->where('operator_name', 'like', '%' . $operator_name . '%');
        }
        if (!empty($start_date && $end_date ) ) {
            $cnc_production->whereBetween('date',[date('m/d/Y',strtotime($start_date)), date('m/d/Y',strtotime($end_date))]);
        }
        $data['batch_no'] = $batch_no;
        $data['mc_no'] = $mc_no;
        $data['shift'] = $shift;
        $data['setup'] = $setup;
        $data['part_name'] = $part_name;
        $data['customer'] = $customer;
        $data['cycle_time'] = $cycle_time;
        $data['total_rejection'] = $total_rejection;
        $data['no_opration'] = $no_opration;
        $data['no_power'] = $no_power;
        $data['job_setting'] = $job_setting;
        $data['job_fault'] = $job_fault;
        $data['no_load'] = $no_load;
        $data['operator_name'] = $operator_name;
        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $cnc_production = $cnc_production->paginate(10);
        // dd($request->pdf);
        if ($request->pdf =='pdf') {
            $data = CncProduction::select("*")
            ->where('batch_no', 'like', '%' . $batch_no . '%')
            ->where('mc_no', 'like', '%' . $mc_no . '%')
            ->where('shift', 'like', '%' . $shift . '%')
            ->where('setup', 'like', '%' . $setup . '%')
            ->where('customer', 'like', '%' . $customer . '%')
            ->where('cycle_time', 'like', '%' . $cycle_time . '%')
            ->where('total_rejection', 'like', '%' . $total_rejection . '%')
            ->where('no_opration', 'like', '%' . $no_opration . '%')
            ->where('no_power', 'like', '%' . $no_power . '%')
            ->where('job_setting', 'like', '%' . $job_setting . '%')
            ->where('job_fault', 'like', '%' . $job_fault . '%')
            ->where('no_load', 'like', '%' . $no_load . '%')
            ->where('operator_name', 'like', '%' . $operator_name . '%')
            ->where('part_name', 'like', '%' . $part_name . '%')
            ->whereBetween('date',[date('m/d/Y',strtotime($start_date)), date('m/d/Y',strtotime($end_date))])
            ->get();
            $return_data = [
                'title' => 'Ravi Technoforge Pvt Ltd',
                'date' => date('m/d/Y'),
                'data' => $data,
            ];

            $pdf = PDF::loadView('cnc_production.daily_report', $return_data);

            return $pdf->download('CNC_daily_report.pdf');
        }
        $mc_no = MachineEntry::where('machine_department', 'like', '%Machining%')->orWhere('machine_department', 'like', '%CNC%')->get();
        $shift = ShiftEntry::all();
        
        $setup = Setup::all();
        $operator_name = EmployeeBioData::where('Oemcname', 'CNC OPERATOR')->get();
        return view('cnc_production.index', compact('cnc_production', 'data','mc_no', 'shift','setup', 'operator_name'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        $batch_number = BatchNumber::all();
        $mc_no = MachineEntry::where('machine_department', 'like', '%Machining%')->orWhere('machine_department', 'like', '%CNC%')->get();
        $shift = ShiftEntry::all();
        $bd_category = BreakDownCategory::all();
        $setup = Setup::all();
        $operator_name = EmployeeBioData::where('Oemcname', 'CNC OPERATOR')->get();
        return view('cnc_production.create', compact('mc_no', 'shift', 'batch_number', 'bd_category', 'setup', 'operator_name'));
    }
    public function export() 
    {
        // dd(new CncProductionsExport);
        return Excel::download(new CncProductionsExport(), 'CncProduction.xlsx');
    }
    public function store(Request $request)
    {
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));
        CncProduction::create($input);

        return redirect()->route('cnc_production.index')->with('success', 'Data Saved Successfully');
    }
    public function edit($id)
    {
        $cnc_production = CncProduction::with('batch_number')->where('id', $id)->first();
        // dd($cnc_production);
        $date = date('d/m/Y', strtotime($cnc_production->date));
        $batch_number = BatchNumber::all();
        $mc_no = MachineEntry::where('machine_department', 'like', '%Machining%')->orWhere('machine_department', 'like', '%CNC%')->get();
        $shift = ShiftEntry::all();
        $bd_category = BreakDownCategory::all();
        $setup = Setup::all();
        $operator_name = EmployeeBioData::where('Oemcname', 'CNC OPERATOR')->get();
        $operator_check = EmployeeBioData::where('full_name',$cnc_production->operator_name)->count();

        return view('cnc_production.edit', compact('cnc_production', 'mc_no', 'date', 'shift', 'batch_number', 'bd_category', 'setup', 'operator_name','operator_check'));
    }
    public function update(Request $request, $id)
    {
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));
        $cnc_production = CncProduction::find($id);
        $cnc_production->update($input);
        return redirect()->route('cnc_production.index')->with('success', 'Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = CncProduction::find($id);
        $data->delete();
        return redirect()->route('cnc_production.index')->with('success', 'Data Deleted Successfully');
    }
    public function daily_cnc_report(Request $request)
    {
        dd($request()->has('batch_no'));
        $data = CncProduction::select("*")
            ->where('date', Carbon::today()->format('m/d/Y'))
            ->get();
        // dd($data);
        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('cnc_production.daily_report', $return_data);

        return $pdf->download('CNC_daily_report.pdf');
    }
    public function daily_cnc_report_view()
    {
        $data = CncProduction::select("*")
            ->where('date', Carbon::today()->format('m/d/Y'))
            ->get();

        return view('cnc_production.daily_cnc_report_view', compact('data'));
    }
}
