<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\View\View;
use App\Models\BatchNumber;
use App\Models\CncProduction;
use App\Models\Customer;
use App\Models\PartEntry;
use App\Models\PartCategory;
use App\Models\PartTypeCategory;
use App\Rules\UniqueBatchNumber;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use PDF;

class BatchNumberController extends Controller
{

    function __construct()
    {
        $this->middleware('permission:batch_number-list|batch_number-create|batch_number-edit|batch_number-delete', ['only' => ['index', 'store']]);
        $this->middleware('permission:batch_number-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:batch_number-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:batch_number-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request): View
    {
        $batch_no = isset($_GET['batch_no']) ? $_GET['batch_no'] : '';
        $batch_data=BatchNumber::orderBy('id','desc');
        if(!empty($batch_no)){
            $batch_data->where('batch_name','like','%'.$batch_no.'%');
        } 
        $data['batch_name']=$batch_no;
        $batch_data=$batch_data->paginate(10);
        $data = BatchNumber::orderBy('id','desc')->paginate(10);

        return view('batch_numbers.index', compact('data','batch_data'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $part_category=PartEntry::all();
        return view('batch_numbers.create', compact('part_category'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'batch_name' => ['required', new UniqueBatchNumber],
        ]);
        //  $request->validate([
        //     'batch_name' => 'required|min:1|max:5|unique:batch_numbers',
        // ]);
        try {

            $BatchNumber = new BatchNumber;
            $BatchNumber->batch_name = $request->batch_name;
            $BatchNumber->part_name = $request->part_name;
            $BatchNumber->customer_name = $request->customer_name;
            $BatchNumber->part_type_category = $request->part_type_category;
            $BatchNumber->batch_start_date = date('Y-m-d', strtotime($request->batch_start_date));
            $BatchNumber->batch_comp_date = date('Y-m-d', strtotime($request->batch_comp_date));
            $BatchNumber->batch_qty = $request->batch_qty;
            $BatchNumber->save();

            return redirect()->route('batch_number.index')
                ->with('success', 'Data Saved Successfully');
        } catch (\Exception $e) {
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id): View
    {
        $BatchNumber = BatchNumber::find($id);
        $part_category=PartEntry::all();
        return view('batch_numbers.edit', compact('BatchNumber','part_category'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // $request->validate([
        //     'batch_name' => ['required', new UniqueBatchNumber],
        // ]);
        try {

            $BatchNumber = BatchNumber::find($id);
            $BatchNumber->batch_name = $request->batch_name;
            $BatchNumber->part_name = $request->part_name;
            $BatchNumber->customer_name = $request->customer_name;
            $BatchNumber->part_type_category = $request->part_type_category;
            $BatchNumber->batch_start_date = date('Y-m-d', strtotime($request->batch_start_date));
            $BatchNumber->batch_comp_date = date('Y-m-d', strtotime($request->batch_comp_date));
            $BatchNumber->batch_qty = $request->batch_qty;
            $BatchNumber->save();

            return redirect()->route('batch_number.index')
                ->with('success', 'Data Saved Successfully');
        } catch (\Exception $e) {
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id): RedirectResponse
    {
        try {

            BatchNumber::find($id)->delete();
            return redirect()->route('batch_number.index')
                ->with('success', 'Data Deleted Successfully');
        } catch (\Exception $e) {
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
    public function generatePDF()
    {
        $users = BatchNumber::select('id', 'batch_start_date')
            ->get()
            ->groupBy(function ($date) {
                //return Carbon::parse($date->created_at)->format('Y'); // grouping by years
                return Carbon::parse($date->batch_start_date)->format('m'); // grouping by months
            });

        $usermcount = [];
        $userArr = [];

        foreach ($users as $key => $value) {
            $usermcount[(int)$key] = count($value);
        }
        $data_array=[];
        for ($i = 1; $i <= 1; $i++) {
            if (!empty($usermcount[$i])) {
                $date=date('m/Y', strtotime($i . '/' . date('y')));
                $userArr['month_year'] = date('M y', strtotime($i . '/' . date('y')));

                $userArr['data'] = BatchNumber::whereRaw("DATE_FORMAT(STR_TO_DATE(batch_start_date, '%m/%d/%Y'), '%m/%Y') ='".$date."'")
                    ->get();
                    
            } else {
                $userArr[$i] = 0;
                $date=date('m/Y', strtotime($i . '/' . date('y')));
                $userArr['month_year'] = date('M y', strtotime($i . '/' . date('y')));
                $userArr['data'] = BatchNumber::whereRaw("DATE_FORMAT(STR_TO_DATE(batch_start_date, '%m/%d/%Y'), '%m/%Y') ='".$date."'")
                    ->get();
                    
            }
            // dd($userArr);
            array_push($data_array,$userArr);
        }
        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'date' => date('m/d/Y'),
            'data' => $data_array,
        ];

        $pdf = PDF::loadView('batch_numbers.myPDF', $return_data);

        return $pdf->download('batchnumber.pdf');
    }
    public function generatePDF_view()
    {
        $users = BatchNumber::select('id', 'batch_start_date')
            ->get()
            ->groupBy(function ($date) {
                //return Carbon::parse($date->created_at)->format('Y'); // grouping by years
                return Carbon::parse($date->batch_start_date)->format('m'); // grouping by months
            });

        $usermcount = [];
        $userArr = [];

        foreach ($users as $key => $value) {
            $usermcount[(int)$key] = count($value);
        }
        $data_array=[];
        for ($i = 1; $i <= 1; $i++) {
            if (!empty($usermcount[$i])) {
                $date=date('m/Y', strtotime($i . '/' . date('y')));
                $userArr['month_year'] = date('M y', strtotime($i . '/' . date('y')));

                $userArr['data'] = BatchNumber::whereRaw("DATE_FORMAT(STR_TO_DATE(batch_start_date, '%m/%d/%Y'), '%m/%Y') ='".$date."'")
                    ->get();
                    
            } else {
                $userArr[$i] = 0;
                $date=date('m/Y', strtotime($i . '/' . date('y')));
                $userArr['month_year'] = date('M y', strtotime($i . '/' . date('y')));
                $userArr['data'] = BatchNumber::whereRaw("DATE_FORMAT(STR_TO_DATE(batch_start_date, '%m/%d/%Y'), '%m/%Y') ='".$date."'")
                    ->get();
                    
            }
            // dd($userArr);
            array_push($data_array,$userArr);
        }
        return view('batch_numbers.generatePDF_view',compact('data_array'));
    }
    public function batchwise_cnc_prod_report()
    {
        $users = CncProduction::select('id', 'batch_no')
            ->first();
            // ->groupBy(function ($date) {
            //     //return Carbon::parse($date->created_at)->format('Y'); // grouping by years
            //     return Carbon::parse($date->date)->format('m'); // grouping by months
            // });
            // dd($users);
        $usermcount = [];
        $userArr = [];

        // foreach ($users as $key => $value) {
        //     $usermcount[(int)$key] = count($value);
        // }
        $data_array=[];
        for ($i = 1; $i <= 1; $i++) {
            if (!empty($usermcount[$i])) {
                // $date=date('m/Y', strtotime($i . '/' . date('y')));
                $userArr['month_year'] = date('M y', strtotime($i . '/' . date('y')));

                $userArr['data'] = CncProduction::whereRaw("DATE_FORMAT(STR_TO_DATE(date, '%m/%d/%Y'), '%m/%Y') ='".$date."'")
                    ->get();
                    
            } else {
                $userArr[$i] = 0;
                $date=date('m/Y', strtotime($i . '/' . date('y')));
                $userArr['month_year'] = date('M y', strtotime($i . '/' . date('y')));
                $userArr['data'] = CncProduction::whereRaw("DATE_FORMAT(STR_TO_DATE(date, '%m/%d/%Y'), '%m/%Y') ='".$date."'")
                    ->get();
                    
            }
            dd($userArr);
            array_push($data_array,$userArr);
        }
        return view('batch_numbers.batchwise_cnc_prod_report',compact('data_array'));
    }
}
