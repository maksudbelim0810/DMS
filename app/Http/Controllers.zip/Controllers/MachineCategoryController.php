<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\MachineCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class MachineCategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        
         $this->middleware('permission:machine_category-list|machine_category-create|machine_category-edit|machine_category-delete', ['only' => ['index','store']]);
         $this->middleware('permission:machine_category-create', ['only' => ['create','store']]);
         $this->middleware('permission:machine_category-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:machine_category-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $machine_category=MachineCategory::orderBy('id','desc')->paginate(10);
        return view('machine_category.index',compact('machine_category'))
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        return view('machine_category.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
        ]);
        $input = $request->all();

        MachineCategory::create($input);

        return redirect()->route('machine_category.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $machine_category=MachineCategory::find($id);
        return view('machine_category.edit',compact('machine_category'));
    }
    public function update(Request $request,$id)
    {
        $request->validate([
            'name' => 'required',
        ]);
        
        $input = $request->all();
       
        $machine_category = MachineCategory::find($id);
        $machine_category->update($input);
        return redirect()->route('machine_category.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = MachineCategory::find($id);
        $data->delete();
        return redirect()->route('machine_category.index')->with('success','Data Deleted Successfully');
    }

}
