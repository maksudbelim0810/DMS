<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\VendorCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;

class VendorCategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
       
         $this->middleware('permission:vendor_category-list|vendor_category-create|vendor_category-edit|vendor_category-delete', ['only' => ['index','store']]);
         $this->middleware('permission:vendor_category-create', ['only' => ['create','store']]);
         $this->middleware('permission:vendor_category-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:vendor_category-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $vendor_category=VendorCategory::orderBy('id','desc')->paginate(10);
        return view('vendor_category.index',compact('vendor_category')) 
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        return view('vendor_category.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'vendor_category' => 'required|unique:vendor_categories',
        ]);
        $input = $request->all();

        VendorCategory::create($input);

        return redirect()->route('vendor_category.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $vendor_category=VendorCategory::find($id);
        return view('vendor_category.edit',compact('vendor_category'));
    }
    public function update(Request $request,$id)
    {
        $request->validate([
            'vendor_category' => 'required',
        ]);
        
        $input = $request->all();
       
        $vendor_category = VendorCategory::find($id);
        $vendor_category->update($input);
        return redirect()->route('vendor_category.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = VendorCategory::find($id);
        $data->delete();
        return redirect()->route('vendor_category.index')->with('success','Data Deleted Successfully');
    }

}
