<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Location;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class LocationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        
         $this->middleware('permission:location-list|location-create|location-edit|location-delete', ['only' => ['index','store']]);
         $this->middleware('permission:location-create', ['only' => ['create','store']]);
         $this->middleware('permission:location-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:location-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $location=Location::orderBy('id','desc')->paginate(10);
        return view('location.index',compact('location'))
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        return view('location.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'location_name' => 'required|unique:locations',
        ]);
        $input = $request->all();

        Location::create($input);

        return redirect()->route('location.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $location=Location::find($id);
        return view('location.edit',compact('location'));
    }
    public function update(Request $request,$id)
    {
        $request->validate([
            'location_name' => 'required',
        ]);
        
        $input = $request->all();
       
        $location = Location::find($id);
        $location->update($input);
        return redirect()->route('location.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = Location::find($id);
        $data->delete();
        return redirect()->route('location.index')->with('success','Data Deleted Successfully');
    }

}
