<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Setup;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class SetupController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        
         $this->middleware('permission:setup-list|setup-create|setup-edit|setup-delete', ['only' => ['index','store']]);
         $this->middleware('permission:setup-create', ['only' => ['create','store']]);
         $this->middleware('permission:setup-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:setup-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $setup=Setup::orderBy('id','desc')->paginate(10);
        return view('setup.index',compact('setup'))
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        return view('setup.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'setup_name' => 'required|unique:setups',
        ]);
        $input = $request->all();

        Setup::create($input);

        return redirect()->route('setup.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $setup=Setup::find($id);
        return view('setup.edit',compact('setup'));
    }
    public function update(Request $request,$id)
    {
        $request->validate([
            'setup_name' => 'required',
        ]);
        
        $input = $request->all();
       
        $setup = Setup::find($id);
        $setup->update($input);
        return redirect()->route('setup.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = Setup::find($id);
        $data->delete();
        return redirect()->route('setup.index')->with('success','Data Deleted Successfully');
    }

}
