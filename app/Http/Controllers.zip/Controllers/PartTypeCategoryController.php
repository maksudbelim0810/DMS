<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\PartTypeCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class PartTypeCategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        
         $this->middleware('permission:part_type_category-list|part_type_category-create|part_type_category-edit|part_type_category-delete', ['only' => ['index','store']]);
         $this->middleware('permission:part_type_category-create', ['only' => ['create','store']]);
         $this->middleware('permission:part_type_category-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:part_type_category-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $part_type_category=PartTypeCategory::orderBy('id','desc')->paginate(10);
        return view('part_type_category.index',compact('part_type_category'))
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        return view('part_type_category.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'part_type_category' => 'required|unique:part_type_categories',
        ]);
        $input = $request->all();

        PartTypeCategory::create($input);

        return redirect()->route('part_type_category.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $part_type_category=PartTypeCategory::find($id);
        return view('part_type_category.edit',compact('part_type_category'));
    }
    public function update(Request $request,$id)
    {
        $request->validate([
            'part_type_category' => 'required',
        ]);
        
        $input = $request->all();
       
        $part_type_category = PartTypeCategory::find($id);
        $part_type_category->update($input);
        return redirect()->route('part_type_category.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = PartTypeCategory::find($id);
        $data->delete();
        return redirect()->route('part_type_category.index')->with('success','Data Deleted Successfully');
    }

}
