<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\EmployeeBioData;
use Illuminate\Http\Request;
use App\Models\EmployeeCategory;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class EmployeeBioDataController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        
         $this->middleware('permission:employee_bio_data-list|employee_bio_data-create|employee_bio_data-edit|employee_bio_data-delete', ['only' => ['index','store']]);
         $this->middleware('permission:employee_bio_data-create', ['only' => ['create','store']]);
         $this->middleware('permission:employee_bio_data-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:employee_bio_data-delete', ['only' => ['destroy']]);
   
    }
    public function index(Request $request)
    {
        $employee_bio_data=EmployeeBioData::orderBy('id','desc')->paginate(10);
        return view('employee_bio_data.index',compact('employee_bio_data')) 
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        $emp_category=EmployeeCategory::all();
        return view('employee_bio_data.create',compact('emp_category'));
    }
    public function store(Request $request)
    {
        $input = $request->all();

        EmployeeBioData::create($input);

        return redirect()->route('employee_bio_data.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $employee_bio_data=EmployeeBioData::find($id);
        $emp_category=EmployeeCategory::all();
        return view('employee_bio_data.edit',compact('employee_bio_data','emp_category'));
    }
    public function update(Request $request,$id)
    {
        $input = $request->all();
       
        $employee_bio_data = EmployeeBioData::find($id);
        $employee_bio_data->update($input);
        return redirect()->route('employee_bio_data.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = EmployeeBioData::find($id);
        $data->delete();
        return redirect()->route('employee_bio_data.index')->with('success','Data Deleted Successfully');
    }

}
