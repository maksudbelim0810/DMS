<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\BatchNumber;
use App\Models\EmployeeBioData;
use App\Models\GradeSortingReport;
use App\Models\MachineEntry;
use App\Models\ShiftEntry;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use PDF;

class GrandSortingReportController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');

        $this->middleware('permission:grade_sorting_report-list|grade_sorting_report-create|grade_sorting_report-edit|grade_sorting_report-delete', ['only' => ['index', 'store']]);
        $this->middleware('permission:grade_sorting_report-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:grade_sorting_report-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:grade_sorting_report-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        $batch_no = isset($_GET['batch_no']) ? $_GET['batch_no'] : '';
        $part_no_and_name = isset($_GET['part_no_and_name']) ? $_GET['part_no_and_name'] : '';
        $customer = isset($_GET['customer']) ? $_GET['customer'] : '';
        $mc_no = isset($_GET['mc_no']) ? $_GET['mc_no'] : '';
        $shift = isset($_GET['shift']) ? $_GET['shift'] : '';
        $checked_qty = isset($_GET['checked_qty']) ? $_GET['checked_qty'] : '';
        $suspected_rej_qty = isset($_GET['suspected_rej_qty']) ? $_GET['suspected_rej_qty'] : '';
        $inspectors = isset($_GET['inspectors']) ? $_GET['inspectors'] : '';
        $ok_qty = isset($_GET['ok_qty']) ? $_GET['ok_qty'] : '';
        $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
        $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

        $grade_sorting_report = GradeSortingReport::orderBy('id', 'desc');
        if (!empty($batch_no)) {
            $grade_sorting_report->where('batch_no', 'like', '%' . $batch_no . '%');
        }
        if (!empty($part_no_and_name)) {
            $grade_sorting_report->where('part_no_and_name', 'like', '%' . $part_no_and_name . '%');
        }
        if (!empty($customer)) {
            $grade_sorting_report->where('customer', 'like', '%' . $customer . '%');
        }
        if (!empty($mc_no)) {
            $grade_sorting_report->where('mc_no', 'like', '%' . $mc_no . '%');
        }
        if (!empty($shift)) {
            $grade_sorting_report->where('shift', 'like', '%' . $shift . '%');
        }
        if (!empty($checked_qty)) {
            $grade_sorting_report->where('checked_qty', 'like', '%' . $checked_qty . '%');
        }
        if (!empty($suspected_rej_qty)) {
            $grade_sorting_report->where('suspected_rej_qty', 'like', '%' . $suspected_rej_qty . '%');
        }
        if (!empty($inspectors)) {
            $grade_sorting_report->where('inspectors', 'like', '%' . $inspectors . '%');
        }
        if (!empty($ok_qty)) {
            $grade_sorting_report->where('ok_qty', 'like', '%' . $ok_qty . '%');
        }
        if (!empty($start_date && $end_date)) {
            $grade_sorting_report->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
        }
        $data['batch_no'] = $batch_no;
        $data['part_no_and_name'] = $part_no_and_name;
        $data['customer'] = $customer;
        $data['mc_no'] = $mc_no;
        $data['shift'] = $shift;
        $data['checked_qty'] = $checked_qty;
        $data['suspected_rej_qty'] = $suspected_rej_qty;
        $data['inspectors'] = $inspectors;
        $data['ok_qty'] = $ok_qty;
        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $grade_sorting_report = $grade_sorting_report->paginate(10);
        if ($request->pdf == 'pdf') {
            $data = GradeSortingReport::select("*")
                ->where('batch_no', 'like', '%' . $batch_no . '%')
                ->where('part_no_and_name', 'like', '%' . $part_no_and_name . '%')
                ->where('customer', 'like', '%' . $customer . '%')
                ->where('mc_no', 'like', '%' . $mc_no . '%')
                ->where('shift', 'like', '%' . $shift . '%')
                ->where('checked_qty', 'like', '%' . $checked_qty . '%')
                ->where('suspected_rej_qty', 'like', '%' . $suspected_rej_qty . '%')
                ->where('inspectors', 'like', '%' . $inspectors . '%')
                ->where('ok_qty', 'like', '%' . $ok_qty . '%')
                ->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))])
                ->get();
            $return_data = [
                'title' => 'Ravi Technoforge Pvt Ltd',
                'date' => date('m/d/Y'),
                'data' => $data,
            ];

            $pdf = PDF::loadView('grade_sorting_report.daily_report', $return_data);

            return $pdf->download('daily grade sorting report all unit.pdf');
        }
        $mc_no = MachineEntry::where('machine_department', 'like', '%Grade Sorting%')->get();
        $shift = ShiftEntry::all();
        $inspectors = EmployeeBioData::where('Oemcname', 'LIKE', '%GRADE SORTING%')->get();
        return view('grade_sorting_report.index', compact('grade_sorting_report', 'data','mc_no','shift','inspectors'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        $batch_number = BatchNumber::all();
        $shift = ShiftEntry::all();
        $inspectors = EmployeeBioData::where('Oemcname', 'LIKE', '%GRADE SORTING%')->get();

        $mc_no = MachineEntry::where('machine_department', 'like', '%Grade Sorting%')->get();

        return view('grade_sorting_report.create', compact('batch_number', 'shift', 'mc_no', 'inspectors'));
    }
    public function store(Request $request)
    {
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));
        GradeSortingReport::create($input);

        return redirect()->route('grade_sorting_report.index')->with('success', 'Data Saved Successfully');
    }
    public function edit($id)
    {
        $grade_sorting_report = GradeSortingReport::with('batch_number')->where('id', $id)->first();
        $batch_number = BatchNumber::all();
        $shift = ShiftEntry::all();
        $inspectors = EmployeeBioData::where('Oemcname', 'LIKE', '%GRADE SORTING%')->get();
        $mc_no = MachineEntry::where('machine_department', 'like', '%Grade Sorting%')->get();
        return view('grade_sorting_report.edit', compact('grade_sorting_report', 'batch_number', 'shift', 'mc_no', 'inspectors'));
    }
    public function update(Request $request, $id)
    {
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));
        $grade_sorting_report = GradeSortingReport::find($id);
        $grade_sorting_report->update($input);
        return redirect()->route('grade_sorting_report.index')->with('success', 'Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = GradeSortingReport::find($id);
        $data->delete();
        return redirect()->route('grade_sorting_report.index')->with('success', 'Data Deleted Successfully');
    }
    public function daily_grade_sorting_report()
    {
        $data = GradeSortingReport::where('date', Carbon::today()->format('m/d/Y'))
            ->get();
        // dd($data);
        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('grade_sorting_report.daily_report', $return_data);

        return $pdf->download('daily grade sorting report all unit.pdf');
    }
    public function daily_grade_sorting_report_view()
    {
        $data = GradeSortingReport::where('date', Carbon::today()->format('m/d/Y'))
            ->get();
        // dd($data);
        return view('grade_sorting_report.daily_grade_sorting_report_view', compact('data'));
    }
}
