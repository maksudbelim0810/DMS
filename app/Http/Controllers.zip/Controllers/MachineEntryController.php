<?php

namespace App\Http\Controllers;

use App\Models\MachineCategory;
use App\Models\MachineEntry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class MachineEntryController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:machine_entry-list|machine_entry-create|machine_entry-edit|machine_entry-delete', ['only' => ['index','store']]);
         $this->middleware('permission:machine_entry-create', ['only' => ['create','store']]);
         $this->middleware('permission:machine_entry-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:machine_entry-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        $data = MachineEntry::orderBy('machine_number','asc')->paginate(10);
  
        return view('machine_entry.index',compact('data'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {  
        $machine_department=MachineCategory::all();
        return view('machine_entry.create',compact('machine_department'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {    
        try { 
            $MachineEntry = New MachineEntry;
            $MachineEntry->machine_name = $request->machine_name;
            $MachineEntry->machine_department = $request->machine_department;
            $MachineEntry->machine_number = $request->machine_number;
            $MachineEntry->machine_model = $request->machine_model;
            $MachineEntry->machine_make = $request->machine_make;
            $MachineEntry->mc_capacity = $request->mc_capacity;
            $MachineEntry->save();
        
            return redirect()->route('machine_entry.index')
                            ->with('success','Data Saved Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $MachineEntry = MachineEntry::find($id);  
        $machine_department=MachineCategory::all();  
        return view('machine_entry.edit',compact('MachineEntry','machine_department'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try { 

            $MachineEntry = MachineEntry::find($id);
            $MachineEntry->machine_name = $request->machine_name;
            $MachineEntry->machine_department = $request->machine_department;
            $MachineEntry->machine_number = $request->machine_number;
            $MachineEntry->machine_model = $request->machine_model;
            $MachineEntry->machine_make = $request->machine_make;
            $MachineEntry->mc_capacity = $request->mc_capacity;
            $MachineEntry->save();
        
            return redirect()->route('machine_entry.index')
                            ->with('success','Data Saved Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
             
            MachineEntry::find($id)->delete();
            return redirect()->route('machine_entry.index')
                            ->with('success','Data Deleted Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
}
