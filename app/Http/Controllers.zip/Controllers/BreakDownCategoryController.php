<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\BreakDownCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class BreakDownCategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
       
         $this->middleware('permission:break_down_category-list|break_down_category-create|break_down_category-edit|break_down_category-delete', ['only' => ['index','store']]);
         $this->middleware('permission:break_down_category-create', ['only' => ['create','store']]);
         $this->middleware('permission:break_down_category-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:break_down_category-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $break_down_category=BreakDownCategory::orderBy('id','desc')->paginate(10);
        return view('break_down_category.index',compact('break_down_category'))
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        return view('break_down_category.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'break_down_category' => 'required|unique:break_down_categories',
        ]);
        $input = $request->all();

        BreakDownCategory::create($input);

        return redirect()->route('break_down_category.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $break_down_category=BreakDownCategory::find($id);
        return view('break_down_category.edit',compact('break_down_category'));
    }
    public function update(Request $request,$id)
    {
        $request->validate([
            'break_down_category' => 'required',
        ]);
        
        $input = $request->all();
       
        $break_down_category = BreakDownCategory::find($id);
        $break_down_category->update($input);
        return redirect()->route('break_down_category.index')->with('success','Update successfully');
    }
    public function destroy($id)
    {
        $data = BreakDownCategory::find($id);
        $data->delete();
        return redirect()->route('break_down_category.index')->with('success','Data Deleted Successfully');
    }

}
