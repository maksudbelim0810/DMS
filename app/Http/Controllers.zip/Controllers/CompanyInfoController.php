<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Yajra\DataTables\Facades\DataTables;
use Illuminate\Support\Facades\URL;

class CompanyInfoController extends Controller
{
    //
    public function company_info(Request $request)
    {
    
        $data = DB::table('company_info')->first();
       
       
        return view('company_info.company_info',compact('data'));
    }
    public function update_company_info(Request $request)
    {
        $data['Name'] = $request->Name;
        $data['Address'] = $request->Address;
        $data['City'] = $request->City;
        $data['Phone'] = $request->Phone;

        // $about=DB::table('company_info')->first();
        DB::table('company_info')->update($data);
        return redirect('company_info');
        
    }
}
