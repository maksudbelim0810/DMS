<?php

namespace App\Http\Controllers;

use App\Models\InsertEntry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class InsertEntryController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:insert_entry-list|insert_entry-create|insert_entry-edit|insert_entry-delete', ['only' => ['index','store']]);
         $this->middleware('permission:insert_entry-create', ['only' => ['create','store']]);
         $this->middleware('permission:insert_entry-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:insert_entry-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        $data = InsertEntry::latest()->paginate(10);
  
        return view('insert_entry.index',compact('data'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {  
        return view('insert_entry.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {    
        try { 
            $InsertEntry = New InsertEntry;
            $InsertEntry->name = $request->name;
            $InsertEntry->short_name = $request->short_name;
            $InsertEntry->mfg_name = $request->mfg_name;
            $InsertEntry->rate = $request->rate;
            $InsertEntry->save();
        
            return redirect()->route('insert_entry.index')
                            ->with('success','Data Saved Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $InsertEntry = InsertEntry::find($id);    
        return view('insert_entry.edit',compact('InsertEntry'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try { 

            $InsertEntry = InsertEntry::find($id);
            $InsertEntry->name = $request->name;
            $InsertEntry->short_name = $request->short_name;
            $InsertEntry->mfg_name = $request->mfg_name;
            $InsertEntry->rate = $request->rate;
            $InsertEntry->save();
        
            return redirect()->route('insert_entry.index')
                            ->with('success','Data Saved Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
             
            InsertEntry::find($id)->delete();
            return redirect()->route('insert_entry.index')
                            ->with('success','Data Deleted Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
}
