<?php

namespace App\Http\Controllers;

use App\Models\BatchNumber;
use App\Models\MachineEntry;
use App\Models\MPIProduction;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class MPIProductionController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:mpi_production-list|mpi_production-create|mpi_production-edit|mpi_production-delete', ['only' => ['index','store']]);
         $this->middleware('permission:mpi_production-create', ['only' => ['create','store']]);
         $this->middleware('permission:mpi_production-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:mpi_production-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        $data = MPIProduction::with('BatchNumber')->latest()->paginate(10);
        return view('mpi_production.index',compact('data'))
            ->with('i', ($request->input('page', 1) - 1) * 10);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {  
        $BatchNumber = BatchNumber::pluck('batch_name','id')->all(); // BatchNumber data
        return view('mpi_production.create',compact('BatchNumber','mc_no'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {    
        try { 
            $MPIProduction = New MPIProduction;
            $MPIProduction->mc_no = $request->mc_no;
            $MPIProduction->date = $request->date;
            $MPIProduction->shift = $request->shift;
            $MPIProduction->batch_number_id = $request->batch_number_id;
            $MPIProduction->part_name = $request->part_name;
            $MPIProduction->customer = $request->customer;
            $MPIProduction->operator_name = $request->operator_name;
            $MPIProduction->inspected_qty = $request->inspected_qty;
            $MPIProduction->rejected_qty = $request->rejected_qty;
            $MPIProduction->ok_qty = $request->ok_qty;
            $MPIProduction->mag_type = $request->mag_type;
            $MPIProduction->black_light = $request->black_light;
            $MPIProduction->bath_concentration = $request->bath_concentration;
            $MPIProduction->bath_quality = $request->bath_quality;
            $MPIProduction->test_piece = $request->test_piece;
            $MPIProduction->ampere = $request->ampere;
            $MPIProduction->save();
        
            return redirect()->route('mpi_production.index')
                            ->with('success','Data Saved Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $MPIProduction = MPIProduction::find($id);  
        $BatchNumber = BatchNumber::pluck('batch_name','id')->all(); // BatchNumber data 
        $SelectedBatchNumber = BatchNumber::where('id',$MPIProduction->batch_number_id)->pluck('id')->first(); // BatchNumber data 
        return view('mpi_production.edit',compact('MPIProduction','BatchNumber','SelectedBatchNumber'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try { 

            $MPIProduction = MPIProduction::find($id);
            $MPIProduction->mc_no = $request->mc_no;
            $MPIProduction->date = $request->date;
            $MPIProduction->shift = $request->shift;
            $MPIProduction->batch_number_id = $request->batch_number_id;
            $MPIProduction->part_name = $request->part_name;
            $MPIProduction->customer = $request->customer;
            $MPIProduction->operator_name = $request->operator_name;
            $MPIProduction->inspected_qty = $request->inspected_qty;
            $MPIProduction->rejected_qty = $request->rejected_qty;
            $MPIProduction->ok_qty = $request->ok_qty;
            $MPIProduction->mag_type = $request->mag_type;
            $MPIProduction->black_light = $request->black_light;
            $MPIProduction->bath_concentration = $request->bath_concentration;
            $MPIProduction->bath_quality = $request->bath_quality;
            $MPIProduction->test_piece = $request->test_piece;
            $MPIProduction->ampere = $request->ampere;
            $MPIProduction->save();
        
            return redirect()->route('mpi_production.index')
                            ->with('success','Data Saved Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
             
            MPIProduction::find($id)->delete();
            return redirect()->route('mpi_production.index')
                            ->with('success','Data Deleted Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
}
