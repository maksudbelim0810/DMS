<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\BatchNumber;
use App\Models\DispatchAdvice;
use App\Models\EmployeeBioData;
use App\Models\MachineEntry;
use App\Models\ShiftEntry;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon as SupportCarbon;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;
use PDF;

class DispatchAdviceController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');

        $this->middleware('permission:dispatch_advice-list|dispatch_advice-create|dispatch_advice-edit|dispatch_advice-delete', ['only' => ['index', 'store']]);
        $this->middleware('permission:dispatch_advice-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:dispatch_advice-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:dispatch_advice-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        $batch_no = isset($_GET['batch_no']) ? $_GET['batch_no'] : '';
        $part_name = isset($_GET['part_name']) ? $_GET['part_name'] : '';
        $customer = isset($_GET['customer']) ? $_GET['customer'] : '';
        $ok_qty = isset($_GET['ok_qty']) ? $_GET['ok_qty'] : '';
        $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
        $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
        $dispatch_advice = DispatchAdvice::orderBy('id', 'desc');
        if (!empty($batch_no)) {
            $dispatch_advice->where('batch_no', 'like', '%' . $batch_no . '%');
        }
        if (!empty($part_name)) {
            $dispatch_advice->where('part_name', 'like', '%' . $part_name . '%');
        }
        if (!empty($customer)) {
            $dispatch_advice->where('customer', 'like', '%' . $customer . '%');
        }
        if (!empty($ok_qty)) {
            $dispatch_advice->where('ok_qty', 'like', '%' . $ok_qty . '%');
        }
        if (!empty($start_date && $end_date)) {
            $dispatch_advice->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
        }
        $data['batch_no'] = $batch_no;
        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $data['part_name'] = $part_name;
        $data['customer'] = $customer;
        $data['ok_qty'] = $ok_qty;
        $dispatch_advice = $dispatch_advice->paginate(10);
        if ($request->pdf == 'pdf') {
            $data = DispatchAdvice::select("*")
                ->where('batch_no', 'like', '%' . $batch_no . '%')
                ->where('part_name', 'like', '%' . $part_name . '%')
                ->where('customer', 'like', '%' . $customer . '%')
                ->where('ok_qty', 'like', '%' . $ok_qty . '%')
                ->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))])
                ->get();
            $return_data = [
                'title' => 'Ravi Technoforge Pvt Ltd',
                'date' => date('m/d/Y'),
                'data' => $data,
            ];

            $pdf = PDF::loadView('dispatch_advice.daily_report', $return_data);

            return $pdf->download('daily dispatch report.pdf');
        }
        return view('dispatch_advice.index', compact('dispatch_advice', 'data'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        $dispatch_advice_no = DB::table('dispatch_advice')->orderBy('id', 'desc')->first();
        $new_dispatch_advice_no = $dispatch_advice_no->dispatch_advice_no + 1;
        $batch_number = BatchNumber::all(); // BatchNumber data
        $shift = ShiftEntry::all();
        $incharge = EmployeeBioData::where('Oemcname', 'LIKE', '%DISPATCH%')->get();
        return view('dispatch_advice.create', compact('batch_number', 'shift', 'incharge', 'new_dispatch_advice_no'));
    }
    public function store(Request $request)
    {
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));
        $input['advice_date'] = date('m/d/Y', strtotime($input['advice_date']));
        // $input['invoice_date']=date('m/d/Y', strtotime($input['invoice_date']));
        $input['sr_no'] = json_encode($request->sr_no);
        $input['box_quantity'] = json_encode($request->box_quantity);
        $input['nos_per_box'] = json_encode($request->nos_per_box);
        $input['total_nos'] = json_encode($request->total_nos);
        $input['weight_per_nos'] = json_encode($request->weight_per_nos);
        $input['total_weight'] = json_encode($request->total_weight);

        DispatchAdvice::create($input);

        return redirect()->route('dispatch_advice.index')->with('success', 'Data Saved Successfully');
    }
    public function edit($id)
    {
        $dispatch_advice = DispatchAdvice::with('batch_number')->where('id', $id)->first();
        $batch_number = BatchNumber::all(); // BatchNumber data
        $shift = ShiftEntry::all();
        $incharge = EmployeeBioData::where('Oemcname', 'LIKE', '%DISPATCH%')->get();
        return view('dispatch_advice.edit', compact('dispatch_advice', 'batch_number', 'shift', 'incharge'));
    }
    public function update(Request $request, $id)
    {
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));
        $input['advice_date'] = date('m/d/Y', strtotime($input['advice_date']));
        // $input['invoice_date']=date('m/d/Y', strtotime($input['invoice_date']));
        $input['sr_no'] = json_encode($request->sr_no);
        $input['box_quantity'] = json_encode($request->box_quantity);
        $input['nos_per_box'] = json_encode($request->nos_per_box);
        $input['total_nos'] = json_encode($request->total_nos);
        $input['weight_per_nos'] = json_encode($request->weight_per_nos);
        $input['total_weight'] = json_encode($request->total_weight);
        $dispatch_advice = DispatchAdvice::find($id);
        $dispatch_advice->update($input);
        return redirect()->route('dispatch_advice.index')->with('success', 'Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = DispatchAdvice::find($id);
        $data->delete();
        return redirect()->route('dispatch_advice.index')->with('success', 'Data Deleted Successfully');
    }
    public function Daily_dispatch_report()
    {
        $data = DispatchAdvice::select("*")
            ->where('date', Carbon::today()->format('m/d/Y'))
            ->get();
        // dd($data);
        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('dispatch_advice.daily_report', $return_data);

        return $pdf->download('daily dispatch report.pdf');
    }
    public function Daily_dispatch_report_view()
    {
        $data = DispatchAdvice::select("*")
            ->where('date', Carbon::today()->format('m/d/Y'))
            ->get();
        // dd($data);
        return view('dispatch_advice.Daily_dispatch_report_view', compact('data'));
    }
}
