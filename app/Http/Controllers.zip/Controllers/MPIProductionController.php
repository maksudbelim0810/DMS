<?php

namespace App\Http\Controllers;

use App\Models\BatchNumber;
use App\Models\EmployeeBioData;
use App\Models\MachineEntry;
use App\Models\MPIProduction;
use App\Models\ShiftEntry;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use PDF;

class MPIProductionController extends Controller
{
    function __construct()
    {
        $this->middleware('permission:mpi_production-list|mpi_production-create|mpi_production-edit|mpi_production-delete', ['only' => ['index', 'store']]);
        $this->middleware('permission:mpi_production-create', ['only' => ['create', 'store']]);
        $this->middleware('permission:mpi_production-edit', ['only' => ['edit', 'update']]);
        $this->middleware('permission:mpi_production-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        $batch_no = isset($_GET['batch_no']) ? $_GET['batch_no'] : '';
        $part_name = isset($_GET['part_name']) ? $_GET['part_name'] : '';
        $customer = isset($_GET['customer']) ? $_GET['customer'] : '';
        $mc_no = isset($_GET['mc_no']) ? $_GET['mc_no'] : '';
        $shift = isset($_GET['shift']) ? $_GET['shift'] : '';
        $inspected_qty = isset($_GET['inspected_qty']) ? $_GET['inspected_qty'] : '';
        $rejected_qty = isset($_GET['rejected_qty']) ? $_GET['rejected_qty'] : '';
        $operator_name = isset($_GET['operator_name']) ? $_GET['operator_name'] : '';
        $ok_qty = isset($_GET['ok_qty']) ? $_GET['ok_qty'] : '';
        $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
        $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
        $mpi_production = MPIProduction::orderBy('id', 'desc');
        if (!empty($batch_no)) {
            $mpi_production->where('batch_number_id', 'like', '%' . $batch_no . '%');
        }
        if (!empty($part_name)) {
            $mpi_production->where('part_name', 'like', '%' . $part_name . '%');
        }
        if (!empty($customer)) {
            $mpi_production->where('customer', 'like', '%' . $customer . '%');
        }
        if (!empty($mc_no)) {
            $mpi_production->where('mc_no', 'like', '%' . $mc_no . '%');
        }
        if (!empty($shift)) {
            $mpi_production->where('shift', 'like', '%' . $shift . '%');
        }
        if (!empty($inspected_qty)) {
            $mpi_production->where('inspected_qty', 'like', '%' . $inspected_qty . '%');
        }
        if (!empty($rejected_qty)) {
            $mpi_production->where('rejected_qty', 'like', '%' . $rejected_qty . '%');
        }
        if (!empty($operator_name)) {
            $mpi_production->where('operator_name', 'like', '%' . $operator_name . '%');
        }
        if (!empty($ok_qty)) {
            $mpi_production->where('ok_qty', 'like', '%' . $ok_qty . '%');
        }
        if (!empty($start_date && $end_date ) ) {
            $mpi_production->whereBetween('date',[date('m/d/Y',strtotime($start_date)), date('m/d/Y',strtotime($end_date))]);
    }
        $data['batch_no'] = $batch_no;
        $data['part_name'] = $part_name;
        $data['customer'] = $customer;
        $data['mc_no'] = $mc_no;
        $data['shift'] = $shift;
        $data['inspected_qty'] = $inspected_qty;
        $data['rejected_qty'] = $rejected_qty;
        $data['operator_name'] = $operator_name;
        $data['ok_qty'] = $ok_qty;
        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $mpi_production = $mpi_production->paginate(10);
        if ($request->pdf == 'pdf') {
            $data = MPIProduction::select("*")
                ->where('batch_no', 'like', '%' . $batch_no . '%') 
                ->where('part_name', 'like', '%' . $part_name . '%')
                ->where('customer', 'like', '%' . $customer . '%')
                ->where('mc_no', 'like', '%' . $mc_no . '%')
                ->where('shift', 'like', '%' . $shift . '%')
                ->where('inspected_qty', 'like', '%' . $inspected_qty . '%')
                ->where('rejected_qty', 'like', '%' . $rejected_qty . '%')
                ->where('operator_name', 'like', '%' . $operator_name . '%')
                ->where('ok_qty', 'like', '%' . $ok_qty . '%')
                ->whereBetween('date',[date('m/d/Y',strtotime($start_date)), date('m/d/Y',strtotime($end_date))])
                ->get();
            $return_data = [
                'title' => 'Ravi Technoforge Pvt Ltd',
                'date' => date('m/d/Y'),
                'data' => $data,
            ];

            $pdf = PDF::loadView('mpi_production.daily_report', $return_data);

            return $pdf->download('daily mpi report.pdf');
        }
        $shift = ShiftEntry::all();
        $mc_no = MachineEntry::where('machine_department', 'LIKE', '%MPI%')->get();

        $operator_name = EmployeeBioData::where('Oemcname', 'LIKE', '%MPI%')->get();
        return view('mpi_production.index', compact('mpi_production', 'data', 'shift', 'mc_no', 'operator_name'))
            ->with('i', ($request->input('page', 1) - 1) * 10);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

        $batch_number = BatchNumber::all(); // BatchNumber data
        $shift = ShiftEntry::all();
        $mc_no = MachineEntry::where('machine_department', 'LIKE', '%MPI%')->get();

        $operator_name = EmployeeBioData::where('Oemcname', 'LIKE', '%MPI%')->get();

        return view('mpi_production.create', compact('batch_number', 'shift', 'mc_no', 'operator_name'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // try { 
        //     $MPIProduction = New MPIProduction;
        //     $MPIProduction->mc_no = $request->mc_no;
        //     $MPIProduction->date = $request->date;
        //     $MPIProduction->shift = $request->shift;
        //     $MPIProduction->batch_number_id = $request->batch_number_id;
        //     $MPIProduction->part_name = $request->part_name;
        //     $MPIProduction->customer = $request->customer;
        //     $MPIProduction->operator_name = $request->operator_name;
        //     $MPIProduction->inspected_qty = $request->inspected_qty;
        //     $MPIProduction->rejected_qty = $request->rejected_qty;
        //     $MPIProduction->ok_qty = $request->ok_qty;
        //     $MPIProduction->mag_type = $request->mag_type;
        //     $MPIProduction->black_light = $request->black_light;
        //     $MPIProduction->bath_concentration = $request->bath_concentration;
        //     $MPIProduction->bath_quality = $request->bath_quality;
        //     $MPIProduction->test_piece = $request->test_piece;
        //     $MPIProduction->ampere = $request->ampere;
        //     $MPIProduction->save();

        //     return redirect()->route('mpi_production.index')
        //                     ->with('success','MPI Production Data Saved Successfully');

        // } catch(\Exception $e){
        //     return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        // };
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));

        MPIProduction::create($input);
        return redirect()->route('mpi_production.index')->with('success', 'Data Saved Successfully');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $MPIProduction = MPIProduction::with('batch')->where('id', $id)->first();
        $batch_number = BatchNumber::all(); // BatchNumber data
        $shift = ShiftEntry::all();
        $mc_no = MachineEntry::where('machine_department', 'LIKE', '%MPI%')->get();
        $operator_name = EmployeeBioData::where('Oemcname', 'LIKE', '%MPI%')->get();
        return view('mpi_production.edit', compact('MPIProduction', 'batch_number', 'shift', 'mc_no', 'operator_name'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // try { 

        //     $MPIProduction = MPIProduction::find($id);
        //     $MPIProduction->mc_no = $request->mc_no;
        //     $MPIProduction->date = $request->date;
        //     $MPIProduction->shift = $request->shift;
        //     $MPIProduction->batch_number_id = $request->batch_number_id;
        //     $MPIProduction->part_name = $request->part_name;
        //     $MPIProduction->customer = $request->customer;
        //     $MPIProduction->operator_name = $request->operator_name;
        //     $MPIProduction->inspected_qty = $request->inspected_qty;
        //     $MPIProduction->rejected_qty = $request->rejected_qty;
        //     $MPIProduction->ok_qty = $request->ok_qty;
        //     $MPIProduction->mag_type = $request->mag_type;
        //     $MPIProduction->black_light = $request->black_light;
        //     $MPIProduction->bath_concentration = $request->bath_concentration;
        //     $MPIProduction->bath_quality = $request->bath_quality;
        //     $MPIProduction->test_piece = $request->test_piece;
        //     $MPIProduction->ampere = $request->ampere;
        //     $MPIProduction->save();

        //     return redirect()->route('mpi_production.index')
        //                     ->with('success','MPI Production Data Saved Successfully');

        // } catch(\Exception $e){
        //     return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        // };
        $input = $request->all();
        $input['date'] = date('m/d/Y', strtotime($input['date']));
        $visual_packing = MPIProduction::find($id);
        $visual_packing->update($input);
        return redirect()->route('mpi_production.index')->with('success', 'Data Saved Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {

            MPIProduction::find($id)->delete();
            return redirect()->route('mpi_production.index')
                ->with('success', 'Data Deleted Successfully');
        } catch (\Exception $e) {
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
    public function daily_mpi_report()
    {
        $data = MPIProduction::where('date', Carbon::today()->format('m/d/Y'))
            ->get();
        // dd($data);
        $return_data = [
            'title' => 'Ravi Technoforge Pvt Ltd',
            'date' => date('m/d/Y'),
            'data' => $data,
        ];

        $pdf = PDF::loadView('mpi_production.daily_report', $return_data);

        return $pdf->download('daily mpi report.pdf');
    }
    public function daily_mpi_report_view()
    {
        $data = MPIProduction::where('date', Carbon::today()->format('m/d/Y'))
            ->get();
        // dd($data);
        return view('mpi_production.daily_mpi_report_view', compact('data'));
    }
}
