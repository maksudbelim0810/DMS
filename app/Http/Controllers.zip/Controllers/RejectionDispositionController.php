<?php

namespace App\Http\Controllers;

use App\Models\BatchNumber;
use App\Models\EmployeeBioData;
use App\Models\InsertEntry;
use App\Models\RejectionDisposition;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class RejectionDispositionController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:rejection_disposition-list|rejection_disposition-create|rejection_disposition-edit|rejection_disposition-delete', ['only' => ['index','store']]);
         $this->middleware('permission:rejection_disposition-create', ['only' => ['create','store']]);
         $this->middleware('permission:rejection_disposition-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:rejection_disposition-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        $batch_no = isset($_GET['batch_no']) ? $_GET['batch_no'] : '';
        $part_name = isset($_GET['part_name']) ? $_GET['part_name'] : '';
        $customer = isset($_GET['customer']) ? $_GET['customer'] : '';
        $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
        $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
        $rejection_disposition=RejectionDisposition::orderBy('id','desc');
        if(!empty($batch_no)){
            $rejection_disposition->where('batch_number_id','like','%'.$batch_no.'%');
        } 
        if(!empty($part_name)){
            $rejection_disposition->where('part_name','like','%'.$part_name.'%');
        } 
        if(!empty($customer)){
            $rejection_disposition->where('customer','like','%'.$customer.'%');
        } 
        if (!empty($start_date && $end_date)) {
            $rejection_disposition->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
        }
        $data['batch_no']=$batch_no;
        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $data['part_name'] = $part_name;
        $data['customer'] = $customer;
        $rejection_disposition=$rejection_disposition->paginate(10);
        if ($request->pdf == 'pdf') {
            $data = RejectionDisposition::select("*")
                ->where('batch_no', 'like', '%' . $batch_no . '%')
                ->where('part_name', 'like', '%' . $part_name . '%')
                ->where('customer', 'like', '%' . $customer . '%')
                ->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))])
                ->get();
            $return_data = [
                'title' => 'Ravi Technoforge Pvt Ltd',
                'date' => date('m/d/Y'),
                'data' => $data,
            ];

            $pdf = PDF::loadView('cnc_production.daily_report', $return_data);

            return $pdf->download('CNC_daily_report.pdf');
        }
        return view('rejection_disposition.index',compact('rejection_disposition','data'))
            ->with('i', ($request->input('page', 1) - 1) * 10);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {  
        $batch_number = BatchNumber::all(); // BatchNumber data
        $incharge=EmployeeBioData::get();
        return view('rejection_disposition.create',compact('batch_number','incharge'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {    
        // try { 
        //     $RejectionDisposition = New RejectionDisposition;
        //     $RejectionDisposition->date = $request->date;
        //     $RejectionDisposition->batch_number_id = $request->batch_number_id;
        //     $RejectionDisposition->part_name = $request->part_name;
        //     $RejectionDisposition->customer = $request->customer;
        //     $RejectionDisposition->incharge_name = $request->incharge_name;
        //     $RejectionDisposition->fr = $request->fr;
        //     $RejectionDisposition->fr_am = $request->fr_am;
        //     $RejectionDisposition->pmr = $request->pmr;
        //     $RejectionDisposition->remarks = $request->remarks;
        //     $RejectionDisposition->save();
        
        //     return redirect()->route('rejection_disposition.index')
        //                     ->with('success','Rejection Disposition Data Saved Successfully');

        // } catch(\Exception $e){
        //     return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        // };
        $input = $request->all();
        $input['date']=date('m/d/Y', strtotime($input['date']));
        RejectionDisposition::create($input);

        return redirect()->route('rejection_disposition.index')->with('success','Data Saved Successfully');
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $RejectionDisposition = RejectionDisposition::with('batch_number')->where('id',$id)->first();
        $batch_number = BatchNumber::all(); // BatchNumber data
        $incharge=EmployeeBioData::get(); 
        return view('rejection_disposition.edit',compact('RejectionDisposition','batch_number','incharge'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        // try { 

        //     $RejectionDisposition = RejectionDisposition::find($id);
        //     $RejectionDisposition->date = $request->date;
        //     $RejectionDisposition->batch_number_id = $request->batch_number_id;
        //     $RejectionDisposition->part_name = $request->part_name;
        //     $RejectionDisposition->customer = $request->customer;
        //     $RejectionDisposition->incharge_name = $request->incharge_name;
        //     $RejectionDisposition->fr = $request->fr;
        //     $RejectionDisposition->fr_am = $request->fr_am;
        //     $RejectionDisposition->pmr = $request->pmr;
        //     $RejectionDisposition->remarks = $request->remarks;
        //     $RejectionDisposition->save();
        
        //     return redirect()->route('rejection_disposition.index')
        //                     ->with('success','Rejection Disposition Data Saved Successfully');

        // } catch(\Exception $e){
        //     return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        // };
        $input = $request->all();
        $input['date']=date('m/d/Y', strtotime($input['date']));
        $visual_packing = RejectionDisposition::find($id);
        $visual_packing->update($input);
        return redirect()->route('rejection_disposition.index')->with('success','Data Saved Successfully');
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
             
            RejectionDisposition::find($id)->delete();
            return redirect()->route('rejection_disposition.index')
                            ->with('success','Data Deleted Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
}
