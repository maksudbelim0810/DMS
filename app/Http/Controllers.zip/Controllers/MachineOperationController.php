<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\MachineOperation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class MachineOperationController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        
         $this->middleware('permission:machine_opration-list|machine_opration-create|machine_opration-edit|machine_opration-delete', ['only' => ['index','store']]);
         $this->middleware('permission:machine_opration-create', ['only' => ['create','store']]);
         $this->middleware('permission:machine_opration-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:machine_opration-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $machine_opration=MachineOperation::orderBy('id','desc')->paginate(10);
        return view('machine_opration.index',compact('machine_opration'))
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        return view('machine_opration.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'machine_opration' => 'required|unique:machine_operations',
        ]);
        $input = $request->all();

        MachineOperation::create($input);

        return redirect()->route('machine_opration.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $machine_opration=MachineOperation::find($id);
        return view('machine_opration.edit',compact('machine_opration'));
    }
    public function update(Request $request,$id)
    {
        $request->validate([
            'machine_opration' => 'required',
        ]);
        
        $input = $request->all();
       
        $machine_opration = MachineOperation::find($id);
        $machine_opration->update($input);
        return redirect()->route('machine_opration.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = MachineOperation::find($id);
        $data->delete();
        return redirect()->route('machine_opration.index')->with('success','Data Deleted Successfully');
    }

}
