<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use App\Models\PartCategory;
use App\Models\PartEntry;
use App\Models\PartTypeCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class PartEntryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        
         $this->middleware('permission:part_entry-list|part_entry-create|part_entry-edit|part_entry-delete', ['only' => ['index','store']]);
         $this->middleware('permission:part_entry-create', ['only' => ['create','store']]);
         $this->middleware('permission:part_entry-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:part_entry-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $part_entry=PartEntry::orderBy('id','desc')->paginate(10);
        return view('part_entry.index',compact('part_entry'))
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        $part_category=PartCategory::all();
        $part_type_category=PartTypeCategory::all();
        $customer=Customer::all();
        return view('part_entry.create',compact('part_category','part_type_category','customer'));
    }
    public function store(Request $request)
    {
        $input = $request->all();

        PartEntry::create($input);

        return redirect()->route('part_entry.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $part_entry=PartEntry::find($id);
        $part_category=PartCategory::all();
        $part_type_category=PartTypeCategory::all();
        $customer=Customer::all();
        return view('part_entry.edit',compact('part_entry','part_category','part_type_category','customer'));
    }
    public function update(Request $request,$id)
    {
        $input = $request->all();
       
        $part_entry = PartEntry::find($id);
        $part_entry->update($input);
        return redirect()->route('part_entry.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = PartEntry::find($id);
        $data->delete();
        return redirect()->route('part_entry.index')->with('success','Data Deleted Successfully');
    }

}
