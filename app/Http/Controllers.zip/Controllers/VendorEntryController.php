<?php

namespace App\Http\Controllers;

use App\Models\InsertEntry;
use App\Models\VendorEntry;
use App\Models\VendorCategory;
use Illuminate\View\View;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Spatie\Permission\Contracts\Role;

class VendorEntryController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:vendor_entry-list|vendor_entry-create|vendor_entry-edit|vendor_entry-delete', ['only' => ['index','store']]);
         $this->middleware('permission:vendor_entry-create', ['only' => ['create','store']]);
         $this->middleware('permission:vendor_entry-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:vendor_entry-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request): View
    {
        $data = VendorEntry::latest()->paginate(10);        
        return view('vendor_entry.index',compact('data'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {  
        $VendorCate = InsertEntry::pluck('name','id')->all(); // vendor category
        return view('vendor_entry.create',compact('VendorCate'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {    
        try { 
            $VendorEntry = New VendorEntry;
            $VendorEntry->vendor_name = $request->vendor_name;
            $VendorEntry->vendor_category_id = $request->vendor_category_id;
            $VendorEntry->contact_person = $request->contact_person;
            $VendorEntry->mobile_number = $request->mobile_number;
            $VendorEntry->status = $request->status;
            $VendorEntry->save();
        
            return redirect()->route('vendor_entry.index')
                            ->with('success','Data Saved Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $VendorEntry = VendorEntry::find($id);    
        $VendorCate = InsertEntry::pluck('name','id')->all(); // vendor category
        $SelectedVendorCate = InsertEntry::where('id',$VendorEntry->vendor_category_id)->pluck('id')->first(); // vendor category
        return view('vendor_entry.edit',compact('VendorEntry','VendorCate','SelectedVendorCate'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try { 

            $VendorEntry = VendorEntry::find($id);
            $VendorEntry->vendor_name = $request->vendor_name;
            $VendorEntry->vendor_category_id = $request->vendor_category_id;
            $VendorEntry->contact_person = $request->contact_person;
            $VendorEntry->mobile_number = $request->mobile_number;
            $VendorEntry->status = $request->status;
            $VendorEntry->save();
        
            return redirect()->route('vendor_entry.index')
                            ->with('success','Data Saved Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
             
            VendorEntry::find($id)->delete();
            return redirect()->route('vendor_entry.index')
                            ->with('success','Data Deleted Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
}
