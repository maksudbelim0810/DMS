<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\PartCategory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class PartCategoryController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        
         $this->middleware('permission:part_category-list|part_category-create|part_category-edit|part_category-delete', ['only' => ['index','store']]);
         $this->middleware('permission:part_category-create', ['only' => ['create','store']]);
         $this->middleware('permission:part_category-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:part_category-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $part_category=PartCategory::orderBy('id','desc')->paginate(10);
        return view('part_category.index',compact('part_category'))
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        return view('part_category.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'part_category' => 'required|unique:part_categories',
        ]);
        $input = $request->all();

        PartCategory::create($input);

        return redirect()->route('part_category.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $part_category=PartCategory::find($id);
        return view('part_category.edit',compact('part_category'));
    }
    public function update(Request $request,$id)
    {
        $request->validate([
            'part_category' => 'required',
        ]);
        
        $input = $request->all();
       
        $part_category = PartCategory::find($id);
        $part_category->update($input);
        return redirect()->route('part_category.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = PartCategory::find($id);
        $data->delete();
        return redirect()->route('part_category.index')->with('success','Data Deleted Successfully');
    }

}
