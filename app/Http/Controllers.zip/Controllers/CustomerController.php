<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Facades\Validator;
use Yajra\DataTables\DataTables;

class CustomerController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
      
         $this->middleware('permission:customer-list|customer-create|customer-edit|customer-delete', ['only' => ['index','store']]);
         $this->middleware('permission:customer-create', ['only' => ['create','store']]);
         $this->middleware('permission:customer-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:customer-delete', ['only' => ['destroy']]);
    
    }
    public function index(Request $request)
    {
        $customer=Customer::orderBy('id','desc')->paginate(10);
        return view('customer.index',compact('customer'))
        ->with('i', ($request->input('page', 1) - 1) * 5);
    }
    public function create()
    {
        return view('customer.create');
    }
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|unique:customers',
            'phone' => 'required|unique:customers',
        ]);
        $input = $request->all();

        Customer::create($input);

        return redirect()->route('customer.index')->with('success','Data Saved Successfully');
    }
    public function edit($id)
    {
        $customer=Customer::find($id);
        return view('customer.edit',compact('customer'));
    }
    public function update(Request $request,$id)
    {
        $request->validate([
            'name' => 'required',
            'phone' => 'required',
        ]);
        
        $input = $request->all();
       
        $customer = Customer::find($id);
        $customer->update($input);
        return redirect()->route('customer.index')->with('success','Data Saved Successfully');
    }
    public function destroy($id)
    {
        $data = Customer::find($id);
        $data->delete();
        return redirect()->route('customer.index')->with('success','Data Deleted Successfully');
    }

}
