<?php

namespace App\Http\Controllers;

use App\Models\ShiftEntry;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;

class ShiftEntryController extends Controller
{
    function __construct()
    {
         $this->middleware('permission:shift_entry-list|shift_entry-create|shift_entry-edit|shift_entry-delete', ['only' => ['index','store']]);
         $this->middleware('permission:shift_entry-create', ['only' => ['create','store']]);
         $this->middleware('permission:shift_entry-edit', ['only' => ['edit','update']]);
         $this->middleware('permission:shift_entry-delete', ['only' => ['destroy']]);
    }
    public function index(Request $request)
    {
        $data = ShiftEntry::latest()->paginate(10);
  
        return view('shift_entry.index',compact('data'))
            ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {  
        return view('shift_entry.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {    
        try { 
            $ShiftEntry = New ShiftEntry;
            $ShiftEntry->shift_name = $request->shift_name;
            $ShiftEntry->shift_duration = $request->shift_duration;
            $ShiftEntry->insert_change = $request->insert_change;
            $ShiftEntry->lunch_recess = $request->lunch_recess;
            $ShiftEntry->save();
        
            return redirect()->route('shift_entry.index')
                            ->with('success','Data Saved Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $ShiftEntry = ShiftEntry::find($id);    
        return view('shift_entry.edit',compact('ShiftEntry'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        try { 

            $ShiftEntry = ShiftEntry::find($id);
            $ShiftEntry->shift_name = $request->shift_name;
            $ShiftEntry->shift_duration = $request->shift_duration;
            $ShiftEntry->insert_change = $request->insert_change;
            $ShiftEntry->lunch_recess = $request->lunch_recess;
            $ShiftEntry->save();
        
            return redirect()->route('shift_entry.index')
                            ->with('success','Data Saved Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
    
    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        try {
             
            ShiftEntry::find($id)->delete();
            return redirect()->route('shift_entry.index')
                            ->with('success','Data Deleted Successfully');

        } catch(\Exception $e){
            return Redirect::back()->withErrors(['msg' => $e->getMessage()]);
        };
    }
}
