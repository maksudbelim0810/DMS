<?php

namespace App\Http\Controllers;

use App\Models\BatchNumber;
use App\Models\CncProduction;
use App\Models\DispatchAdvice;
use App\Models\EmployeeBioData;
use App\Models\GradeSortingReport;
use App\Models\InsertConsumptionEntry;
use App\Models\Location;
use App\Models\MachineEntry;
use App\Models\MPIProduction;
use App\Models\RejectionDisposition;
use App\Models\Setup;
use App\Models\ShiftEntry;
use App\Models\VisualPacking;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use PDF;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index(Request $request)
    {
        $batch_no = isset($_GET['batch_no']) ? $_GET['batch_no'] : '';
        $mc_no = isset($_GET['mc_no']) ? $_GET['mc_no'] : '';
        $shift = isset($_GET['shift']) ? $_GET['shift'] : '';
        $setup = isset($_GET['setup']) ? $_GET['setup'] : '';
        $part_name = isset($_GET['part_name']) ? $_GET['part_name'] : '';
        $customer = isset($_GET['customer']) ? $_GET['customer'] : '';
        $cycle_time = isset($_GET['cycle_time']) ? $_GET['cycle_time'] : '';
        $total_rejection = isset($_GET['total_rejection']) ? $_GET['total_rejection'] : '';
        $no_opration = isset($_GET['no_opration']) ? $_GET['no_opration'] : '';
        $no_power = isset($_GET['no_power']) ? $_GET['no_power'] : '';
        $job_setting = isset($_GET['job_setting']) ? $_GET['job_setting'] : '';
        $job_fault = isset($_GET['job_fault']) ? $_GET['job_fault'] : '';
        $no_load = isset($_GET['no_load']) ? $_GET['no_load'] : '';
        $operator_name = isset($_GET['operator_name']) ? $_GET['operator_name'] : '';
        $start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
        $end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';
        $ok_qty = isset($_GET['ok_qty']) ? $_GET['ok_qty'] : '';
        $mpi_operator_name = isset($_GET['mpi_operator_name']) ? $_GET['mpi_operator_name'] : '';
        $mpi_mc_no = isset($_GET['mpi_mc_no']) ? $_GET['mpi_mc_no'] : '';
        $insert_name = isset($_GET['insert_name']) ? $_GET['insert_name'] : '';
        $insert_rate_rs = isset($_GET['insert_rate_rs']) ? $_GET['insert_rate_rs'] : '';
        $location = isset($_GET['location']) ? $_GET['location'] : '';
        $visual_inspected_qty = isset($_GET['visual_inspected_qty']) ? $_GET['visual_inspected_qty'] : '';
        $inspected_qty = isset($_GET['inspected_qty']) ? $_GET['inspected_qty'] : '';
        $packed_qty = isset($_GET['packed_qty']) ? $_GET['packed_qty'] : '';
        $box_qty = isset($_GET['box_qty']) ? $_GET['box_qty'] : '';
        $grade_mc_no = isset($_GET['grade_mc_no']) ? $_GET['grade_mc_no'] : '';
        $inspectors = isset($_GET['inspectors']) ? $_GET['inspectors'] : '';
        $checked_qty = isset($_GET['checked_qty']) ? $_GET['checked_qty'] : '';



        $data['batch_no'] = $batch_no;
        $data['mc_no'] = $mc_no;
        $data['shift'] = $shift;
        $data['setup'] = $setup;
        $data['part_name'] = $part_name;
        $data['customer'] = $customer;
        $data['cycle_time'] = $cycle_time;
        $data['total_rejection'] = $total_rejection;
        $data['no_opration'] = $no_opration;
        $data['no_power'] = $no_power;
        $data['job_setting'] = $job_setting;
        $data['job_fault'] = $job_fault;
        $data['no_load'] = $no_load;
        $data['operator_name'] = $operator_name;
        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $data['ok_qty'] = $ok_qty;
        $data['mpi_operator_name'] = $mpi_operator_name;
        $data['mpi_mc_no'] = $mpi_mc_no;
        $data['insert_name'] = $insert_name;
        $data['insert_rate_rs'] = $insert_rate_rs;
        $data['grade_mc_no'] = $grade_mc_no;
        $data['inspectors'] = $inspectors;
        $data['checked_qty'] = $checked_qty;
        $data['location'] = $location;
        $data['visual_inspected_qty'] = $visual_inspected_qty;
        $data['inspected_qty'] = $inspected_qty;
        $data['packed_qty'] = $packed_qty;
        $data['box_qty'] = $box_qty;

        $mc_no = MachineEntry::where('machine_department', 'like', '%Machining%')->orWhere('machine_department', 'like', '%CNC%')->get();
        $mpi_mc_no =  MachineEntry::where('machine_department', 'LIKE', '%MPI%')->get();
        $shift = ShiftEntry::all();
        $location = Location::all();
        $setup = Setup::all();
        $operator_name = EmployeeBioData::where('Oemcname', 'CNC OPERATOR')->get();
        $mpi_operator_name = EmployeeBioData::where('Oemcname', 'MPI OPERATOR')->get();
        $inspectors = EmployeeBioData::where('Oemcname', 'LIKE', '%GRADE SORTING%')->get();
        $grade_mc_no = MachineEntry::where('machine_department', 'like', '%Grade Sorting%')->get();
        return view('adminHome', compact('data', 'mc_no', 'shift', 'setup', 'operator_name', 'mpi_operator_name', 'mpi_mc_no', 'location', 'inspectors', 'grade_mc_no'));

        // return view('adminHome');
    }
    public function getDataFilter(Request $request)
    {
        $return_data = [];

        $transaction = isset($_POST['transaction']) ? $_POST['transaction'] : [];

        $checked_value = isset($_POST['checked_value']) ? $_POST['checked_value'] : [];
        $batch_no = isset($_POST['batch_no']) ? $_POST['batch_no'] : '';
        $mc_no = isset($_POST['mc_no']) ? $_POST['mc_no'] : '';
        $shift = isset($_POST['shift']) ? $_POST['shift'] : '';
        $setup = isset($_POST['setup']) ? $_POST['setup'] : '';
        $part_name = isset($_POST['part_name']) ? $_POST['part_name'] : '';
        $customer = isset($_POST['customer']) ? $_POST['customer'] : '';
        $cycle_time = isset($_POST['cycle_time']) ? $_POST['cycle_time'] : '';
        $total_rejection = isset($_POST['total_rejection']) ? $_POST['total_rejection'] : '';
        $no_opration = isset($_POST['no_opration']) ? $_POST['no_opration'] : '';
        $no_power = isset($_POST['no_power']) ? $_POST['no_power'] : '';
        $job_setting = isset($_POST['job_setting']) ? $_POST['job_setting'] : '';
        $job_fault = isset($_POST['job_fault']) ? $_POST['job_fault'] : '';
        $no_load = isset($_POST['no_load']) ? $_POST['no_load'] : '';
        $operator_name = isset($_POST['operator_name']) ? $_POST['operator_name'] : '';
        $start_date = isset($_POST['start_date']) ? $_POST['start_date'] : '';
        $end_date = isset($_POST['end_date']) ? $_POST['end_date'] : '';
        $mpi_operator_name = isset($_GET['mpi_operator_name']) ? $_GET['mpi_operator_name'] : '';
        $mpi_mc_no = isset($_GET['mpi_mc_no']) ? $_GET['mpi_mc_no'] : '';
        $ok_qty = isset($_GET['ok_qty']) ? $_GET['ok_qty'] : '';
        $insert_name = isset($_GET['insert_name']) ? $_GET['insert_name'] : '';
        $insert_rate_rs = isset($_GET['insert_rate_rs']) ? $_GET['insert_rate_rs'] : '';
        $location = isset($_GET['location']) ? $_GET['location'] : '';
        $visual_inspected_qty = isset($_GET['visual_inspected_qty']) ? $_GET['visual_inspected_qty'] : '';
        $inspected_qty = isset($_GET['inspected_qty']) ? $_GET['inspected_qty'] : '';
        $packed_qty = isset($_GET['packed_qty']) ? $_GET['packed_qty'] : '';
        $box_qty = isset($_GET['box_qty']) ? $_GET['box_qty'] : '';
        $grade_mc_no = isset($_GET['grade_mc_no']) ? $_GET['grade_mc_no'] : '';
        $inspectors = isset($_GET['inspectors']) ? $_GET['inspectors'] : '';
        $checked_qty = isset($_GET['checked_qty']) ? $_GET['checked_qty'] : '';

        if ($transaction == 'CNC Production') {

            $cnc_production = CncProduction::orderBy('id', 'desc');
            if (!empty($batch_no) && in_array('batch_no', $checked_value)) {
                $cnc_production->where('batch_no', 'like', '%' . $batch_no . '%');
            }
            if (!empty($mc_no) && in_array('mc_no', $checked_value)) {
                $cnc_production->where('mc_no', 'like', '%' . $mc_no . '%');
            }
            if (!empty($shift) && in_array('shift', $checked_value)) {
                $cnc_production->where('shift', 'like', '%' . $shift . '%');
            }
            if (!empty($setup) && in_array('setup', $checked_value)) {
                $cnc_production->where('setup', 'like', '%' . $setup . '%');
            }
            if (!empty($part_name) && in_array('part_name', $checked_value)) {
                $cnc_production->where('part_name', 'like', '%' . $part_name . '%');
            }
            if (!empty($customer) && in_array('customer', $checked_value)) {
                $cnc_production->where('customer', 'like', '%' . $customer . '%');
            }
            if (!empty($cycle_time) && in_array('cycle_time', $checked_value)) {
                $cnc_production->where('cycle_time', 'like', '%' . $cycle_time . '%');
            }
            if (!empty($total_rejection) && in_array('total_rejection', $checked_value)) {
                $cnc_production->where('total_rejection', 'like', '%' . $total_rejection . '%');
            }
            if (!empty($no_opration) && in_array('no_opration', $checked_value)) {
                $cnc_production->where('no_opration', 'like', '%' . $no_opration . '%');
            }
            if (!empty($no_power) && in_array('no_power', $checked_value)) {
                $cnc_production->where('no_power', 'like', '%' . $no_power . '%');
            }
            if (!empty($job_setting) && in_array('job_setting', $checked_value)) {
                $cnc_production->where('job_setting', 'like', '%' . $job_setting . '%');
            }
            if (!empty($job_fault) && in_array('job_fault', $checked_value)) {
                $cnc_production->where('job_fault', 'like', '%' . $job_fault . '%');
            }
            if (!empty($no_load) && in_array('no_load', $checked_value)) {
                $cnc_production->where('no_load', 'like', '%' . $no_load . '%');
            }
            if (!empty($operator_name) && in_array('operator_name', $checked_value)) {
                $cnc_production->where('operator_name', 'like', '%' . $operator_name . '%');
            }
            if (!empty($start_date && $end_date) && in_array('start_date', $checked_value) && in_array('end_date', $checked_value)) {
                $cnc_production->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
            }
        }
        if ($transaction == 'Dispatch Advice') {

            $dispatch_advice = DispatchAdvice::orderBy('id', 'desc');
            if (!empty($batch_no)) {
                $dispatch_advice->where('batch_no', 'like', '%' . $batch_no . '%');
            }
            if (!empty($part_name)) {
                $dispatch_advice->where('part_name', 'like', '%' . $part_name . '%');
            }
            if (!empty($customer)) {
                $dispatch_advice->where('customer', 'like', '%' . $customer . '%');
            }
            if (!empty($ok_qty)) {
                $dispatch_advice->where('ok_qty', 'like', '%' . $ok_qty . '%');
            }
            if (!empty($start_date && $end_date)) {
                $dispatch_advice->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
            }
        }
        if ($transaction == 'MPI Production') {

            $mpi_production = MPIProduction::orderBy('id', 'desc');
            if (!empty($batch_no)) {
                $mpi_production->where('batch_number_id', 'like', '%' . $batch_no . '%');
            }
            if (!empty($part_name)) {
                $mpi_production->where('part_name', 'like', '%' . $part_name . '%');
            }
            if (!empty($customer)) {
                $mpi_production->where('customer', 'like', '%' . $customer . '%');
            }
            if (!empty($mpi_mc_no)) {
                $mpi_production->where('mc_no', 'like', '%' . $mpi_mc_no . '%');
            }
            if (!empty($shift)) {
                $mpi_production->where('shift', 'like', '%' . $shift . '%');
            }
            if (!empty($inspected_qty)) {
                $mpi_production->where('inspected_qty', 'like', '%' . $inspected_qty . '%');
            }
            if (!empty($rejected_qty)) {
                $mpi_production->where('rejected_qty', 'like', '%' . $rejected_qty . '%');
            }
            if (!empty($mpi_operator_name)) {
                $mpi_production->where('operator_name', 'like', '%' . $mpi_operator_name . '%');
            }
            if (!empty($ok_qty)) {
                $mpi_production->where('ok_qty', 'like', '%' . $ok_qty . '%');
            }
            if (!empty($start_date && $end_date)) {
                $mpi_production->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
            }
        }
        if ($transaction == 'Insert Counsuption Entry') {

            $insert_consumption_entry = InsertConsumptionEntry::orderBy('id', 'desc');
            if (!empty($batch_no)) {
                $insert_consumption_entry->where('batch_no', 'like', '%' . $batch_no . '%');
            }
            if (!empty($part_name)) {

                $insert_consumption_entry->where('part_name', 'like', '%' . $part_name . '%');
            }
            if (!empty($customer_name)) {
                $insert_consumption_entry->where('customer_name', 'like', '%' . $customer_name . '%');
            }
            if (!empty($mc_no)) {
                $insert_consumption_entry->where('mc_no', 'like', '%' . $mc_no . '%');
            }
            if (!empty($insert_name)) {
                $insert_consumption_entry->where('insert_name', 'like', '%' . $insert_name . '%');
            }
            if (!empty($insert_rate_rs)) {
                $insert_consumption_entry->where('insert_rate_rs', 'like', '%' . $insert_rate_rs . '%');
            }
            if (!empty($start_date && $end_date)) {
                $insert_consumption_entry->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
            }
        }
        if ($transaction == 'Rejection Disposition') {

            $rejection_disposition = RejectionDisposition::orderBy('id', 'desc');
            if (!empty($batch_no)) {
                $rejection_disposition->where('batch_number_id', 'like', '%' . $batch_no . '%');
            }
            if (!empty($part_name)) {
                $rejection_disposition->where('part_name', 'like', '%' . $part_name . '%');
            }
            if (!empty($customer)) {
                $rejection_disposition->where('customer', 'like', '%' . $customer . '%');
            }
            if (!empty($start_date && $end_date)) {
                $rejection_disposition->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
            }
        }
        if ($transaction == 'Visual & Packing') {

            $visual_packing = VisualPacking::orderBy('id', 'desc');
            if (!empty($batch_no)) {
                $visual_packing->where('batch_no', 'like', '%' . $batch_no . '%');
            }

            if (!empty($shift)) {
                $visual_packing->where('shift', 'like', '%' . $shift . '%');
            }
            if (!empty($part_name)) {
                $visual_packing->where('part_name', 'like', '%' . $part_name . '%');
            }
            if (!empty($customer)) {
                $visual_packing->where('customer', 'like', '%' . $customer . '%');
            }
            if (!empty($location)) {
                $visual_packing->where('location', 'like', '%' . $location . '%');
            }
            if (!empty($packed_qty)) {
                $visual_packing->where('packed_qty', 'like', '%' . $packed_qty . '%');
            }
            if (!empty($box_qty)) {
                $visual_packing->where('box_qty', 'like', '%' . $box_qty . '%');
            }
            if (!empty($visual_inspected_qty)) {
                $visual_packing->where('visual_inspected_qty', 'like', '%' . $visual_inspected_qty . '%');
            }
            if (!empty($total_rejection)) {
                $visual_packing->where('total_rejection', 'like', '%' . $total_rejection . '%');
            }
            if (!empty($start_date && $end_date)) {
                $visual_packing->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
            }
        }
        if ($transaction == 'Grade Sorting Report') {

            $grade_sorting_report = GradeSortingReport::orderBy('id', 'desc');
            if (!empty($batch_no)) {
                $grade_sorting_report->where('batch_no', 'like', '%' . $batch_no . '%');
            }
            if (!empty($part_no_and_name)) {
                $grade_sorting_report->where('part_no_and_name', 'like', '%' . $part_no_and_name . '%');
            }
            if (!empty($customer)) {
                $grade_sorting_report->where('customer', 'like', '%' . $customer . '%');
            }
            if (!empty($grade_mc_no)) {
                $grade_sorting_report->where('mc_no', 'like', '%' . $grade_mc_no . '%');
            }
            if (!empty($shift)) {
                $grade_sorting_report->where('shift', 'like', '%' . $shift . '%');
            }
            if (!empty($checked_qty)) {
                $grade_sorting_report->where('checked_qty', 'like', '%' . $checked_qty . '%');
            }
            if (!empty($suspected_rej_qty)) {
                $grade_sorting_report->where('suspected_rej_qty', 'like', '%' . $suspected_rej_qty . '%');
            }
            if (!empty($inspectors)) {
                $grade_sorting_report->where('inspectors', 'like', '%' . $inspectors . '%');
            }
            if (!empty($ok_qty)) {
                $grade_sorting_report->where('ok_qty', 'like', '%' . $ok_qty . '%');
            }
            if (!empty($start_date && $end_date)) {
                $grade_sorting_report->whereBetween('date', [date('m/d/Y', strtotime($start_date)), date('m/d/Y', strtotime($end_date))]);
            }
        }
        $data['batch_no'] = $batch_no;
        $data['mc_no'] = $mc_no;
        $data['shift'] = $shift;
        $data['setup'] = $setup;
        $data['part_name'] = $part_name;
        $data['customer'] = $customer;
        $data['cycle_time'] = $cycle_time;
        $data['total_rejection'] = $total_rejection;
        $data['no_opration'] = $no_opration;
        $data['no_power'] = $no_power;
        $data['job_setting'] = $job_setting;
        $data['job_fault'] = $job_fault;
        $data['no_load'] = $no_load;
        $data['operator_name'] = $operator_name;
        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $data['ok_qty'] = $ok_qty;
        $data['mpi_operator_name'] = $mpi_operator_name;
        $data['mpi_mc_no'] = $mpi_mc_no;
        $data['insert_name'] = $insert_name;
        $data['insert_rate_rs'] = $insert_rate_rs;
        $data['grade_mc_no'] = $grade_mc_no;
        $data['inspectors'] = $inspectors;
        $data['checked_qty'] = $checked_qty;
        $data['location'] = $location;
        $data['visual_inspected_qty'] = $visual_inspected_qty;
        $data['inspected_qty'] = $inspected_qty;
        $data['packed_qty'] = $packed_qty;
        $data['box_qty'] = $box_qty;

        if ($transaction == 'CNC Production') {
            $cnc_production = $cnc_production->get();
        }
        if ($transaction == 'Dispatch Advice') {
            $dispatch_advice = $dispatch_advice->get();
        }
        if ($transaction == 'MPI Production') {
            $mpi_production = $mpi_production->get();
        }
        if ($transaction == 'Insert Counsuption Entry') {
            $insert_consumption_entry = $insert_consumption_entry->get();
        }
        if ($transaction == 'Rejection Disposition') {
            $rejection_disposition = $rejection_disposition->get();
        }
        if ($transaction == 'Visual & Packing') {
            $visual_packing = $visual_packing->get();
        }
        if ($transaction == 'Grade Sorting Report') {
            $grade_sorting_report = $grade_sorting_report->get();
        }
        // $style = '<link href="https://cdn.datatables.net/1.13.7/css/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
        // <link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.4.2/css/buttons.dataTables.min.css" type="text/css" />';
        // $html = $style;
        $html = '<table class="table table-bordered display" id="cnc">';
        $html .= '<thead><tr>';
        if (in_array('batch_no', $checked_value)) {
            $html .= '<th>Batch No</th>';
        }
        if (in_array('mc_no', $checked_value)) {
            $html .= '<th>MC No</th>';
        }
        if (in_array('shift', $checked_value)) {
            $html .= '<th>Shift</th>';
        }
        if (in_array('setup', $checked_value)) {
            $html .= '<th>Setup</th>';
        }
        if (in_array('part_name', $checked_value)) {
            $html .= '<th>Part Name</th>';
        }
        if (in_array('customer', $checked_value)) {
            $html .= '<th>Customer</th>';
        }
        if (in_array('cycle_time', $checked_value)) {
            $html .= '<th>Cycle Time</th>';
        }
        if (in_array('total_rejection', $checked_value)) {
            $html .= '<th>Total Rejection</th>';
        }
        if (in_array('no_opration', $checked_value)) {
            $html .= '<th>No Opration</th>';
        }
        if (in_array('no_power', $checked_value)) {
            $html .= '<th>No Power</th>';
        }
        if (in_array('job_setting', $checked_value)) {
            $html .= '<th>Job Setting</th>';
        }
        if (in_array('job_fault', $checked_value)) {
            $html .= '<th>Job Fault</th>';
        }
        if (in_array('no_load', $checked_value)) {
            $html .= '<th>No Load</th>';
        }
        if (in_array('operator_name', $checked_value)) {
            $html .= '<th>Operator Name</th>';
        }
        if (in_array('start_date', $checked_value)) {
            $html .= '<th>Start Date</th>';
        }
        if (in_array('end_date', $checked_value)) {
            $html .= '<th>End Date</th>';
        }
        if (in_array('ok_qty', $checked_value)) {
            $html .= '<th>OK Qty</th>';
        }
        if (in_array('mpi_operator_name', $checked_value)) {
            $html .= '<th>Mpi Operator Name</th>';
        }
        if (in_array('mpi_mc_no', $checked_value)) {
            $html .= '<th>Mpi Mc No</th>';
        }
        if (in_array('insert_name', $checked_value)) {
            $html .= '<th>Insert Name</th>';
        }
        if (in_array('insert_rate_rs', $checked_value)) {
            $html .= '<th>Insert Rate Rs</th>';
        }
        if (in_array('grade_mc_no', $checked_value)) {
            $html .= '<th>Grade Mc No</th>';
        }
        if (in_array('inspectors', $checked_value)) {
            $html .= '<th>Inspectors</th>';
        }
        if (in_array('checked_qty', $checked_value)) {
            $html .= '<th>Checked Qty</th>';
        }
        if (in_array('location', $checked_value)) {
            $html .= '<th>Location</th>';
        }
        if (in_array('visual_inspected_qty', $checked_value)) {
            $html .= '<th>Visual Inspected Qty</th>';
        }
        if (in_array('inspected_qty', $checked_value)) {
            $html .= '<th>Inspected Qty</th>';
        }
        if (in_array('packed_qty', $checked_value)) {
            $html .= '<th>Packed Qty</th>';
        }
        if (in_array('box_qty', $checked_value)) {
            $html .= '<th>Box Qty</th>';
        }
        $html .= '</tr></thead>';

        $html .= '<tbody>';
        if ($transaction == 'CNC Production') {
            foreach ($cnc_production as $val) {
                $html .= '<tr>';
                if (in_array('batch_no', $checked_value)) {
                    $html .= '<td>' . $val->batch_no . '</td>';
                }
                if (in_array('mc_no', $checked_value)) {
                    $html .= '<td>' . $val->mc_no . '</td>';
                }
                if (in_array('shift', $checked_value)) {
                    $html .= ' <td>' . $val->shift . '</td>';
                }
                if (in_array('setup', $checked_value)) {
                    $html .= '<td>' . $val->setup . '</td>';
                }
                if (in_array('part_name', $checked_value)) {
                    $html .= '<td>' . $val->part_name . '</td>';
                }
                if (in_array('customer', $checked_value)) {
                    $html .= '<td>' . $val->customer . '</td>';
                }
                if (in_array('cycle_time', $checked_value)) {
                    $html .= '<td>' . $val->cycle_time . '</td>';
                }
                if (in_array('total_rejection', $checked_value)) {
                    $html .= '<td>' . $val->total_rejection . '</td>';
                }
                if (in_array('no_opration', $checked_value)) {
                    $html .= '<td>' . $val->no_opration . '</td>';
                }
                if (in_array('no_power', $checked_value)) {
                    $html .= ' <td>' . $val->no_power . '</td>';
                }
                if (in_array('job_setting', $checked_value)) {
                    $html .= '<td>' . $val->job_setting . '</td>';
                }
                if (in_array('job_fault', $checked_value)) {
                    $html .= '<td>' . $val->job_fault . '</td>';
                }
                if (in_array('no_load', $checked_value)) {
                    $html .= '<td>' . $val->no_load . '</td>';
                }
                if (in_array('operator_name', $checked_value)) {
                    $html .= '<td>' . $val->operator_name . '</td>';
                }
                if (in_array('start_date', $checked_value)) {
                    $html .= '<td>' . $val->start_date . '</td>';
                }
                if (in_array('end_date', $checked_value)) {
                    $html .= '<td>' . $val->end_date . '</td>';
                }
                $html .= '</tr>';
            }
        }
        if ($transaction == 'Dispatch Advice') {
            foreach ($dispatch_advice as $val) {
                $html .= '<tr>';
                if (in_array('batch_no', $checked_value)) {
                    $html .= '<td>' . $val->batch_no . '</td>';
                }
                if (in_array('part_name', $checked_value)) {
                    $html .= '<td>' . $val->part_name . '</td>';
                }
                if (in_array('customer', $checked_value)) {
                    $html .= '<td>' . $val->customer . '</td>';
                }
                if (in_array('start_date', $checked_value)) {
                    $html .= '<td>' . $val->start_date . '</td>';
                }
                if (in_array('end_date', $checked_value)) {
                    $html .= '<td>' . $val->end_date . '</td>';
                }
                $html .= '</tr>';
            }
        }
        if ($transaction == 'MPI Production') {
            foreach ($mpi_production as $val) {
                $html .= '<tr>';
                if (in_array('batch_no', $checked_value)) {
                    $html .= '<td>' . $val->batch_number_id . '</td>';
                }
                if (in_array('part_name', $checked_value)) {
                    $html .= '<td>' . $val->part_name . '</td>';
                }
                if (in_array('customer', $checked_value)) {
                    $html .= '<td>' . $val->customer . '</td>';
                }
                if (in_array('start_date', $checked_value)) {
                    $html .= '<td>' . $val->start_date . '</td>';
                }
                if (in_array('end_date', $checked_value)) {
                    $html .= '<td>' . $val->end_date . '</td>';
                }
                if (in_array('mpi_mc_no', $checked_value)) {
                    $html .= '<td>' . $val->mc_no . '</td>';
                }
                if (in_array('mpi_operator_name', $checked_value)) {
                    $html .= ' <td>' . $val->operator_name . '</td>';
                }
                if (in_array('inspected_qty', $checked_value)) {
                    $html .= ' <td>' . $val->inspected_qty . '</td>';
                }
                $html .= '</tr>';
            }
        }
        if ($transaction == 'Insert Counsuption Entry') {
            foreach ($insert_consumption_entry as $val) {
                $html .= '<tr>';
                if (in_array('batch_no', $checked_value)) {
                    $html .= '<td>' . $val->batch_no . '</td>';
                }
                if (in_array('part_name', $checked_value)) {
                    $html .= '<td>' . $val->part_name . '</td>';
                }
                if (in_array('customer', $checked_value)) {
                    $html .= '<td>' . $val->customer . '</td>';
                }
                if (in_array('start_date', $checked_value)) {
                    $html .= '<td>' . $val->start_date . '</td>';
                }
                if (in_array('end_date', $checked_value)) {
                    $html .= '<td>' . $val->end_date . '</td>';
                }
                if (in_array('mc_no', $checked_value)) {
                    $html .= '<td>' . $val->mc_no . '</td>';
                }
                if (in_array('insert_name', $checked_value)) {
                    $html .= '<td>' . $val->insert_name . '</td>';
                }
                if (in_array('insert_rate_rs', $checked_value)) {
                    $html .= '<td>' . $val->insert_rate_rs . '</td>';
                }
                $html .= '</tr>';
            }
        }
        if ($transaction == 'Rejection Disposition') {
            foreach ($rejection_disposition as $val) {
                $html .= '<tr>';
                if (in_array('batch_no', $checked_value)) {
                    $html .= '<td>' . $val->batch_no . '</td>';
                }
                if (in_array('part_name', $checked_value)) {
                    $html .= '<td>' . $val->part_name . '</td>';
                }
                if (in_array('customer', $checked_value)) {
                    $html .= '<td>' . $val->customer . '</td>';
                }
                if (in_array('start_date', $checked_value)) {
                    $html .= '<td>' . $val->start_date . '</td>';
                }
                if (in_array('end_date', $checked_value)) {
                    $html .= '<td>' . $val->end_date . '</td>';
                }
                $html .= '</tr>';
            }
        }
        if ($transaction == 'Visual & Packing') {
            foreach ($visual_packing as $val) {
                $html .= '<tr>';
                if (in_array('batch_no', $checked_value)) {
                    $html .= '<td>' . $val->batch_no . '</td>';
                }
                if (in_array('part_name', $checked_value)) {
                    $html .= '<td>' . $val->part_name . '</td>';
                }
                if (in_array('customer', $checked_value)) {
                    $html .= '<td>' . $val->customer . '</td>';
                }
                if (in_array('start_date', $checked_value)) {
                    $html .= '<td>' . $val->start_date . '</td>';
                }
                if (in_array('end_date', $checked_value)) {
                    $html .= '<td>' . $val->end_date . '</td>';
                }
                if (in_array('location', $checked_value)) {
                    $html .= '<td>' . $val->location . '</td>';
                }
                if (in_array('packed_qty', $checked_value)) {
                    $html .= '<td>' . $val->packed_qty . '</td>';
                }
                if (in_array('box_qty', $checked_value)) {
                    $html .= '<td>' . $val->box_qty . '</td>';
                }
                if (in_array('visual_inspected_qty', $checked_value)) {
                    $html .= '<td>' . $val->visual_inspected_qty . '</td>';
                }
                if (in_array('total_rejection', $checked_value)) {
                    $html .= '<td>' . $val->total_rejection . '</td>';
                }
                $html .= '</tr>';
            }
        }
        if ($transaction == 'Grade Sorting Report') {
            foreach ($grade_sorting_report as $val) {
                $html .= '<tr>';
                if (in_array('batch_no', $checked_value)) {
                    $html .= '<td>' . $val->batch_no . '</td>';
                }
                if (in_array('part_name', $checked_value)) {
                    $html .= '<td>' . $val->part_no_and_name . '</td>';
                }
                if (in_array('customer', $checked_value)) {
                    $html .= '<td>' . $val->customer . '</td>';
                }
                if (in_array('start_date', $checked_value)) {
                    $html .= '<td>' . $val->start_date . '</td>';
                }
                if (in_array('end_date', $checked_value)) {
                    $html .= '<td>' . $val->end_date . '</td>';
                }
                if (in_array('grade_mc_no', $checked_value)) {
                    $html .= '<td>' . $val->mc_no . '</td>';
                }
                if (in_array('shift', $checked_value)) {
                    $html .= '<td>' . $val->shift . '</td>';
                }
                if (in_array('checked_qty', $checked_value)) {
                    $html .= '<td>' . $val->checked_qty . '</td>';
                }
                if (in_array('suspected_rej_qty', $checked_value)) {
                    $html .= '<td>' . $val->suspected_rej_qty . '</td>';
                }
                if (in_array('inspectors', $checked_value)) {
                    $html .= '<td>' . $val->inspectors . '</td>';
                }
                if (in_array('ok_qty', $checked_value)) {
                    $html .= '<td>' . $val->ok_qty . '</td>';
                }
                $html .= '</tr>';
            }
        }
        $html .= '</tbody>';

        $html .= '</table>';
        $js = ' <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
        <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
        <script src="https://cdn.datatables.net/1.13.7/js/jquery.dataTables.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/dataTables.buttons.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.html5.min.js"></script>
        <script src="https://cdn.datatables.net/buttons/2.4.2/js/buttons.print.min.js"></script>
        <script>
        $(document).ready(function() {
            $("#cnc").DataTable( {
                dom: "Bfrtip",
                responsive: true,
                buttons: [{
                    extend: "pdfHtml5",

                    customize: function ( doc ) {
                        doc.content.splice( 1, 0, {
                            margin: [ 0, 0, 0, 12 ],
                            alignment: "left",
                            image: "data:image/jpg;base64,/9j/4AAQSkZJRgABAQEBLAEsAAD/2wBDAAMCAgMCAgMDAwMEAwMEBQgFBQQEBQoHBwYIDAoMDAsKCwsNDhIQDQ4RDgsLEBYQERMUFRUVDA8XGBYUGBIUFRT/2wBDAQMEBAUEBQkFBQkUDQsNFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBQUFBT/wAARCAJ+AlEDASIAAhEBAxEB/8QAHwAAAQUBAQEBAQEAAAAAAAAAAAECAwQFBgcICQoL/8QAtRAAAgEDAwIEAwUFBAQAAAF9AQIDAAQRBRIhMUEGE1FhByJxFDKBkaEII0KxwRVS0fAkM2JyggkKFhcYGRolJicoKSo0NTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqDhIWGh4iJipKTlJWWl5iZmqKjpKWmp6ipqrKztLW2t7i5usLDxMXGx8jJytLT1NXW19jZ2uHi4+Tl5ufo6erx8vP09fb3+Pn6/8QAHwEAAwEBAQEBAQEBAQAAAAAAAAECAwQFBgcICQoL/8QAtREAAgECBAQDBAcFBAQAAQJ3AAECAxEEBSExBhJBUQdhcRMiMoEIFEKRobHBCSMzUvAVYnLRChYkNOEl8RcYGRomJygpKjU2Nzg5OkNERUZHSElKU1RVVldYWVpjZGVmZ2hpanN0dXZ3eHl6goOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4uPk5ebn6Onq8vP09fb3+Pn6/9oADAMBAAIRAxEAPwD9Avgr4S0O9+GOhz3GjWE8zpIXkktkZmPmPySRzXbf8IR4d/6AOmf+Acf+Fc98DP8AklWgf9c5P/Rj13lAzE/4Qjw7/wBAHTP/AADj/wAKP+EI8O/9AHTP/AOP/CtuigRif8IR4d/6AOmf+Acf+FH/AAhHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf8AoA6Z/wCAcf8AhR/whHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf+gDpn/gHH/hR/wAIR4d/6AOmf+Acf+FbdFAGJ/whHh3/AKAOmf8AgHH/AIUf8IR4d/6AOmf+Acf+FbdFAGJ/whHh3/oA6Z/4Bx/4Uf8ACEeHf+gDpn/gHH/hW3RQBif8IR4d/wCgDpn/AIBx/wCFH/CEeHf+gDpn/gHH/hW3RQBif8IR4d/6AOmf+Acf+FH/AAhHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf8AoA6Z/wCAcf8AhR/whHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf+gDpn/gHH/hR/wAIR4d/6AOmf+Acf+FbdFAGJ/whHh3/AKAOmf8AgHH/AIUf8IR4d/6AOmf+Acf+FbdFAGJ/whHh3/oA6Z/4Bx/4Uf8ACEeHf+gDpn/gHH/hW3RQBif8IR4d/wCgDpn/AIBx/wCFH/CEeHf+gDpn/gHH/hW3RQBif8IR4d/6AOmf+Acf+FH/AAhHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf8AoA6Z/wCAcf8AhR/whHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf+gDpn/gHH/hR/wAIR4d/6AOmf+Acf+FbdFAGJ/whHh3/AKAOmf8AgHH/AIUf8IR4d/6AOmf+Acf+FbdFAGJ/whHh3/oA6Z/4Bx/4Uf8ACEeHf+gDpn/gHH/hW3RQBif8IR4d/wCgDpn/AIBx/wCFH/CEeHf+gDpn/gHH/hW3RQBif8IR4d/6AOmf+Acf+FH/AAhHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf8AoA6Z/wCAcf8AhR/whHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf+gDpn/gHH/hR/wAIR4d/6AOmf+Acf+FbdFAGJ/whHh3/AKAOmf8AgHH/AIUf8IR4d/6AOmf+Acf+FbdFAGJ/whHh3/oA6Z/4Bx/4Uf8ACEeHf+gDpn/gHH/hW3RQBif8IR4d/wCgDpn/AIBx/wCFH/CEeHf+gDpn/gHH/hW3RQBif8IR4d/6AOmf+Acf+FH/AAhHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf8AoA6Z/wCAcf8AhR/whHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf+gDpn/gHH/hR/wAIR4d/6AOmf+Acf+FbdFAGJ/whHh3/AKAOmf8AgHH/AIUf8IR4d/6AOmf+Acf+FbdFAGJ/whHh3/oA6Z/4Bx/4Uf8ACEeHf+gDpn/gHH/hW3RQBif8IR4d/wCgDpn/AIBx/wCFH/CEeHf+gDpn/gHH/hW3RQBif8IR4d/6AOmf+Acf+FH/AAhHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf8AoA6Z/wCAcf8AhR/whHh3/oA6Z/4Bx/4Vt0UAYn/CEeHf+gDpn/gHH/hR/wAIR4d/6AOmf+Acf+FbdFAGJ/whHh3/AKAOmf8AgHH/AIUf8IR4d/6AOmf+Acf+FbdFAGJ/whHh3/oA6Z/4Bx/4UHwR4dwf+JDpn/gHH/hW3SHoaAPh4+H9Lyf+Jbaf9+F/worQPU0VBZ9LfAz/AJJVoH/XOT/0Y9d5XB/Az/klWgf9c5P/AEY9d5VkBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFIehpaQ9DQB8XHqaKD1NFQWfS3wM/5JVoH/XOT/0Y9d5XB/Az/klWgf8AXOT/ANGPXeVZAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSHoaWkPQ0AfFx6mig9TRUFn0t8DP+SVaB/1zk/8ARj13lcH8DP8AklWgf9c5P/Rj13lWQFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUh6GlpD0NAHxcepooPU0VBZ9LfAz/klWgf8AXOT/ANGPXeVwfwM/5JVoH/XOT/0Y9d5VkBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAVw3xa+Nngz4H+H/7X8Y63BpNu+RBEcvNcMB92ONcsx6dBgZGSKxf2kvj3pH7OvwwvvFGpKLm8J+z6dYbsNdXLA7U9lGCzHsAepwD+cXwP+CPjv9v34l6h408dazcw+GbWYR3N6BjP8QtLRT8qgA8nkLuBO4tz6eFwiqxdas+WC/HyRy1azi1CCvJnqHjr/gqrr2uaudN+GfgSOXexSCfV99xPN6YghI2n23tWB/w1t+166G+XwDqP2POePCdx5f54zj8a+jrX46fs3fsia1f+ArONfDuqabsS78jTJppZCyK4Lz7SZCVZTyxx04xWmn/BSD4EMwB8T3aj1OlXOB/45XopxS/c4W67u7uc2r+OrZ+R88+C/wDgqj4o8OawNN+JngKJdjBJ5NLElrcQ+5hmLBj7blr7l+D/AMdvBPx20JtU8Ha3DqSR4FxbMDHcWzHoJIzyvQ4PQ4OCa4S38W/AX9sfSZtEW80XxiRGW+yzxtBewju8YcLKmM/eX16818HftAfs++Nv2EfiDYePfh7rN23hmafy7e86vbk8/ZrkfddGA4JGGwcgEDOfscPi37NR9nU7PZ/1/VyuepRXM3zRP1roryL9mD9oXSv2kPhjaeI7NUtNUhP2bVNPDZNtcAAnHcowO5T6HHUGvXa8OpCVKThNWaO+MlJKS2CiiisygooooAK8E/a7/agtf2ZPCWh3620eo6pqmoxwx2TNgtbIytcuPcJhQezSKeQCK96JwM1+Of7VHjPXf2vf2pbnQvB8L6vb2Jk0vR7eJvllSEM8soPT5mV2z/dCDtXqZfho4ir7/wAMdWcuJqunD3d3sfrx4V8T6b418NaZr2j3K3ml6lbpdW06dHR1BB9jz07Vq1+dv/BMD9oSSFr/AOD/AIhmaKeFpLvRRPwwwSZ7fB7g5kA/66egr9Eq5sVh3hqrpv5ehpSqKrBSQUUUVyGwUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFIehpaQ9DQB8XHqaKD1NFQWfS3wM/5JVoH/AFzk/wDRj13lcH8DP+SVaB/1zk/9GPXeVZAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAfk3/AMFFfHepfF39pvTfh9pbma30byNMtrdT8sl5cbGdvr80af8AAK/TX4SfDXS/hB8OdB8IaOgWz0u2WHzNuDNJ1kkb/aZizH3NfldoGNX/AOCl0v25uE8dXG0t/wBM538sf+OrX7AV72Yv2dKjQjslf5nn4b3pzqPe5+UHxa8J6T45/wCCm9xoOu2aahpF/q1nDc2rsQsiGzi4JBB/I19xT/sH/Ai4iZG+H1mAeMpd3Kn8xJmvgD9pPxbrPgT/AIKFa5r/AIe0s63rdhqFpNa6eInk89xZxYXanzHr2r0jxb/wUq+Nng6GE618MtN8PtcbhA+q2F5CJCMZ2hnXdjIzg9xXdWo4mrCj7CVvdXWxhCdKEp+0XV9DzT9sH4NWf7HXxx8K6v8ADvUbuwinjGpWkUspeS0ljk2sobqyEY4bOcsDkV+pPirwnpfxv+El1ous2/8AxLvEGmL5iYy0RdAysuf4kbDA+qivzk8K/s8fGj9tn4n6P43+Jls2jeFXihb7TIogVrPO8RW0WS3z7id7cfNnJ4B/U23gjtYI4YkEcUahERRgKAMACuHMKto0ouV6kd2vw1N8PG7m7Wi9j8mP2CPGOpfAz9rK+8A6nKY7bVJrjQ72InCi5hZzE+PXcrIP+upr9a6/ID4rY0f/AIKTxtYN8w8ZabINvdneAuPzZhX6/wBTmqUpU63WUUPCaKUOzCiiivDO8KKKOlAHzv8At1/HH/hSXwG1WWyuPJ8Qa5nS9O2nDozqfMlHpsTcQezFPWvnz/glX8Dvsml638UtTt/3t4W0zSS46RqQZ5R9WCoD/sOO9eMftkeOtS/ao/av0/wJ4ak+02Gm3Q0LTwpzGZi4+0TnHYMMEjjbEDX6n/DrwLpvwz8C6H4V0iPy9P0m0jtYuMFto5dv9pjlifUmvfq/7Hgo0vtVNX6f1+p58P31dz6R29T81P2+vhBqf7Pfxy0f4u+Dg1hZapereeZCPltdRQ7mBH92UAvg9T5g6V+h3wH+L+mfHT4W6H4w0wqgvYcXNsGyba4XiWI/Rs4J6gg96l+OHwl0v44fDDXPB+qgLFfwkQ3G3LW868xyj3VgD7jI6Gvzo/YR+LWqfs3/AB71j4S+MibGw1S9Ni8crfJbagp2xuCf4ZBhMjrmM9BS/wB+wn9+n+K/r+tQ/wB3rf3ZfmfqlRRRXgnoBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUh6GlpD0NAHxcepooPU0VBZ9LfAz/klWgf9c5P/Rj13lcH8DP+SVaB/wBc5P8A0Y9d5VkBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQB+QX7WFpdfs/ft1nxUsLfZX1Oz8R2/H+uQsplH4yJKtfrjpGrWmvaVZalYXCXVjeQpcQTxHKyRuoZWB9CCDXzJ+37+zFP8e/htDq+gW/neMPDwea1iUfNdwEAyQD1bgMvuCP4s14V/wT9/bNsvDmn23wp+IN4NN+yyeRoupXfyKmWObWVj93B+6TxztOMLn6CtF43CQqQ1lDRry7/wBeZ50H7CtKMtpao5Lxd/ylag/7Ddl/6RRV90/tUfAOy/aH+EOqeHHWOPWIR9r0q6fjybpQdoJ7KwJRvZs9QK8i1n9izXtW/bFj+MsfiHTl0lb+C8/s8xv5xWOBIyM425JXNfXtc2KxKvRnSlrGK+9GtKk7TU1o2z4F/wCCb/7Ql5ay3/wS8ZNJaa3pEko0pbo4k2oT51qc/wASEMyj+7uHRRX3lf39vpdjcXl3Mlva28bSyzSNtVEUZZiewABNfIX7RH7DGq+P/jZp3xO+H3iSz8Ia7G0dxdGeNiGuYyNky7e5UAMDwduedxryz9uz9tAT+Em+FXhS/ttR127iW28SalpZLW6HAEltAx5bc2Qx7L8vJJ261KEMdWjKh9r4l27kRm8PBqp028zxf9nyOf8AaN/b6i8SRxFrH+25/EDtt/1UELF4c/8AAhCv1NfsBXyV/wAE9v2YLn4H/D+48R+IrU2/i7xEiPJBIuHsrUcpEfRyTuYf7oPK19a1hmVeNWty0/hirI0w0HCF5bvUKKKK8o6wrxL9sT43L8B/gVrmt28wi1u8X+ztKGfm+0yAgOP9xQz/APAMd69tr8m/+CgPxPv/AI9/tGaZ8OfDRa+tdEuF0q3hiORPqErKJT/wE7Y+ehRvWvSy/D/WK6UvhWrObEVPZ021u9ju/wDgld8EW1PW9c+Kmqwl0tN2m6W0gzumYZnlGfRSEB7+Y47V+lNcV8GPhjYfBv4X+HfB+nBTDpdqsTygY86U/NLIfdnLN+NV/jp8WtP+B/wr1/xlqCrKunQZgty237ROx2xRg/7TEAnsMntU4qtLGYhuPXRfoOlBUadn8zva/PP/AIKgfs8vLb2Pxe0CApc2vl2mteSMMVyBBccd1OIyfQx+hr7h+FnxI0n4ufD/AETxdoknmafqlusyqTlom6PG3+0rBlPuDWx4l8Oad4v8PalomrWyXmmahbva3NvIOJI3Uqw/I1nh608HXU+26/NDqwVaFjxD9ib9oZP2gfg3ZXN9OH8UaPtsNWQn5ncD5J8ekijPpuDgdK+gq/InwBrWrf8ABP79r260bVpZn8K3MgtrmQji50+RsxXAA4LIcE47rIo61+uNrcw3ttFcW8qTQSoJI5I2DK6kZBBHUEVvj8PGjU56fwS1RGHqOceWW60ZLRRRXmHUFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFIehpaQ9DQB8XHqaKD1NFQWfS3wM/wCSVaB/1zk/9GPXeVwfwM/5JVoH/XOT/wBGPXeVZAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFfJ37U/7AHhn48XU/iLw9PD4T8Yvlpp1izbXzesyDkN/00XnrkNxj6xorejWqUJ89N2ZnOEai5ZI/KnS9Y/a2/ZDA0oaZqGv+GrU4iR7Y6rY7B02yJ+8iX0Xcn0rY/wCHovxZRPsr/D7Rf7QzjH2e6Az6bN+f1r9PcZpNi/3R+Vek8fSqa1aCb7rQ5vq846Qm0vvPyt1Xxf8AtbftbK2k2+k6joHh27O2VLa1Ol2RQ9d00h3yLjqoZs/3TX0x+yx/wT28OfBG9t/Eniu4g8WeLo8PB+6P2Sxf+9Grcu4PR2AxxhQea+u8Ypayq5hOUPZ0oqEey/zKhh4qXNN3fmFFFFeWdYUUUUAeU/tP/GaD4D/BXxD4qLp/aCRfZtOif/lpdyZWMY7gHLkf3UavhD/gmH8Gp/HXxM1r4oa2j3NvorNFazTfMZr6UEu+T1KIxJz3lU9qpf8ABS34w3PxO+MWkfDLQWe8tdDdY5IIPm+0ahNgbQB1KKVUejM4r9B/2cfg/bfAv4OeHPCMIQ3VrAJL6ZP+W10/zStnuNxIH+yFHavff+xYG32qn5f1+Z538ev5R/M9Lr8wf+Cp/wAcv7e8YaT8M9NuN1lowF/qYQ8NdOv7tD/uRtn/ALa+1foh8WviPp3wj+G/iHxfqjD7JpVo8+zODK/SOMH1Zyqj3avwS8Y+K9R8deK9X8Q6tMbjU9UupLu4kPd3Ysceg5wB2GBV5NhvaVHWltHb1FjavLHkXU+0/wDgmJ+0X/wiPjG4+GOtXW3SddkM+lvI3EN4BzGPQSKOP9pQByxr9SK/nV03UbrR9Rtb+ynktby1lWaGeJtrxupBVgexBANfuP8AsofHq2/aF+DuleIt6LrUA+x6tbpx5d0gG4gdlcEOPZsdQavOMJySWIitHv6/8EnBVrr2b6Hlf/BRb9nX/hbvwoPinSLbzPFHhdHuFEa5e5tOs0fuVxvX/dYDlqwP+CaH7RX/AAsH4ey/D3Wbrfr3hqMGzaRvmnsc4Ue5iJCf7pj96+1WUOpVgCpGCD3r8kv2hPBerfsNftXaX408LQGPw7fXDajYRL8sTRscXNmfYBiB6K6HqK58I1i6EsJLdax/yNay9jUVZbbM/W6isDwH420r4j+DdH8T6JcC50vVLZLmCTvhh91h2YHII7EEdq368Npxdmdyd9UFFFFIYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSHoaWkPQ0AfFx6mig9TRUFn0t8DP+SVaB/1zk/8ARj13lcH8DP8AklWgf9c5P/Rj13lWQFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAV598fPizZ/BH4S+I/GF5sZrC2P2aFz/rrhvlij/FyucdBk9q9Br8w/8AgqT8bX8T+NtG+F2kStLbaRtvNQSLnzLuRcRR4HUpG2frL7V3YLD/AFmvGHTd+hz16nsqbl1Oc/4J0fCe8+Mvx61T4j+It99a6FK1/JPMM/aNRmLFCfUr88hx0IT1r9X68a/ZH+CafAb4G6D4eliWPWJ0+36ow6m6kALKT32AKgPogr0bx/41034ceCtb8T6vL5Wm6VaSXcx7kKM7R6sTgAdyQK0x1f61iHybLRf15k4en7Knrvuz8/P+Cqvxy8+70X4W6ZcfJDt1TV9h/jIIgiP0BZyP9qM9q/O6ul+JXj3Uvij4913xXq779Q1a7e5kGchAT8qL/squFHsBXNV9xhMOsNRjT69fU8KtU9rNyCvpT9g/9ok/Af4xW9vqdz5XhTxAUsdR3nCQtn91Of8AcYkE/wB129q+a6OlbVqUa1N057MiE3CSkuh/RkrBlBByDyDXjP7WvwDtv2hfg5qmgKiDXLYfbdJuG42XKA4UnsrglD/vZ6gV5p/wTu/aL/4XF8Jl8N6vc+Z4o8LoltKZGy9xa4xDL7kAbG91BP3q+sq/OpxqYOvb7UWfSJxrU79Gfmz/AMEy/j5c+FvEmp/BrxO8lqZZpZ9Kjucq0FyufPtiD0ztLAdmV+7V+k1fmD/wUY+CV/8ACP4paR8ZPCIewh1C7jkuprcY+y6inzJL7eYFz/vI2fvCvu79m7422Hx/+EejeLLTZHdyJ5GoWqH/AI97pABIn05DL/ssprvx9ONWMcZT2lv5M58PJwboy3W3oeoUUUV4p3BRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFIehpaQ9DQB8XHqaKD1NFQWfS3wM/5JVoH/AFzk/wDRj13lcH8DP+SVaB/1zk/9GPXeVZAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHIfFz4kad8Ivht4h8X6oR9k0q1afy84MsnSOMH1Zyqj3avy5/Yc+HGo/tJftP3vjnxKDe2ek3La7qErjKS3buTBH7Dfl8dNsRFfXf8AwU28HeJvFH7PQutDmZtN0i+S91WzjX5pYQCofI6hGYMR6fN/BXOf8EqfEPhe5+Dmt6LpyCDxPa6i1xqgcgvMjgCGRf8AYCqVx2ZWP8Qr38P+4wNStDWUnb0X9foefU/eYiMJbLX1Pt2vz5/4KqfHL+ztE0b4XaZcYnvyupasEPSFWIhjP+84Lkf9M09a/Qavyu/4Kh/Ay+8MfEm2+JNqZrnR/EIS2umdiwtrqOMKq5PRXjQED1R/aufKowlio8/y9TTFuSpPlPh2iiivvj54KKKKAPTf2cvjXqHwB+LWi+LbPfJbQv5N/aocfabVyBIn1xhhnoyqe1fur4d8Qaf4r0HTta0q5S803ULdLm2uIzlZI3UMrD6giv53a/Sr/gl1+0X/AGhp138Jtbus3FoHvdEeRuWizmaAf7pJcD0Z+yivnM4wntIe3itVv6f8A9LBVuWXs3sz7b+LHw00n4v/AA81zwhrUe+w1S3MRcDLRP1SRf8AaVgrD3Ffmd+x38S9W/ZH/aV1j4ZeMpPsmkandjTbvecRw3IP+j3K5/gcMBnj5ZFY/dr9X6+Cf+Cn37Op8ReG7X4qaHbZ1LSFW21dYl5ltSfkl46mNjgn+62eiV4uX1YycsLV+Gf4Pod2Jg1arDeP5H3r1pa+Z/2Cv2iR8dvg7Baanc+b4r8OhLLUN7ZedMfuZz67lBBP95GPcV9MV5talKhUdOe6OqE1OKkuoUUUViWFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSHoaWkPQ0AfFx6mig9TRUFn0t8DP+SVaB/1zk/9GPXeVwfwM/5JVoH/AFzk/wDRj13lWQFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQBW1LTrbWNPurG9gjurO6iaGaCVdySIwIZSO4IJFfkhqEGrf8E9/2wUmhE83hSd9yAc/a9Lmblfd4yPxaIHoa/Xivmr9vH9nUfHj4O3Fxplt5vivw8HvtO2DLzLj97AP99QCB/eRfU16mX140qjp1Pgno/wDM5MRTco80d1sfROjaxZ+IdIstU064ju9PvYUuLe4iOVkjdQysD6EEGuV+M/wq0r41fDTXPB+sKBbajAUjm25aCUcxyr7qwB98EdCa+PP+CYH7RJ17w9d/CrXLnOo6SrXWkNK3MlsT+8h57ox3Af3WPZK++a569KeDruPVbP8AJmtOca1O/c/nq8e+CdV+G/jLWPDGt25ttU0u5e2nj7ZU8Mp7qRgg9wQe9YNfpd/wVE/Z0/tTSbT4saJa5urJUs9bSNeXhJxFOfdSdhPoydlr80a+9weJWKoqot+vqfPVqTpTcQooorsMQrd8DeNNV+HfjDSPEuiXBtdV0u5S5gkHTcpzgjupGQR3BI71hUUmk1ZgnbVH79/BT4r6V8bfhlofjDSGAg1CANLBuy1vMOJIm91YEe4wehrrNX0mz1/SrzTNQt47uwvIXt7i3lGUkjYFWUjuCCRX5V/8E0v2i/8AhXXxFk+H+s3Wzw/4mkH2RpG+W3v8YX6CQAIf9oR+9frBX53jcM8JWcVtuvQ+loVVWhfr1PyGtpNW/wCCe/7YRRzPN4TnfBPJ+16XM3B93jI/F4j2Nfrfpmp2utaba6hYzx3VldRLPBPE25JEYAqwPcEEGvmr9v39nX/hePwfl1LSrbzfFfhsPe2QRcvPFj99B75ADKP7yAdzXmH/AATD/aK/4Srwnc/C/W7ndquiIbjSmkbma0J+aMepjY8f7LADhK7sQvruGWJXxR0l/n/X6HPT/cVXSez1R93UUUV4J6AUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFIehpaQ9DQB8XHqaKD1NFQWfS3wM/wCSVaB/1zk/9GPXeVwfwM/5JVoH/XOT/wBGPXeVZAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABR1oooA/KH9sr4Zat+yZ+0lo/wATvBqfZNK1O8OpWuwYjhugc3FuwH8DhiccZV2Ufdr9L/hJ8TdJ+MXw60Pxfor7rLU7cS+WTloZOjxN/tKwZT9Kwf2jvgpp/wAfvhJrXhK82R3MyefYXTjP2a6QExv9M5U46qzDvXwZ/wAE6vjXqHwe+K2sfBzxeXsINRvHit4bg4+y6knytH7CQLt/3lTH3jXvS/27Cc326f4r+v61PPX+z1rfZl+Z+mHiDQbDxRoeoaPqlsl5pt/A9tc28gyskbqVZT9QTX4V/tJfBK//AGf/AIuaz4Tu98lpG/n6fdOP+Pi1ckxv9eCrf7SsK/eSvlH/AIKG/s6/8Ll+Ej+IdJtvM8U+GEe6hCLl7i2xmaL3IA3qPVSB96s8rxf1etyS+GX59C8XR9pC63R+PVFHSivuz58KKKKAJLe4ltLiKeCRoZomDpIhwysDkEEdCK/bj9jT9oKL9oT4Nafqd1Mp8Sabix1eIcEzKOJceki4b0zuA+7X4h179+xV+0LJ+z78ZbK8vJ2Twxq+2w1ePPyrGT8k2PWNju9dpcDrXlZlhfrNH3fiWq/yOvC1vZT12Z+2hGRX5O/ta/DrV/2O/wBp3SPiP4Oi+zaNqV2dSslQERRzZ/0m1bHRGDHA4+WTA+7X6wQzJcQpLE6yRuoZXU5DA9CDXlv7TXwOsv2gvhDrHhW4Ecd+V+06bdOP9RdID5bZ9Dkq3+yzV8hgcQsPV9/4Xo/Q9mvT9pDTdbHV/C74jaT8WvAGieLdEl8zTtUt1nQEgtG3R42/2lYMp91NdVX5j/8ABN74433ww+I+r/BrxaZLGK9upBZxXJwbXUE+WSE+m8L/AN9IAOWr9OKzxmHeGrOHTdehVGr7WCl1CiiiuI3CiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkPQ0tIehoA+Lj1NFB6mioLPpb4Gf8kq0D/rnJ/6Meu8rg/gZ/wAkq0D/AK5yf+jHrvKsgKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK/Nz/gpt8Arjw5r+mfGTwzG9szyxQas9tlWhuFx5FzkdM4CE9iqd2r9I6wvHXgvSviL4P1fwzrduLrS9Utntp4z12sMZB7MDgg9iAa7MJiHhayqLbr6GNamqsHE8y/ZG+Ptv+0N8G9M12SRBr1oBZavAvGy5UDLgdlcYcem4jsa9pIDAg8g1+SPwC8Y6t+wt+1hqfg7xROyeHL2ddPv5m+WN4WOba8HsNwJ9FaQdRX62o6yIGUhlIyCOhFbY/DqhVvD4ZaojD1HUjaW60Z+M37ev7Op+BPxhnu9LtvK8J+Ii97p+xcJA+f30A9NrEED+66jsa+Z6/dP9qv4D2v7Qvwd1bw4VjXWIh9s0q4fjyrpAdoJ7KwJQ+zE9QK/DXVNMutF1K70++gktb21leCeCVdrxyKSrKR2IIIr6zLMV9Zo8sn70dH+jPHxVH2U7rZlaiiivXOMKKKKAP1p/wCCbH7Rf/Czfho3gbWLrzPEfhiNUgMjfNcWPSNvcxnCH28vuTX2VX4E/Av4u6p8DfijofjDSyzPYzD7RbhsC4gbiSI/7yk49Dg9q/dzwZ4u0vx94U0nxFotyt3pWp2yXVvKO6MMjI7EdCOxBFfDZrhPYVfaR+GX5nvYSt7SHK90fnb/AMFL/gPdeCvF+lfGXwssloLieKPUpLb5Wt7tMGG4BHTcFAJ7Mi92r7L/AGU/jxa/tC/B3SfEYdF1iEfY9Wt048q6QDcQOysCHHs2OoNd/wDEPwJpPxN8E6z4W1yAXGl6rbNbTL3XPRl9GU4YHsQDX5bfs1+OtW/Yk/ap1XwL4smMPh+/uV06/lb5YsE5trwZ6LhgT6LI2eRVU/8AbsL7P7dPbzXb+vIUv9nrc32ZfmfrXRSAhgCDkGlrwT0AooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApD0NLSHoaAPi49TRQepoqCz6W+Bn/JKtA/65yf8Aox67yuD+Bn/JKtA/65yf+jHrvKsgKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAr4/8Aid/wUd8JfC748Xvgi+0qfUNAsFW3vdZsXDvBdZO9RH/Gi5UHBBDBhg4r1H9sH9oCH9nr4N6lrMMif8JDfA2OkQtgk3DA/vCO6oMse2QB/EK+Ef2Ov2H7f9o/wT4l8Y+Nb7UbGC+kaDSLqB8ySThsy3Dbgd67vkwep8zkEA17ODw9H2UsRifh2Xr/AMA4q1SfMqdLfc/TnwD8R/DPxS8PQ654U1q01zTJek1rJnaf7rr1Rh3VgCPSukr8e/HfwC+OH7DfiaTxP4a1C6m0RG/5DmjgtbumeFuoTnaPZwVyeGJr6g/Z1/4Kb+GvGv2XRfiVBF4U1lsIurQ5NhM3q+ctCfrlepLL0orZdJR9rh3zx8twhiVfkqLlZ9yUVBY39tqdnDd2dxFd2syCSKeBw6Op5BVhwQfUVPXjHaFFFFABRRRQB8Wf8FLf2dP+FifDuP4gaNa7/EHhmM/a1jX5rixzlvqYyS4/2TJ7Vs/8E5v2iv8AhbXwq/4RPV7rzPE/hdEgJkbL3Fn0ik9yuNjfRSeWr62uLeK7t5YJ41mhlUo8bjKspGCCD1Br8jviNoerfsAfteWmuaNFK/ha5kN1axA/LcWEjYmtiehZDkDPdY2PWvdwr+uYd4WXxLWP+X9foefV/c1FWWz0Z+utfl1/wU8/Z0/4RXxbbfFDRbXbpWtuLfVUjXiG7A+WQ+gkUc/7Sknl6/THwx4l07xj4d03XdIuUvNM1G3S6tp06PG6hlP5HpWV8UPh1pPxZ8Aa34S1uLzdO1S3aByAC0bdUkX/AGlYKw91FcODxEsJXU+mz9DorU1Why/cfz60V1PxR+HOrfCXx/rfhLW4vL1HS7hoHIGFkXqki/7LKVYezCuWr9FjJSSktmfNNNOzCiiimAV+iX/BLn9ovyLi7+Eut3X7uUve6G8jdG+9NAPrzIB7Seor87a1PC/iXUfBviPTdd0i5ez1TTrhLq2nTqkiMGU/mOneuTFYeOKpOm/l6m1Go6U1JH9D9fEP/BTT9nX/AITrwJD8R9Ftt+t+HY9l+sa/NPY5yWPqYmJb/dZz2FfS/wCz38ZtO+PXwo0TxfYbI5bmPy721U5+zXK8Sxn2B5GeqlT3r0G8s4NRtJ7W5iSe2nRo5YpFDK6kYKkHqCD0r4ClUng66l1i9f1R9DOMa1O3Rnyt/wAE8f2iv+FyfCVPDurXPmeKfC6JazGRsvcWuMQy+5AGxj6qCfvV9X1+RHi3TNW/4J9ftf2+pafHNJ4UuJDPAgJxdabK2JIST1eMjAz/ABIjHg1+s/h/XrDxToWn6xpdyl5pt/AlzbXEZyskbqGVh9QRXXmFCMJqtS+Ceq/VGWHqOScJbo0KKKK8k6wooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkPQ0tIehoA+Lj1NFB6mioLPpb4Gf8AJKtA/wCucn/ox67yuD+Bn/JKtA/65yf+jHrvKsgKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACmySLFGzuwRFBLMxwAPWnV8ff8FH/wBov/hVfwuHg3R7ry/EviiNonMbfPb2XSV/Yv8A6sexcjla3oUZYioqcd2Z1JqnFyZ8n/G3xXq37eH7WmneFPDc7t4as5msLGZRmOK2U5uLwj/a2kjpkCNetfqv4L8IaX4A8J6T4c0W3FppWmWyWtvEOyqMZJ7k9Se5JNfJv/BNf9nT/hWnw1fx3rNts8ReJ41a3Ei/Nb2OcoPYyHDn28vuDX2ZXoZhWi5LD0vghp8+rOfDQaTqS3kMmhjuInilRZI3BVkcZDA9QRXxr+0b/wAE2PB/xL+1az4DeHwZ4jbLm1VP+JfcN7oOYj7px/sk819O6V8XvBmt+OtU8GWXiOwm8U6Zt+1aX5uJlyobgH7+ARnbnb0ODXYVxUq1bCy5oNp/mbzhCqrS1Pxt8N/Ev47fsF+K10XUre5g0lpC39lalmfTrtc8vA4OFJ65Qg5xuHav0E/Z2/bp+Hvx8W205rkeF/FcgCnR9SkAErekEvCyfThv9nHNe4+NPAvh/wCIugXGieJtItNa0qcfPbXkYdc9mHdWHZhgjsa/O79ov/gl/qGjNc698Jbt9QtlJkbw9eygTx98Qynh/ZXwePvMa9f22Fx+ldck+62fr/XzOPkq4f8Ah+9HsfpdRX5J/BH9vr4l/s+6r/wivxBsb3xHpVm/kS2eq7otSssdldxlsD+GTPYAqK/SP4MftD+BPj3o327wjrcV3MihrjTpv3d3bf8AXSI8gZ43DKnsTXn4nA1sLrJXj3Wx0UsRCrot+x6TRRRXnHSFeAftq/s9R/tBfBq9s7KBX8T6Ruv9IfHzNIB88OfSRRt9NwQnpXv9Fa0qkqM1UhuiJxU4uL6n54f8Ev8A9oV9l98IPEE7R3FsZLvRfPOGxkme3we4OZAPeT0FfofX5X/t6fCPVP2dPjvo/wAXPBoaxsdUvReiSJfkttRU7nUj+7KAXwev7wdBX6J/Az4uaX8cvhdofjDSyqJfQj7Rbhsm3nXiSI/7rA4PcYPevUzCnGaji6Xwz38mcuHk43oy3X5Hyf8A8FPP2dP+Es8I2/xP0W13aroiCDVUjXmazJ+WQ+pjY8/7LEnhRX5c1/RVqem2us6ddWF9BHdWV1E0E8Eq7kkRgQykdwQSK/Db9q34DXX7PXxi1bw4VkbRpj9s0m4fnzbVydoJ7spBQ+656EV6+T4vnj9XlutvT/gHFjaNn7RdTx6iiivpTzAooooA+u/+Ccv7RX/CpfiqPCer3Xl+GPFEiQZkb5Le86RSewbOw/VSeFr9eOtfzmo7RurKSrKcgjqDX7TfsM/tEL8ffg5a/wBo3Al8VaEEsdUDH55cD91Of99Qcn+8r9sV8nnOEs1iI+j/AEZ6+CrX/dv5D/24v2d1+P3wbu00+3EnirQ919pTKPmkIH7yD/toowB/eVPSvA/+CX37Q7X+nXvwk164IvLEPd6KZjy0WczQc91JLgdcM/Za/QWvyo/bi+FWq/sxftCaP8VvBimy07VL37fC0a/u7e+U7pYmA/gkBLY7hpB0FcWCksTSlg5vfWPr/X6m9dOlNV4/P0P1XoriPgv8VdK+Nfw00LxhpDAW+owBpId2Wt5hxJE3urAj3wD0Irt68WUXCTjLdHcmmroKKKKkYUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFIehpaQ9DQB8XHqaKD1NFQWfS3wM/5JVoH/XOT/wBGPXeVwfwM/wCSVaB/1zk/9GPXeVZAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAZPizxTpvgjwzqmv6xcrZ6Xptu91czv0VFBJ+p44Hc8V+UPwp8Oat+31+1zfeItdhkHhe1lF5eRMcrBZI2ILUHpl8AHGM/vGHNev/wDBT79oOW6msPg94emaWaVo7rWhByzEkGC2wOpJxIR/1z96+nP2Mv2fIv2e/g1YaddQqviXU8X2rydSJWHyxZ9I1wvpncR96veo/wCw4V1n8c9F5Lv/AF5Hnz/f1eT7Mdz3aGGO2hSKJFjijUKiIMBQOgA7CvL/ANpf44WP7P3wi1nxXclJL5V+z6bauf8Aj4unB8tfoMFm/wBlWr1LpX47f8FCP2iv+F0/F2TQ9JufN8K+GWe0tijZS4uM4mm9xkBFPouR941x4DC/Wqyi/hWr/rzNsRV9lC636HzZfeK9Y1DxPceIptSuTrk90169+shWYzMxYyBhyG3HORX2j+zp/wAFOfEfg37LovxMt5fFGjrhF1eAAX8I9XHCzAe+G6klulfDFFfdVsNSxEeSpG/6Hgwqzpu8Wf0DfDX4r+E/i/4ej1rwjrlrrVg2AzQN88TH+GRDhkb2YA11tfz5fD74l+KPhV4hh1zwnrd3ompR8ebbPgOP7rqfldf9lgR7V+jH7On/AAU/0bxKbbRPilax6BqJwi67ZoTZynpmVOWiPuMr1PyivksXlFWjeVL3l+P/AAT2KOMjPSejPqH44/szeAf2gtKNt4q0dGv0Qrb6vaYivLf/AHZMcj/ZYFfavzW+NP7EvxU/Zg1r/hLPBl7e63o1kxmh1nRd0V5Zj1ljU7gMZyykrjrjOK/XLSdXsde0631DTbyDULG4QSQ3NrIJI5FPRlZSQR7irRGRg1xYbHVsL7u8ez/rQ3q4eFXXZ9z83f2df+CotxaG20T4tWhuIhhF8R6fFiRfeeFeG92jwf8AZPWv0I8H+NdB+IGg2+teHNWtNa0q4GY7qzlEiH1Bx0I7g8jvXzl+0Z/wT68BfGsXWraJGng3xXJlzeWUQ+zXL/8ATaEYGSf41wecnd0r85rXUvip+xr8aLzw3omtfZ/EFvNHFNaabMLq1vdwBRWj6NkMMBlDjdxg16P1bDZgnLDPln1T2/r+rHL7Wrh9Kuq7n7g0VheBrjXrzwbos/iiC1tfEUtpG+oQWWfJinKguqZJOAcjqelbtfOtWdj0lqcD8dPhFpfxy+F2ueD9UCol9Cfs9wVybedeY5R/usBkdxkd6/O79gv4u6p+zr8dtY+EfjItY2OqXpszHK3yW2oqdqMD/dlACZHX92egr9T6/PD/AIKgfs9OFsfi/wCH4GjuLcx2mteQMMBkCC4yO4OIyfeP0Nexl9SM1LCVfhnt5M48RFxtWjuvyP0Pr5o/bz/Z1Hx3+D091plt5vivw8HvdO2Ll50x+9gHruUAgf3kUdzWz+xX+0LH+0F8G7K9vJ1fxPpO2w1ePPzNIB8k2PSRRu9NwcDpXv3WuBOpg6/aUX/X3m/u1qfkz+c0gqSCMEUlfV//AAUP/Z0/4U38Wn8RaTbeX4W8Tu91CI1wlvdZzNF7Ak71HoxA+7XyhX6LQrRr01Ujsz5ucHTk4voFFFFbEBXtX7I3x9uP2efjJpmuySOdBuyLLV4Fyd1sxGXA7shw49cEfxGvFaKzqU41YOEtmVGTg1JdD+iyxvbfU7K3vLSZLi1uI1limiYMrowyGBHUEEHNcD+0B8G9N+PHwp1vwhqIWN7uLfaXLDJtrleYpB9DwcdVLDvXzF/wTI/aK/4TbwNP8Ntaut+teHo/M05pG+aexJxtHqYmIH+6yAfdNfcVfnNanPB13HrF6foz6WEo1qd+jPy2/wCCffxj1L4EfGfWPg/4x32Fpqd61skU54tdSQ7AB7SgBcjqRHjgmv1Jr85v+Cnv7Psun3un/GLw7E8MqPFa6y1v8rI4wILnI6HgRk+0fvX1L+xv+0FF+0L8G9P1W5lQ+I9OxY6vEMA+coGJcf3ZFw3pncP4a9DHRWIpxxlPrpLyZzUG6cnQl029D3SiiivEO8KKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkPQ0tIehoA+Lj1NFB6mioLPpb4Gf8kq0D/rnJ/6Meu8rg/gZ/wAkq0D/AK5yf+jHrvKsgKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAK89+Pfxh0z4E/CvXPGGpFX+xxbbW2Jwbm4biKMfVsZI6AMe1ehV+Vf7dXxY1X9pX4/6P8JvBrG+0/S70WMaRt8lzqDHbLIxH8MYyue2JD0Nd+Cw31mqlL4Vq/Q569X2ULrd7Fj9gL4Pan+0B8btY+L3jENf2el3rXYlmX5brUnO9cD0iBD4HQmMdK/UyuF+CXwm0v4I/DHQ/B+kqGh0+ACafbhriY8ySt7sxJ9hgdBXX6tqtpoWl3mpahcR2ljZwvcT3EpwkcagszE9gACaMZiPrVZyjstF6BQp+yhZ79T5t/b6/aK/4Ub8H5tP0u58rxX4jD2VjsbDwRY/fT+21SFB/vOp7GvxpJJOTya9c/al+O13+0J8YdX8TO0iaUh+yaVbP/yxtUJ2cdmbJdvdiOgFeR19nl+F+q0Un8T1f9eR4mJq+1ndbIKKKK9M5Qoop0cbSyKiKXdjhVUZJPpQB9gf8E29b+Jd/wDGW10LwzrdxbeEIQb3W7Sceba+SOMKp4WR22qGXB6k5CkV+uNfPP7EH7PC/AD4N2kV/biPxTre2+1ViPmjYj93B9I1OCP7zOe9fQ3Svz3Ma8a+IcoLRaevmfR4am6dNKW55t+0N8Z9O+Anwn1vxdf7JJrePyrK1Y4+03LcRx/TPJx0VWPavgT/AIJ5/BjUfjb8YNY+MXjDff22m3jzwyzjIutSc7y/0jDbvZmjx0NZP7a/xR1b9qf9ovR/hZ4MY3umaXef2dAIz+7nvCcTTMR/BGAVz2COw4av0n+Dvwu0r4MfDbQvB+jJ/ommwCNpSuGnlPMkre7MWb8cdBXW/wDYcJb7dT8F/X9aGK/2itf7MfzOzoqjq+t6doFk95ql/badaJ96e7mWJF+rMQBXnGpftV/B7SZmiuPiV4a3qcEQ6jHLg/8AACa8WNOc/hTZ3OUY7s9VrL8UeGtO8ZeHNS0LV7ZLzS9Rt3tbmB+jxupVh+R69q4zQf2kPhX4mmWHTfiJ4auZ24WEapCsjfRSwJ/KvRIpo541kidZEYZVkOQR6g0OM6b1TTBNS21PyN+HGu6t+wD+15eaHrMsr+FrqUWt1Kw+W4sJGzDcgdNycE47rIo61+uNvcRXdvHPBIssMqh0kQ5VlIyCD3FfJH/BRn9nX/hbXwq/4SzSLXzPE/heN58Rrl7mz6yx+5XG8fRgOWrI/wCCaf7RX/Cxfh1J8P8AWbrf4g8Mxj7KZG+a4sc4T6mMkIf9kx+9eziksZh1io/EtJf5/wBfocNL9zUdF7PVH0H+0h8E7D4//CTWvCd2Eju5U8/T7px/x73SAmN/pnKn/ZZh3r8K/EOgX/hXXdQ0bVLZ7PUrCd7a5t5Bho5EYqyn6EGv6I6/NL/gqJ+zp/ZmqWnxY0S1xbXhSz1tI14SbGIpz/vABCfVU7tW2T4r2c/YSej29f8AgkY2jzR9ot0fnzRRRX2R4oUUUUAdf8I/ibq3wd+Iuh+L9Ffbe6ZcCXyycLNGeJIm/wBllLKfrX7wfDnx9pPxQ8DaL4q0Obz9M1W2W4iPdc/eRvRlYFSOxBFfz4V99f8ABL79ov8AsDxDdfCvW7rFhqjNdaO8jcR3IGZIRnoHUbgP7ynu9eBm+E9tT9tHeP5f8A9DB1uSXI9mfpD4w8J6Z468Lar4e1m2W70vU7Z7W4hb+JGGDg9j3B7EA1+Unwf8Tat+wT+1vf8AhnxBM/8AwjF3MtlezMMJNaOc292B0ymQTjOB5i9a/XOvjn/gpH+zr/wtD4Yr420e28zxJ4XjaSURr89xY9ZF9yh/eD239zXz+X1oxk6FX4J6fPoz0cTBtKpDeJ9hxSpPEkkbq8bgMrKcgg9CDT6+OP8Agm3+0V/ws/4ZN4I1i68zxH4XjWOEyN89xY9I29zGcRn28vua+x64a9GWHqOnLodFOaqRUkFFFFc5oFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFIehpaQ9DQB8XHqaKD1NFQWfS3wM/5JVoH/AFzk/wDRj13lcH8DP+SVaB/1zk/9GPXeVZAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRUN3dw2NrNc3EqQW8KGSSWRgqooGSST0AHegDwH9t39odP2f/AIN3k9jcCPxTrW6w0lAfmRiP3k/0jU5z/eKDvXz1/wAEvv2eWt7S9+Lmv25a7vPMtNFEwyQmcTXHPdjlAfQP2YV4j441fVv+CgX7X1tpOlyzR+FbeQ29tIAcW2nRNmW4IPAZycjPd0U9K/WXw34e0/wloGnaLpNslnpmn26Wttbxj5Y40UKoH4Cver/7DhlQXxz1l5Lt/XmefD9/V9p0jsaVfBf/AAU//aL/AOEZ8L23wt0S626lrCC51d425itQfkiOOhkYZI/urg8PX2R8VviTpPwh+HuueLtbk2WGl27TFAcNK/RI1/2mYqo9zX4PfEz4hat8VfHmt+LNbl87UtVuWnkwflQHhUX0VVCqB6KKeUYT21X2slpH8/8AgBjK3JHkW7OZooor7Y8IKKKKACvsH/gnB+zp/wALV+KJ8Zaxa+Z4a8LyLKgkXKXF71iT3Cf6w+4QHhq+VPCfhbUvG/ibS9A0e2a81TUrhLW2gTqzuQB9Bzyew5r92vgF8HdN+BHwq0PwfpwVzaRb7u5UYNzctzLIfq3TPRQo7V4ma4v6vS5I/FL8up3YSj7SfM9keh184/t0/tEj4B/By5XTrkReK9eD2OmBT88WR+9n/wCAKRg/3mTtmvoe/vrfS7G4vLuZLe1t42llmlbaqIoyzEnoAATmvx9+IXi6X9tr9qO6vbu+bS/AGkI8kl5KSqWGkQHdJMfR5M5H+1Iq8gCvmcvw6rVOefwx1f8AkepiajhHljuz3P8A4J1fCTSPhf4G1j46ePLm30m3mieDTbm/YKsNuDiWbn+KRhsXHJAOM7xWh44/bo+I/wAefE9x4P8A2efC9zIgysmvXMCtKFzjeA/7uBD2aTJPop4rg9F0bxP/AMFCPiHb6JpCz+D/AIGeEjHbW9vCuFWNF2oAOjzsnTORGp75+f8ARf4afC3wx8IPCtt4e8J6TBpOmQDO2IZeVscvI55dj3Ykmu7FVKdOo6tZc1R9OkV0v3ZhSjKUeWDtHv1Z8S6D/wAE1/F3xJvE1r4yfE+/1LUJOXtbGRrl0B/hE03C46YVCB2OK9U0v/gmP8E9PhVJ7LWtSYdZLrUmVj/37Cj9K+sCQOvFcR4g+Ofw58KXMltrPjzw3pdzG214LrVYI5FPoVLZ/SuB47F1XaMn6LT8jo9hRhuvvPnbxD/wS4+D2rQMNPn8QaJNj5Xtr1ZFB9xIjZH0IryzUP2M/j1+ze76r8G/iFPr1hCfMbRpG8hnHXHkSFoZPrlT6Cvu/wALfEzwh44Zl8O+KdG15lG4rpuoRXBA9SEY10tCx+Jh7tR8y7SVweHpS1ireh8V/Ab/AIKGWWva7/whHxh0j/hBfFiP9ma6njaK0kfptlV/mgY/7WVPqvAr5j+PPhHVP2Gf2rtL8Z+FYiPDV9OdR0+JDiKSBji4syfQBiB1wrRnqK/QX9pX9lPwh+0l4ceHU7dNO8RwRkWGuwIPOgPUK/TzI89VPqcEHmvz8vj4jOk6n+zR8XMR6zZOJvBmu3L5WG4AIhh8w/et5xlFY/cLAEfLhPVwcqM5OdJWTVpR8u69DkrKaSjP5P8ARn6o+BvGelfETwfpHiXRLgXWlapbJcwSDrtYZwR2YHII7EEUnjvwVpXxG8Hax4Z1u3FzpeqWz208ffaw+8D2YHBB7EA9q/Pr/gmR8frjw7r2pfBvxLI9szyy3Gkpc/K0M658+2wemcFwOxV+7V+kdeJiqEsJWcPmn5dDupVFWhf7z8AvjR8KdV+CnxM13wfq6k3GnTlY59uFuITzHKvsykH25HUGuJr9Xv8Agpd+zp/wsP4eR/EHRrXfr/hqI/bFjX5rixzls+piJL/7pk9q/KGvucDiViqKn12fqeDXpeym49AooorvOcKuaNrF74e1ey1TTriS01CymS4t7iI4aORGDKwPqCAam8O+G9V8XaxbaTomnXWranctshtLOJpZJD6BQMmvvv8AZ0/4JdXN59l1v4s3ZtITh18OafKDI3tPMOF91TJ/2geK5MRiqOGjeq/l1ZtTpTqv3EfZ/wCzD8crP9oP4P6P4phKR6jt+y6nbJ/ywukA3jHYHIdf9lx3r1SWJJ4njkUPG4KsrDIIPUEVj+DvBOg/D3QLfRPDek2mi6VbjEdrZxBEB7k46se5OSe5rbr85qOLm3TVl0PpYpqKUtz8jPjH4X1b9gr9rbT/ABP4ehceGLuZr2xhU4Sa0c4uLQnplckDOcAxt1r9W/B/izTPHfhbSvEOjXK3el6nbJdW8y/xIwyMjsR0I7EEV8n/APBSjXPhnqPweuNC8R65bW/jO2YXmiWkA826EvQhlXlI3XILNgZwRkqBXmP/AASw+PV1cDU/hVqfnT28KPqWkzbSywjP76En+EEnevbJfuQK92vCWMwccQ170dH5rv8A15nBTkqNZ009H+DP0Wooor549EKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKQ9DS0h6GgD4uPU0UHqaKgs+lvgZ/ySrQP+ucn/ox67yuD+Bn/ACSrQP8ArnJ/6Meu8qyAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvib/gpj+0X/wgHgCL4d6Lc7Nd8SRlr1o2+aCxzgj2MpBX/dV/UV9c+P8AxxpXw18F6z4o1ucW2l6XbPczv3IA4VR3ZjhQO5IFfll+zr4J1b9uL9qzVPG3iuAy+HrG4XUb+JvmiCA4trMexCgH1VH7mvXy+jHmeIq/DDX1fRHHiZuypw3kfXP/AATs/Z1/4U/8J18TavbeX4o8UIlzIJFw9tadYYvYkHe3uyg/dr60pFUIoUDAAwAK8b/ay+Pdt+zz8HNU8QB0bW7gfY9Jt358y5cHaxHdUALn2XHUiuOcqmMr3+1JmyUaNO3RHwz/AMFOv2i/+Ex8Z2/wy0W63aRoMnnam0bfLNekcIfURqSP95mB5UV8L1Y1HULnVr+5vryd7m7uZGmmmlbc8jscsxPckknNV6/QcNQjhqSpR6HzlWo6s3JhRRRXSZhRRXoPwF+D2p/Hb4qaH4P00Mn2yXddXIXItrdeZZT9FzgHqSo71M5KEXKWyGk5OyPtf/glz+zpk3fxa1u14G+y0JZF+qzXA/WMH/rp7V+jdZHhHwrpngfwxpfh/RrZbPS9Nt0tbaFf4UUYH1PHJ7nJqj8SPH+k/C3wLrXivXJvI0zSrZriU/xNj7qL6szEKB3JFfnOJryxldz76JfkfS0qaow5T5A/4Kb/ALRX/CF+CYPhpot1t1nxBH5upNG3zQ2WcbD6GVgR/uqwP3hXyLd/D3WPCXhHwb8H9GhK+O/iHLbalrakENBbM3+hWrnqoA3TyDtlM/drtv2X/AWrftpftSav8QPF8Pn6Dp9yNSvo2+aIkHFtaLnqoCjI7pGQeWr1n9jm2Hxw/bY+KnxOux9pttGeWGwZufL8xmggP4QROv419HHlwVJ01vBc0v8AE9l/XZHmO9efN30Xp1Ptj4MfCbRfgl8ONH8I6HEFtbGICWfbh7mY8ySv/tM2T7DAHAFN+Mvxj8OfArwHfeK/E9yYbK3wkUEeDNcyn7sUakjLHB9gAScAE13Nfjp/wUR+Od18Vfjpf6Bbzt/wj/hV3063hVvle4BxPIR67xs+kY9TXhYLDyx1e03pu2ehXqKhT0+Rzf7Qn7bfxE+POoXVu2pTeHPCzOfJ0TTZSilO3nOMNKfXPy56KK+fCSepzSUV97TpQox5aasj56U5Td5O5PZX1zp1zHc2lxLa3ETbklhco6H1BHINfav7LH/BR3xJ4E1Kz8P/ABLu5/EnhhysS6rIN97ZdgzN1mT1DZbuCcbT8R0VFfD08RHlqK5VOpKk7xZ/RTpeqWmt6ba6hp9zFeWN1Es0FxA4dJUYZVlI4IIIOa+ZP2//ANnSH4y/CW41/S7Yf8Jf4Zje8tJY1/eTwKN0sHHJ4BZR/eXAxuNeTf8ABK7453WvaDrfwy1Sdpn0lP7R0tnbJFuzBZYvorsrD/ro3oK+/WUOpUjIIwQa+CnGeX4my3j+KPoIuOIpa9T8OfF19qmqaJ4Z+NehTvb67bXyWWt3EPDQ6pEA8N0f+u8YDE95I5c9QK/Xr9nL416f8fvhLovi2y2R3MyeTf2qHP2a6QASJ9M4YZ6qynvXwd8JPhZpWm/tTfGv4Bashi8NeJ7WY2cajJgkQrc2kij1jjkYj3HpWB+xp8TdW/ZN/aR1j4YeMn+yaVqd4NOut5IjhugcQXCk/wADhgM8ZV1Y/dr3cZTjiqTUPiiuZecX/l/W5wUZOlK8tno/U/Vi5tor22lt540mglQpJHIu5WUjBBB6givxF/bI/Z9l/Z6+MuoaVbROPDmo5vtIlOSPJY8xZ/vRtlfXG0/xV+3/AFrw39rn9mm1/aZ+G8ejRzwafr9jcLc6bqE6krESQJEbAztZew7qh7V4+XYv6rW974Xv/mduJo+1hpuj8P1UuwVQWJ4AFfWv7Ov/AATq8dfF77Lq/igSeCfC74cPdRf6bcL/ANM4TjaD/efHUEBhX3b+zt+wp8PfgIttqUlsPFPiuPDHV9SjBELesEXKx/Xlv9rHFfSFepi85b93Dr5v9EclHBdan3HmvwX/AGdvAnwD0b7D4R0SK1ndQtxqU/7y7uf9+QjOM87RhR2Ar0qqOta5p3hvS7nUtWvrbTdOtkMk11dyrFFGo7szEAD618JftEf8FQtJ0H7TovwrtE1u/GUbXr5CtrGemYo+GkPu2F9mFeHSoV8bO8U2+r/4J3znToR10Ps74k/Fbwl8IfD8mteLtctNEsFyFad/nlYfwxoMs7eygmvzr+Pv/BTDxR49u5PDnwn0+40KynfyF1OSMSahcknAESDIjz2xubpgqeK87+G/7Mvxq/bR8Rr4r8U6heW2kXBy3iDXN21kz922h43L1wFCp15Ffox8AP2Qvh7+zzaRy6Jpo1HX9m2XXdRAkuWyOQnGI19lAyOpPWvU9nhMB/E/eT7dF/X9I5eatiPh92P4nxD8B/8Agm940+Kl+vij4r6jeaBY3T+fJaSv5uqXZPJMhbPlZ9Wy3qo61+jPwv8AhB4Q+DXh9NG8IaHa6NZjBkaJcyzMP4pJDlnPuxPtXZUV5mJxtbFP33p2Wx00qEKXw79wooorhOgKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKQ9DS0h6GgD4uPU0UHqaKgs+lvgZ/ySrQP+ucn/ox67yuD+Bn/JKtA/65yf8Aox67yrICiiigAooooAKKKKACiiigAooooAKKKKACiiigAoory39pX432P7P3wi1nxXdFJL1E+z6dauf+Pi6cERp9Bgs3+yrVcISqSUI7smUlFNs+KP8Agpl8e7nxb4o0v4NeF3kuvJmim1SO2+Zp7p8eRbgDrt3BiO7Mvda+xP2TfgJbfs8/BzSvDxRG1u4H2zVrhOfMuXA3KD3VAAg9lz1Jr4o/4Jx/BG++K/xO1f4yeLhJfQ2F3I9pNcjJutRf5nl9/LDZ/wB51I+7X6eV7GPnGhCODp7R1fm/6/rQ48OnUk60uu3oIzBFLE4AGSTX4v8A7d37RJ+PPxjuIdNufN8KeHy9jpoVspM2f3s4/wB9gMH+6qe9fdn/AAUU/aK/4VB8J28MaRc+X4o8UI9shjbD21p0ml9iQdi/7zEfdr8getejk2FsniJLyX6s5sbW/wCXa+YUUUV9SeSFFFFABX63/wDBN79nX/hVvwvPjTWLXy/EniiNZYxIuHt7LrEnsX/1h9tgPK18KfsR/s8v+0B8ZLOC+tzJ4W0Xbf6sxHyuoP7uD6yMMY/uhz2r9rY40hjWONQiKAqqowAB2FfL5zi7JYeHXf8ARHq4Kjd+0fyHV+Z3/BSr47Xfj7xxpXwa8KtJeLa3ETahFbfM1zevgQ24x12hgSP7zgdUr7Y/ah+Oln+z58H9X8TymN9TK/ZdLtn/AOW904OwY7hcF2/2UPeviT/gmz8C7z4i+PtW+MvisSXqWlzILCW5GTdXz5Ms5z12Buv958jlK83AQjRjLGVNo7eb/r+tDqxEnNqjHd7+h9kfs9/BO3/Zt+AEWg26o+spaSX2pXMfWa7ZMtg9wuAi+yjuTXzr/wAElbSMeBPiBecGebVIY3buQsRIz+LtX3jdQJdWs0Mg3JIhRh6gjBr4A/4Jc3jeFfFXxc8A3rbL/T7yKVYm4YmN5YZc/QiP86zpzlVw2IlLduL/ABKlFQq00ttT9AZW2xOcE4BOBX872v6lNrOu6jqFwWNxdXEk8hbqWZiTn8TX9EZGQR61+B/7Qfw+n+Fvxq8ZeGZ0ZFstSl8gsMb4GbfE34oyn8a9HI5LmqR66fqc2PTtFnntFFFfWnjhRRRQB9Nf8E49Um0/9rTwpDFu2XsF7BKF/ui1kfn23ItfszX5N/8ABLP4fT+IvjvqHidkYWPh7TpP3gHHnzfu0XPunmn/AIDX6yV8PnMk8TZdEv1PewSapa9z8+fHwGkf8FWfCFxb8Pd2kZl2982c0Zz/AMBAq7/wU/8A2djr3h+0+Kuh22dR0pVtdYWJeZLYn93Nx1KMdpP91h2Ss/RZB8Sv+CrF9dW37+y8M20iuy9vLsxE2fpNMR+Fffus6PZeIdIvdL1G3ju9PvYXt7i3lGVkjdSrKR6EEinVrywtWhNbqKv6a6ChTVWFSL6tnzv+wf8AtEj48fB23g1O5Evivw+EsdS3HLzLj91Of99QQT/eRvavpSvyH06fVv8Agnv+2E8EzTy+E7h9rk8/a9Llb5X93jI/FoiOhr9B/jV+2R8M/gjokN3qOtx6vqN1AtxZ6TpTLNcTo6hkc4OEQgghmIyOmelY4zCP2qlQV4z1Vi6NZcjVR2cdz3BmCgkkADua+Uf2iP8Agof4B+Dn2nSfDzp418UJlDBZSj7Jbt/01mGQSD/CmTxgla+Jvi1+198X/wBrTXv+EU8L2V5puk3jFIvD2gh3lnT/AKbyABnGOv3Ux1HGa90/Z0/4JcxxfZtb+LV35r8OvhzT5flHtPMvX3WM/wDAz0rojgaOFXPjZa/yrf8Ar+rmbrzqvloL5nzxdat8eP2+fF/2eNbnUdOilz5EObbSdPz3Y9M4PUlpCOmelfbv7On/AATj8D/Cf7LrHi/yvG3iZMOBcR/6Dbt/sRH75H9589AQqmvqnwz4W0fwZottpGg6Za6Rpdsu2G0s4ljjQewA/XvWrXPiMxnUj7OiuSHZGtPDRi+aerGoixoqIoVVGAoGABTqKK8c7AooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACkPQ0tIehoA+Lj1NFB6mioLPpb4Gf8kq0D/rnJ/6Meu8rg/gZ/ySrQP+ucn/AKMeu8qyAooooAKKKKACiiigAooooAKKKKACiiigAooooATpX5P/ALX3xI1b9rz9pjSPhr4Ok+1aPpt2dNsyhzFLcE/6RctjqihSAefljJH3jX2N+3x+0V/wov4PTWOl3PleK/EYeysNjYeCPH76cem1SAD/AHnU9jXk/wDwTC/Z1PhrwxdfFLW7bGp6yjW2krKvMVqD88vPQyMMA/3VyOHr3cFFYWjLGT32j69/68zgrt1ZqjH1Z9j/AAp+G2k/CH4e6H4R0SPZYaXbrCrEYaV+ryN/tMxZj7mtrxJ4h0/wloGo61q1ylnpmn273VzcSH5Y40UsxP4CtKvzz/4Ki/tF/YbC0+E2iXWJ7kJe648bcrHndDAf94gSEegTsxrz8PRnjK6h33f5nRUmqML9j4j/AGi/jVqHx9+LWteLb3fHbzyeTYWrnP2a1QkRx/XHJx1ZmPevNKKK/RoQjTioR2R81JuTbYUUUVQgqW0tZr66htreJ57iZxHHFGpZnYnAAA6kntUVfbP/AATO/Z0/4T/4gS/ETWbXfoXhuQLYrIvyz32AVI9RECG/3mT0Nc+Irxw9J1ZdDSnTdSaij7p/Y8/Z/h/Z6+DenaRPEn/CRX+L7V5hgkzsB+7B/uxjCjtkMf4q9wJwMmlr5a/4KCftFf8ACk/hDLo+lXXleK/EyvZ2hRsPbwYxNN7EAhVP95wR901+exVTGV7fakz6NuNGn5I+Pv2qfiDq37Zv7UOkfD3whL9o0PTrptNsXQ7omfObm7bHVQFOD/cjBH3q/T/4Z/D3SfhV4D0TwnokPk6bpdssEeR8znqzt6szFmJ9WNfH3/BMb9nX/hD/AAZcfE3W7XbrGvRmHTFkX5obIHJcehkYA/7qqRwxr7ortzCrFNYal8MPxfUxw8HZ1Z7y/IK/Ob4mXB/ZI/4KC6f4zmBtfB3jZT9rm6Iol2rcZP8AsTCOY+zCv0ZrxD9rz9na3/aO+E13o0Ijh8RWJN5pF1JwFmA5jY9lcfKfQ7W521zYOrGnUcanwyVn8+vyNK0HKN47rVHtqOsiKykMrDIIPBFfF/8AwUN/ZGu/jDosPjvwjaNc+LNJg8q6sIVy9/bAkjaO8iZJA6sCR1Cgw/sG/tSTanbD4O/EF5NL8caCTZ2X275Huoo+PJbP/LWMDGP4lAPJDGvtin+9y7EXW6+5r/gh7mJp+v4H8580MlvM8UqNFKjFWRxgqR1BHY0yv2n+P/7Cnw3+PV1Pq01tJ4a8TSnc+raUFUzt6zRn5X+vDf7VfI/iD/gkp42t7qQaH410G/t93yNfxTWzke4VZAD+NfWUc2w1SPvPlfmePPB1YvRXR8IVv+BfAmvfErxRY+HvDemz6rq964SK3gXJ92J6KoHJY8AcmvurwV/wSR1WS8R/Fvju0t7VcFodGtWld/YPJtC/XafpX238Ef2cPAf7P2ktaeEdHW3upkC3Op3J827ucf35D2zztUBfas8Rm9CnH917z/Aqng6kn7+iM39lj9nuw/Zw+FVn4chkS71advteqXyDAmuGABC99igBVz2GepNdl8W/iTpvwh+G/iDxfqzgWml2rTeWWwZZOkcY93cqo9zXWTzx20LyyusUSKWd3OAoHJJPYV+bf7QXxJ1f9u742aV8I/h3Ox8EaXcefqWropMUpXh7gnvGgJVBxvZs91I+YoU5Yys51HpvJ+X9bHq1JKjBRjvskd3/AMEx/AOparD45+L+vqz6l4mvHgt53GDIvmGS4kHs0pA+sRr7srC8DeC9K+HfhDSPDWiW4tdK0u2S2t4x12qOpPdicknuST3rdrDFVvrFaVTp09OhpSh7OCifLv8AwUA/ZzPxv+EUmq6Ta+d4s8Nh7yzEa5e4hx++gHckgBlH95AB9418b/s7f8E2/GnxQNrrHjp5vBfh1sMIJUzqFwvosZ4iHu/I/ukV+tVFdVHMa1Cj7GH39jKeGhUnzyOB+EPwK8E/AzQhpfg/Q4NNVgBPdEb7m4I7ySn5m+nQZ4ArvqKK82UpTfNJ3Z0pKKsgoooqRhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSHoaWkPQ0AfFx6mig9TRUFn0t8DP8AklWgf9c5P/Rj13lcH8DP+SVaB/1zk/8ARj13lWQFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFVdV1S00TTLvUb+4jtLG0ieeeeVsJHGoLMxPYAAmrVfB3/BT39oo+GPC1r8LtEucaprKC41Z425itAfki46GRhk/7K4PD11YahLE1VSj1MqtRUoOTPndjq3/BQn9sLA8+HwpA/uPsmlwt+jyE++Hl9BX63aTpVpoWl2enWFvHaWNpCkEEES4SONQFVQOwAAFfN37Av7Ov/Cjfg/Df6pbeV4r8RhL2+3rh4IsfuYPbapLEf3nYdhX05XXmFeNSapU/ghov8zHD03GPPLdnC/G34s6X8EfhjrnjDViGh0+AmGDdhriY8RxL7sxA9hk9BX4ReN/GWqfEPxdq/iXW7g3Wq6pcvc3Ep6bmOcAdlHAA7AAV9af8FK/2i/8AhY/xHj8A6Ndb/D/hmVhdNG3y3F9jDn3EYJQf7Rk9q+L6+kyrCewpe0l8UvyPMxdb2k+VbIKKKK9w4AooooA6DwB4H1X4leNNH8L6JAbnVNUuUtoE7Ak8sx7KoyxPYAmv3f8Ag38LNK+C/wANdC8H6Oo+y6bAEebbhp5TzJK3uzEn2zjoK+MP+CXn7On9kaPd/FfW7XF3fq9noqSLykAOJZx7uRsB9Fbs1foHXxWb4v2tT2Mdo/n/AMA9zB0eSPO92Utb1my8O6PfarqVzHZ6fZQPcXFxKcLHGilmYn0ABNfkppNtq3/BQj9sGS5uFni8J2775FJx9k0uJvlTPZ5Cf++pGPQV77/wVA/aJOiaDafCnQ7k/wBoaoq3WsNEeY7fOY4eO7sNxH91R2evaf2Ef2dh8Bfg5by6lbCLxX4gCX2pFlw8Ix+6gP8AuKTkf3mf2qaH+xYZ4h/HPSPp3HU/f1VTWy3PorTtPttJsLaxs4EtrS2jWGGGJdqRoowqgdgAAMVYoorwT0Aorzf4j/tGfDj4Ra5Bo/i/xXZ6HqU1ut1Hb3CuWaIsyhvlUjGUYfhXKf8ADb/wN/6KJpn/AHxL/wDEVvGhWkrxg2vRmbqQTs2jiv2vf2KbP45uni/wjcp4e+I1kFaO8VjHHe7PuLIy8q64G2QcjAByACvk3wi/b68R/CHWF8A/tB6Ff6bqVpiNdeWAmQr0DTRr/rF4OJY859Dy1fR3/Db/AMDf+iiaZ/3xL/8AEVx/xL/aB/Zc+MGinSvGHiTQNctAD5ZuIZRJCT1McgQMh91Ir1KTquCo4ik5RW2juvT/ACOWajzc9OaT/Bnv3gf4k+FfiVpS6l4W8Qafr1mQCZLG4WTZnswByp9mANdLX5P+L/gp+z3Zao2q/Db9oN/Cd4p3RQ3Uc0oQ+iyxhHUfXcax18cfEnw6PJ0v9qrRb62XhDc6rfs+PcSW7Y/M1X9mxnrTm16xa/QX1lx+Jfc0frvnFeZ/Fr9pL4c/BKzll8V+J7O0u0XK6bC4mvJPTEK5bn1IA9SK/NJ9S8V+NB5Hiv8Aay0u2sX4eK01HUZQQeuYxFGp/Ou9+GHwe/ZH8KXcd/4u+K6+Ob9W3mO4WW2tWbrkxqpc8+rkHuKP7OhT1qSb8oxf5sPrEpaRSXq0afjD4z/Fz9v/AFmfwd8NtIuPCnw63+XqGpXLFRKn/TeVeOR/yxjyTnksOR9qfs6/s5+GP2b/AASuiaDGbi+n2yajqsygTXkoHU/3VGTtQcAE9SSTyWgftffs8+FdJt9L0bxnoWlabbrshtLO2eKKMeiqqACtD/ht/wCBv/RRNM/74l/+IrKu69SPsqVJxh2s9fNvqXTUIvnlNOX9bHudFeGf8Nv/AAN/6KJpn/fEv/xFH/Db/wADf+iiaZ/3xL/8RXB9Wr/yP7mdHtYfzL7z3OivDP8Aht/4G/8ARRNM/wC+Jf8A4ij/AIbf+Bv/AEUTTP8AviX/AOIo+rV/5H9zD2sP5l957nRXhn/Db/wN/wCiiaZ/3xL/APEUf8Nv/A3/AKKJpn/fEv8A8RR9Wr/yP7mHtYfzL7z3OivDP+G3/gb/ANFE0z/viX/4ij/ht/4G/wDRRNM/74l/+Io+rV/5H9zD2sP5l957nRXhn/Db/wADf+iiaZ/3xL/8RR/w2/8AA3/oommf98S//EUfVq/8j+5h7WH8y+89zorwz/ht/wCBv/RRNM/74l/+Io/4bf8Agb/0UTTP++Jf/iKPq1f+R/cw9rD+Zfee50V4Z/w2/wDA3/oommf98S//ABFH/Db/AMDf+iiaZ/3xL/8AEUfVq/8AI/uYe1h/MvvPc6K8M/4bf+Bv/RRNM/74l/8AiK9N+H3xK8MfFXQP7b8J6zba5pfmtCbi2JwrrjKkEAg8g4I6EHvUTo1aavOLS80NTjLRM6aiiisSwooooAKKKKACiiigAooooAKKKKACiiigAooooAKQ9DS0h6GgD4uPU0UHqaKgs+lvgZ/ySrQP+ucn/ox67yuD+Bn/ACSrQP8ArnJ/6Meu8qyAooooAKKKKACiiigAooooAKKKKACiiigDlPip8SNJ+Efw+1zxdrcnl6fpdu0zKDhpW6JGv+0zFVHuRX5kfsifDjVv2v8A9prV/iT4xj+1aPpt2NSvA4Jilnz/AKPbLnqihQSOfljAP3hXUf8ABR744X3xU+JekfBvwkZL6Kwuo1vIbY5N1qD/ACpCPXYGx/vOQeVFfc/7NHwQsf2fvhFo3hS2CSXyL9o1K6Qf8fF04HmN9BgKv+yq170f9hwnP9upt5I89/7RW5fsx/M9S6V4P+2d+0HH+z38Gr/UbSZV8S6pmw0iM8kSsPmlx6RrlvTO0H71e7TzR20MksrrHFGpZ3c4Cgckk9hX4l/tpftCyftB/GS+vrOZm8MaVusdIjz8rRA/NNj1kYbvXbsB6VzZbhfrVb3vhWr/AMjXE1vZQ03Z4PcXEt3PJPNI0s0jF3kc5ZmJySSepqOiiv0A+dCiiigAr1H9mr4IX37QHxd0bwpah47J3+0ajdIP+Pe1QgyP9TkKv+0y15d1r9h/+Cev7Ov/AApj4Rpr2rWvleKvE6pd3AdcPb22Mww+xwd7D1bB+6K83H4r6rRcl8T0X9eR04el7WdnsfTug6FY+GNEsNI0y2Sz06wgS2treIYWONFCqo+gArnfi98TtJ+Dfw413xfrL4s9MtzIIwcNNIeI4l/2mYqo+tdjX5e/8FEfjTqHxm+LWj/Bzwfvv7fTrxIZ4rc5+16k52CP6RhtvszPn7or4vB4d4qsovbdvyPcrVPZQut+hi/sX/DHVv2rv2j9Y+KPjJPtml6ZeDUbkuMxz3ZOYIFB/gQAHHOFRFPDV+rnSvNP2dfgtp/wC+E2i+EbLZJcQR+df3SDH2m6cAySfTPAz0VVHavS6eOxP1irePwrRegqFL2cNd3uFFFFeedJ+T3/AAVe5/aJ8P8A/YsW/wD6VXVev+BP+CW3gLxV4I8P61ceKvEUVxqOn293JHGYNqtJGrEDMecAmvIf+Crv/JxXh/8A7Fi3/wDSq6r9M/hENvwp8GD00azH/kBK+mr4irh8HQdKVrnl06cKlepzK58j/wDDpj4ef9Dd4l/O3/8AjdH/AA6Y+Hn/AEN3iX87f/43X3LRXlf2ji/+fjOv6tR/lPhr/h0x8PP+hu8S/nb/APxuj/h0x8PP+hu8S/nb/wDxuvuWij+0cX/z8YfVqP8AKfDX/Dpj4ef9Dd4l/O3/APjdH/Dpj4ef9Dd4l/O3/wDjdfctFH9o4v8A5+MPq1H+U+Gv+HTHw8/6G7xL+dv/APG6P+HTHw8/6G7xL+dv/wDG6+5aKP7Rxf8Az8YfVqP8p8Nf8OmPh5/0N3iX87f/AON0f8OmPh5/0N3iX87f/wCN19y0Uf2ji/8An4w+rUf5T4a/4dMfDz/obvEv52//AMbo/wCHTHw8/wChu8S/nb//ABuvuWij+0cX/wA/GH1aj/KfDX/Dpj4ef9Dd4l/O3/8AjdH/AA6Y+Hn/AEN3iX87f/43X3LRR/aOL/5+MPq1H+U+Gv8Ah0x8PP8AobvEv52//wAbo/4dMfDz/obvEv52/wD8br7loo/tHF/8/GH1aj/KfDX/AA6Y+Hn/AEN3iX87f/43R/w6Y+Hn/Q3eJfzt/wD43X3LRR/aOL/5+MPq1H+U+Gv+HTHw8/6G7xL+dv8A/G6P+HTHw8/6G7xL+dv/APG6+5aKP7Rxf/Pxh9Wo/wAp8Nf8OmPh5/0N3iX87f8A+N0f8OmPh5/0N3iX87f/AON19y0Uf2ji/wDn4w+rUf5T4R1H/gkv4GbT7kWPjHX0vTE3kNcCFoxJg7SwCAlc4yAQcd6+bP2V/jPrn7GPx81Pwf4zSSy0K5uhYazbPkrbyA4juk9QAQcj7yNnnC1+wNfFH/BRz9lj/hZfhFviJ4btN/ifQoD9uhhX5r2zXJJx3ePkjuV3DnCiu/CY515OhineMtPRnPWoKCVSkrNH2nb3EV3BHPDIssMih0kQgqykZBBHUVJXwV/wTU/al/4SrRF+FXiW7zq+mRF9Fnmbm4tlGWgyerRjkf7HH8HP3rXkYnDyw1V059DspVFVipIKKKK5jUKKKKACiiigAooooAKKKKACiiigAooooAKQ9DS0h6GgD4uPU0UHqaKgs+lvgZ/ySrQP+ucn/ox67yuD+Bn/ACSrQP8ArnJ/6Meu8qyAooooAKKKKACiiigAooooAKKKKACvHP2sPj1bfs9fB3VfEO9G1qcfY9Jt358y6cHaSO6oAXPsuOpFexMwVSScAckmvyU/aO8cat+2/wDtV6V4I8KTGXw9Y3DadYSr80QQHNzeH1GFJHqqJ3NelgcOq9W8/hjqzmxFT2cPd3ex6F/wTO+Atz4w8V6p8ZfFCSXfkTyxaXJc/M090+fPuCT127ioPdmbutfpVXPfD7wNpXw08FaN4X0SAW+l6VbJbQp3IA5Zj3Zjlie5JNT+NfGGl/D/AMJ6t4j1q4FrpWmWz3VxKeyqM4A7k9AO5IFZYqvLF1nNeiXl0Ko01Rhb7z5M/wCClH7Rf/CtPhsngTRrny/EXieNluGjb5rex6OfYyHKD28zuBX5M13nxx+LeqfHH4oa54w1UlZL+Y+Rb7si3gXiOIeyqBz3OT1NcHX3GBwqwtFQ6vV+p4Ner7WbfQKKKK9A5wooq1pWl3et6naadYW8l3fXcqQQQRLl5JGIVVA7kkgUbAfSH7A/7Ov/AAvT4ww32qW3m+FPDhS9v965SeTP7mA+u5gSR/dRh3FfswAAABwBXkX7K/wItP2e/g9pPhpVjfVpB9r1W5T/AJa3Tgb+e6qAEHsoPUmvXHdY0Z2IVVGSScACvz3MMV9arNr4Vov68z6PDUvZQs92eK/tefH6D9nn4N6nrcUiHX7wGy0iBud1wwPzkd1QZc9jgD+IV8lf8Ex/gDPr+t6l8ZPEsb3DLJLb6Q9zlmlnbInucnrjJQHuWk7gV5h8dvF+rft2ftZab4R8Mzs/huynawsJlG6OOBTm5vD/AL20kdMhYx1Nfqp4I8G6X8PfCOkeGtFtxa6VpdslrbxDrtUYyT3Y9Se5JNddX/YcKqS+Oer8l2/rzMYfv6vP9mO3qblFFFeCegFFFFAH5P8A/BV3/k4rw9/2LFv/AOlV1X6b/Cpdnww8Ir6aRaD/AMgpX5kf8FXf+TivD3/YsW//AKVXVfp38Ml2/DfwqPTSrUf+Qlr3sb/udD5nn0P49Q5H9qPxbq3gT9n/AMb6/oV42n6vYWDTW10iqxjfcoyAwI79xX5Nf8N3fHb/AKKDef8AgLb/APxuv1O/bQ/5Nb+I3/YLb/0Ja/Dau/J6NOpRk5xT16ryOfGzlGa5XbQ97/4bu+O3/RQbz/wFt/8A43R/w3d8dv8AooN5/wCAtv8A/G68Eor3/qtD/n2vuR5/tan8z+897/4bu+O3/RQbz/wFt/8A43R/w3d8dv8AooN5/wCAtv8A/G68Eoo+q0P+fa+5B7Wp/M/vPe/+G7vjt/0UG8/8Bbf/AON0f8N3fHb/AKKDef8AgLb/APxuvBKKPqtD/n2vuQe1qfzP7z3v/hu747f9FBvP/AW3/wDjdH/Dd3x2/wCig3n/AIC2/wD8brwSij6rQ/59r7kHtan8z+897/4bu+O3/RQbz/wFt/8A43R/w3d8dv8AooN5/wCAtv8A/G68Eoo+q0P+fa+5B7Wp/M/vPe/+G7vjt/0UG8/8Bbf/AON0f8N3fHb/AKKDef8AgLb/APxuvBKKPqtD/n2vuQe1qfzP7z3v/hu747f9FBvP/AW3/wDjdH/Dd3x2/wCig3n/AIC2/wD8brwSij6rQ/59r7kHtan8z+897/4bu+O3/RQbz/wFt/8A43R/w3d8dv8AooN5/wCAtv8A/G68Eoo+q0P+fa+5B7Wp/M/vPe/+G7vjt/0UG8/8Bbf/AON0f8N3fHb/AKKDef8AgLb/APxuvBKKPqtD/n2vuQe1qfzP7z3v/hu747f9FBvP/AW3/wDjdH/Dd3x2/wCig3n/AIC2/wD8brwSij6rQ/59r7kHtan8z+8/Y/8AYQ/arP7QfgSXSfEF0j+OdEUC8OApvIScJcBRgZ/hYDgHB43AV9RsoZSCAQeCDX4BfBv4sa18E/iLo/i/QZdt5YS5eEkhLiI8PE/+yy5HtwRyBX7ofCj4naL8YvAGj+LdAn87TtRhEgUkb4XHDxuOzKwKn6ccYr47NMF9Wqe0gvdf4Pt/ke1ha/tY8st0fl/+2v8AAHVP2WvjHp3xC8D+Zpvh+/vBeWM1sMDTrwHe0PoFOCyg8Fdy4wvP6J/sw/H/AEz9ov4V6f4ktPLg1SMC21SxU821yANwHfa33lPofUGur+LXwu0T4y/D/WPCOvw+bp+oRFN4A3wyDlJUPZlYAj6YPBNflH8IvHPif9gX9pi/0PxGkjaM0q2mrQxg7Lq1JzFdRDuVB3DvyyHBJxvF/wBpYfkf8SG3mv6/rUzf+y1Ob7MvwP2MoqppGrWevaXZ6lp9zHeWF3Ck9vcQtuSWNgCrKe4IINW6+d2PSCiiigAooooAKKKKACiiigAooooAKKKKACkPQ0tIehoA+Lj1NFB6mioLPpb4Gf8AJKtA/wCucn/ox67yuD+Bn/JKtA/65yf+jHrvKsgKKKKACiiigAooooAKKKKACiis7xF4g0/wnoOo61qtylnpun273NzcSHCxxopZmP0ANNK7sgPl7/goj+0V/wAKe+EzeGtIufL8UeKEe2jMbYe3tek0vsSDsU+rEj7tct/wTN/Z1/4QLwDN8Rdattmu+I4wtisi/NBY5yD7GUgN/uqnqa+Y/Belat/wUD/a+uNV1OOaPwrbyCe4jJOLXTomxHACOjyE4OO7uw6V+uNpaQ2FpDbW0SQW8KCOOKNQqooGAAB0AHavdxL+p4dYWPxS1l/l/X6nn0v39R1XstETV+bf/BUb9ov7Vd2nwl0S6/dQFL3XHjb7z/ehgP0GJCPUx+hr7b/aH+M+nfAT4T634uv9kk1vH5VlascfabpsiOP6Z5OOiqx7V+FHibxHqPjDxDqWuatcveanqNw91czydXkdizH8zWmT4T2k/byWkdvX/gE42tyx9mt2ZlFFFfZniBRRRQAV94/8Ewv2dP8AhKPFVz8Udbtd2maM5t9JSReJbsj55R6iNTgf7TZHKV8c/Cv4b6t8XfiDofhHRI/M1DVLhYVYjKxL1eRv9lVDMfYGv3g+GPw80n4UeAtE8J6JF5Wm6XbLBHkDdIerO3+0zFmPuxrwc2xXsaXsovWX5f8ABPQwdHnlzvZHUV8hf8FG/wBov/hU/wALP+ER0e68vxN4pjeAmNvnt7PpLJ7Fs7B9XI5WvqjxT4m03wZ4b1PXtXuUs9L063e6uZ36JGikk+/A6d6/J/4ZaBq37fv7Xd7r2twyr4WtZRd3cTH5bexjbENqD03PwDjGcyMOlfPZfRjKTr1fghq/Xoj0cRNpKnHeR9S/8E1P2df+FcfDiTx9rNts8Q+J41NsJF+a3sc5QexkOHP+yI/evtCo7e3jtYI4YY1ihjUIkaDCqoGAAOwqSuHEVpYiq6kup0U4KnFRQUUUVzmgUUUUAfk//wAFXP8Ak4rw9/2LFv8A+lV1X6ffDobfh/4ZHpplsP8AyEtfmD/wVc/5OL8Pf9izb/8ApVdV+oXgJdngbw8PTTrcf+Q1r3cb/ueH+ZwUP41Q8z/bQ/5Nb+I3/YLb/wBCWvw2r9yf20P+TW/iN/2C2/8AQlr8Nq9bJP4MvX9EceP+NegUUUV9EeaFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFfW3/AAT6/alPwT8f/wDCK6/d+X4M8QTKjvI2Esbo4VJvZW4V/ba38PPyTR0rCvRjiKbpz2ZdObpyUon9GQIYAg5Br5X/AG+P2W1+O/w8OvaFah/G2gRNJbBF+e9t+r259T1ZP9rI/jJrmf8AgnP+1N/wtTwWPAPiK73+KtAgAtZpW+a9sxgKc93j4U9yNp5O419n1+ftVcBiPOP4/wDDn0a5MRT8mfnJ/wAE0P2o2glHwg8UXRXl5NBnnbGDy0lqSfxZP+BD+6K/Ruvy1/4KG/s2Xfwj8eW3xa8GJJY6VqF4s12bTKnT7/duWVSPurIRuB7OD/eUV9pfsd/tJ2n7R/wst7+d44vFOmBbXWLVcDEmPlmUdkkAJHoQy/w5rux9GNWKxlH4Zb+T/r+tTnw83BujPdbeh7xRRRXhneFFFFABRRRQAUUUUAFFFFABRRRQAUh6GlpD0NAHxcepooPU0VBZ9LfAz/klWgf9c5P/AEY9d5XB/Az/AJJVoH/XOT/0Y9d5VkBRRRQAUUUUAFFFFABRRRQAV+e//BUH9odrSxsvhHoNwWu73Zd60YTlhHnMNvx3YgOR1wE7NX2h8a/ivpXwS+GWueMNXYGDT4C0UG7DXEx4jiX3ZiB7DJ6Cvzi/YZ+FGq/tM/tA6x8WPGSm+0/Sr038ryL8lzfsd0UYB/hjGGx22xjoa9nL6UYc2Lq/DDbzfQ4sRJu1GG7/ACPs/wDYg/Z4X4AfBu0iv7cR+Kda23+qsR80bEfu4PpGpwR/eLnvX0N0oqrqlguq6bd2TTTW63ETwmW3fZIgYEblbswzwexrzKtSVao6k92dUYqEVGPQ/I7/AIKL/tFf8Lc+Kx8K6RdeZ4Y8Lu9upjbKXN50lk9wuNi/RiOGr5Hr9odO/wCCd/wHsX3y+D5b+TOd91ql0cn3AkAP5V1mmfsb/BTSMeR8ONDfH/PzAZ//AEYWr6elmuGw9NUqcXZen+Z5U8JVqScpNan4ZYJ7U+OCSVgqRs7HgBRkmv330z4FfDfRdv2DwB4YsyOhg0i3Q/mErqtP0HTdJXbY6fa2a9MW8KoP0FDzyP2af4/8AFgH1kfz/aZ8NfF2tY/s/wAL6zfbun2awlkz+Smut0z9l34vaxj7N8NfFGD0abSpolP4uoFfvEFA6AUtYPPJ/ZgvvNFgI9ZHxR/wTr/ZO1P4P6bqvjPxnpbad4r1DNnaWc+DJaWwILMcZw0jAfRUH94ivteiuA+O3xe0z4GfC3XPGGqFXWyhIt7Ytg3Nw3EUQ+rYyewye1eJVq1MZW5nuzuhCNGFlsj4t/4Kf/tCSSGw+D/h+ZpLicx3etCA5Y5IMFvgdycSEf8AXP1NfSv7Fv7Pcf7PnwbsbG8hVfE2q7b/AFeTHzLKR8sOfSNfl9N28jrXxb+wR8IdT/aG+OesfF3xkGvrLS703nmSr8t1qLncgA/uxAh8DofLHSv1Or0cdJYenHB0+msvN/1+hzUE6knWl129AooorwzvCiiigAooooA/J/8A4Kuf8nF+Hv8AsWbf/wBKrqv1G8FLt8HaEvpYQD/yGtflz/wVc/5OL8Pf9izb/wDpVdV+pXhIbfCujD0s4R/44K9zG/7nh/R/ocFD+NU+R5X+2h/ya38Rv+wW3/oS1+G1fv8A/Gb4cD4vfC/xH4ObUDpY1i1NsbwQ+b5WSDnZuXPTpkV8P/8ADoSD/oqUn/giH/yRXVleMoYalKNWVm32Zli6FSrJOCPzgor9H/8Ah0JB/wBFSk/8EQ/+SKP+HQkH/RUpP/BEP/kivZ/tXB/z/g/8jh+qVv5fxR+cFFfo/wD8OhIP+ipSf+CIf/JFH/DoSD/oqUn/AIIh/wDJFH9q4P8An/B/5B9Urfy/ij84KK/R/wD4dCQf9FSk/wDBEP8A5Io/4dCQf9FSk/8ABEP/AJIo/tXB/wA/4P8AyD6pW/l/FH5wUV+j/wDw6Eg/6KlJ/wCCIf8AyRR/w6Eg/wCipSf+CIf/ACRR/auD/n/B/wCQfVK38v4o/OCiv0f/AOHQkH/RUpP/AARD/wCSKP8Ah0JB/wBFSk/8EQ/+SKP7Vwf8/wCD/wAg+qVv5fxR+cFFfo//AMOhIP8AoqUn/giH/wAkUf8ADoSD/oqUn/giH/yRR/auD/n/AAf+QfVK38v4o/OCiv0f/wCHQkH/AEVKT/wRD/5Io/4dCQf9FSk/8EQ/+SKP7Vwf8/4P/IPqlb+X8UfnBRX6P/8ADoSD/oqUn/giH/yRR/w6Eg/6KlJ/4Ih/8kUf2rg/5/wf+QfVK38v4o/OCiv0f/4dCQf9FSk/8EQ/+SKP+HQkH/RUpP8AwRD/AOSKP7Vwf8/4P/IPqlb+X8UfnBRX6P8A/DoSD/oqUn/giH/yRR/w6Eg/6KlJ/wCCIf8AyRR/auD/AJ/wf+QfVK38v4o/OCiv0f8A+HQkH/RUpP8AwRD/AOSKP+HQkH/RUpP/AARD/wCSKP7Vwf8AP+D/AMg+qVv5fxR8BfDzx9rPwv8AGukeKdAuTaatpk4nhfsezIw7qwJUjuCRX7nfAX40aN8e/hlpXi7RmCC4Xy7u0LZe1uFA8yJvoeQe6lT3r4u/4dCQf9FSk/8ABEP/AJIr3b9lT9jfVv2Xdf1K4tfiG+vaJqUQW60iXSvJUyL9yVX85trDJB4OQcHoCPHzLEYTFQ5oS95eT18tjtwtOtRlaS0Z9B+NvBuk/ELwnqvhvXbRL7SdSga3uIH7qe4PYg4II5BAI6V+RllP4q/4J4/tSNHN517ou7a4Hypqmmu3DDtvXH4OhHI6/sdXz9+2d+zRbftG/C6a3s4o4/Fukh7nSLlsDc2PmgY/3ZAAPZgp6A583AYmNKTpVfglo/8AM6sRSc0pw+JHtfhPxVpfjjw1pmv6LdpfaVqMCXNtcRnh0YZH0PYg8g5BrWr8w/8AgnL+0tc/DnxdN8H/ABjJJaWF5dOmmfa8qbK93EPbsD90OwOB2fjHznH6eVz4vDSwtVwe3R90aUaqqw5goooriNwooooAKKKKACiiigAooooAKQ9DS0h6GgD4uPU0UHqaKgs+lvgZ/wAkq0D/AK5yf+jHrvK4P4Gf8kq0D/rnJ/6Meu8qyAooooAKKKKACiiigAoorw/9r/45y/Av4P39/paPceKNTzY6RBEhdvOYcy7RniNct6Z2g/erSnTlVmoR3ZMpKCcmfEn/AAUA+MWpfHz416P8IPBxa/s9LvVtWihb5brUnOw59ogSmT0Jkzxiv0I+AXwd034EfCrQ/B+m7ZDZxbru5UYNzcNzLIfq3TPRQo7V+NPwv074x+DPGEfirwb4b8Qt4gAkEd+mhveODICHYb4nG4gkbsZ5PPNe2nWf21PF3/LPx1Bv/wCnT7D/AOypivq8Vg+anChCpFRj3e7PIpVrSlUlFtv8j9ayQKa80calndVUckk4Ar8lD+zt+2L4u5vbjxU8bdTf+KUUD/gJuM/pSr/wTh+PviZg2q3umRseSdR1h5cf98q9eZ/Z9BfFiI/n+p1fWKj2ps/UnU/iT4R0TP8AaHijRrDHX7TfxR4/NhXI6p+1L8INHz9p+JfhckdVh1SGUj8EYmvgPTP+CTfxGnx/aPi/w3ag9fs7XE2PzjWus0z/AIJEXb4Oo/EyGL1W20Yvn8TMP5UfVcDH4q9/Rf8ADh7XEPan+J9Rap+3t8B9IyJfH9tKw7W1lczZ/FIyK5DVP+Cm3wS0/PkX+salj/n201hn/v4VrznTP+CSXhCLH9o+OtauvX7NbRQ/z3112l/8Ervg/Y4NxqHifUD38++iUH/viFf50cmWR+1J/wBegc2KfRIyNU/4Kx/DSDI0/wAL+KLwjoZoreIH8pWP6VyGqf8ABXfT48jTvhpc3Ho11q6xfosLfzr3PTP+CcfwH0/Hm+FbrUCO9zqlyP8A0B1Fdbpn7FPwQ0kDyPh1pL4/5+Q8/wD6Gxp+1y2O1OT+f/BDlxT+0l/XofGGp/8ABW7xbNn+zvAWj2vp9pu5Zsf98hK8V+LH7R/xN/bY8Q+FPB9zYafbs17sstO0mKSOOSaTCiSUu752ru54CgsfWv1m0z9nv4X6Nj7F8OvC1sw/jj0e3DfnszXWaX4X0bRCDp2k2NgR0+zW6R4/ICqjj8LRfNRo2fR3JeHqzVpz0OX+B3wk0v4H/C/Q/B+lANHYQjz7jbg3E7cySn3ZiT7DA6Cu8oorwpSc5OUt2egkoqyCiiipGFFFFABRRRQB+UH/AAVb/wCTjPDv/Ys23/pVdV+pvhpdvhzSx6WsQ/8AHBX5of8ABT74f+KfFXx90K80Tw3q2sWqeHII2nsLGWdFcXNySpZVIzgg49xWJa/tf/tW2dtFBH4bvxHEgRQfC79AMD+Cvp6mGlisLRUJLRPdnlRqqjWm5J6n6uUV+VH/AA2R+1h/0Ll//wCEu/8A8RR/w2R+1h/0Ll//AOEu/wD8RXF/ZNb+aP3/APAN/rcOz+4/Veivyo/4bI/aw/6Fy/8A/CXf/wCIo/4bI/aw/wChcv8A/wAJd/8A4ij+ya380fv/AOAH1uHZ/cfqvRX5Uf8ADZH7WH/QuX//AIS7/wDxFH/DZH7WH/QuX/8A4S7/APxFH9k1v5o/f/wA+tw7P7j9V6K/Kj/hsj9rD/oXL/8A8Jd//iKP+GyP2sP+hcv/APwl3/8AiKP7JrfzR+//AIAfW4dn9x+q9FflR/w2R+1h/wBC5f8A/hLv/wDEUf8ADZH7WH/QuX//AIS7/wDxFH9k1v5o/f8A8APrcOz+4/Veivyo/wCGyP2sP+hcv/8Awl3/APiKP+GyP2sP+hcv/wDwl3/+Io/smt/NH7/+AH1uHZ/cfqvRX5Uf8NkftYf9C5f/APhLv/8AEUf8NkftYf8AQuX/AP4S7/8AxFH9k1v5o/f/AMAPrcOz+4/Veivyo/4bI/aw/wChcv8A/wAJd/8A4ij/AIbI/aw/6Fy//wDCXf8A+Io/smt/NH7/APgB9bh2f3H6r0V+VH/DZH7WH/QuX/8A4S7/APxFH/DZH7WH/QuX/wD4S7//ABFH9k1v5o/f/wAAPrcOz+4/Veivyo/4bI/aw/6Fy/8A/CXf/wCIo/4bI/aw/wChcv8A/wAJd/8A4ij+ya380fv/AOAH1uHZ/cfqvRX5Uf8ADZH7WH/QuX//AIS7/wDxFH/DZH7WH/QuX/8A4S7/APxFH9k1v5o/f/wA+tw7P7j9V6K/Kj/hsj9rD/oXL/8A8Jd//iKP+GyP2sP+hcv/APwl3/8AiKP7JrfzR+//AIAfW4dn9x+q9FflR/w2R+1h/wBC5f8A/hLv/wDEUf8ADZH7WH/QuX//AIS7/wDxFH9k1v5o/f8A8APrcOz+4/Veivyo/wCGyP2sP+hcv/8Awl3/APiKP+GyP2sP+hcv/wDwl3/+Io/smt/NH7/+AH1uHZ/cdr/wUq/Zek0q+Hxh8J27RKzouuw2wwYpMgR3Qx0ycKxHfae7Gvor9hb9qCP9oP4aLY6vcKfGmhIkGoKxw1zH0S5A/wBrGGx0YHoGWvjTWf2r/wBqPxDpF7pepeEru90+8he3uLabwq7JLGwIZSNnIIJFeQ/A1Pi18CfibpXi/RPBHiTzLWTbcWn9l3AS6t2P7yFvk6EdDzghT1Ar1XhJ1cL7KtJc0fhd/wAGcirKFXngnZ7n7g0Vj+EPE1v4y8L6XrlrBc20F/As6wXkLQzRZHKOjcqwOQR6itivkWmnZns7hRRRSAKKKKACiiigAooooAKQ9DS0h6GgD4uPU0UHqaKgs+lvgZ/ySrQP+ucn/ox67yuD+Bn/ACSrQP8ArnJ/6Meu8qyAooooAKKKKACiiigApCoPUA/WlooAQADoBS0UUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAJgHtRgegpaKAEwPQUYHoKWigBMD0FGB6ClooATA9BRgegpaKAEwPQUYHoKWigBMD0FGB6ClooATA9BRgegpaKAEwPQUYHoKWigBMD0FGB6ClooATA9BRgegpaKAEwPQUYHoKWigBMD0FGB6ClooATA9BRgegpaKAEwPQUYHoKWigBMD0FGB6ClooATA9BRgegpaKACiiigAooooAKKKKACiiigAooooAKQ9DS0h6GgD4uPU0UHqaKgs+lvgZ/ySrQP+ucn/ox67yuD+Bn/ACSrQP8ArnJ/6Meu8qyAooooAKKKKACiiigAooooAKKKKACiiigAooooAKK+f/jr4Z/aBh1TUNc+F3jLR7iwKI0PhjU9NiVlKoAwS4OdxZgWw+0DOM4Ar4f1j/gpP8ePBGt3mi69o+g22q2UhhuLW+0yWORHHUECUV6VDAVMSr0pJ+V9V+By1MRGk7TTP1gor8yfhV/wU6+JnjL4jeFfDupeH/CwtNW1W1sJpba2uEkVJZVRiuZyMgMccYr7Y/as+MOq/Af4Ia34z0W0s77UbGS3SOC+VjEfMmSM5Csp4DHvUVcDWo1I0prWWxUK8Jxclsj16ivybuf+CrfxcmyI9E8JQD1WyuCf1uDWPef8FPPjXeZ8mXQrT/rhp2f/AEJmrtWT4p9vvMPrtLzP18or8aLj/go18e5ZAy+KbaBf7iaTbY/WMn9a63wZ/wAFTPivoVzGNcsdE8S2mR5iyWxtpiP9l4yFB+qGnLJsSldWfz/4ALG0n3P1qor57/Zt/bY8CftGMum2jSeH/FQQu2i37gtIAMkwyDAkA9MBuCduOa941fWLHQNNn1DUruGwsLdd81zcOEjjXP3mY8AepPArx6lKpSnyTVmdkZxmuaL0LlFR29xFdwRzQSJNDIoZJI2DKwPIII6ipKyLCiiuY+KGu3Xhf4aeLNZspBDeadpN3dwSFQ2144WZTg8HBA4NOK5mkhN2Vzp6K/H3TP8Agpx8bLBds97ouokfxXOmqCf+/ZWt22/4Ks/F2AYk0Xwlce72VwD+k4r23k2KXb7zh+u0vM/WWivyrT/grL8Swo3+FfCzN6rFcgf+jqd/w9l+JP8A0Knhf/v3cf8Ax2p/sjFdl94/rlHufqlRX5W/8PZfiT/0Knhf/v3cf/HaP+HsvxJ/6FTwv/37uP8A47R/ZGK7L7w+uUe5+qVFef8AwE+Il98V/g34W8X6lb29pfatZC5lhtQwiRiSMLuJOOO5r8+tc/4Kr/EbS9av7OPwr4YaO3uJIlZo7jJCsQCf3vtXJRwVavKUILWO5tOvCmk5dT9RaK/K3/h7L8Sf+hU8L/8Afu4/+O0f8PZfiT/0Knhf/v3cf/Ha6/7IxXZfeY/XKPc/VKivyt/4ey/En/oVPC//AH7uP/jtQz/8FY/igw/c+GPCcZ/27e5b+U4o/sjFdl94fXKPc/ViivyM1T/gqV8ZNQUiC38N6afW2sJCf/IkrV9tfsB/Gjxh8dvhFrPiLxnfx39/FrktnA0VukKpCsEDAYQDPzSNycmsa+XVsNT9pUtYuniYVZcsT6ZorhPjD4d8deI/C6Q/D7xZbeEtdhm83z7ywS7iuE2sPKYNnYCSp3gEjb0Oa/O/4pftn/tM/AHxdL4d8ZR6Qt4g3xSyacphuo84EkboVDKfwIPBAIIrLDYOeK0pyV+3X8i6tZUviTsfqXRX5O6f/wAFWfi1AyrPonhO6XPJazuFb9J8fpX6SfFX4gX3gT4J+I/GVlBbz6hpujyajFBOGMTOse8BgCDjPoc06+BrYdxjP7WwU68Kibj0O+or8mrz/gqx8XLjIh0bwnajsUsrhj/49Of5V1Pwf/a3/ah/aL8RvpHgyHRl8rDXV8dPVLa0UnAaR3LY74UAscHAODXTLKcRCLlNpJd2ZLGU5O0bs/TyiuC+Dvhvx54c8OTR/ELxdbeLtaml8xZbPT0tIrdNoHlrt5fkE7iAecY4rva8iSUW0nc7E7q4UUUVIwooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApD0NLSHoaAPi49TRQepoqCz6W+Bn/JKtA/65yf+jHrvK4P4Gf8kq0D/rnJ/wCjHrvKsgKKKKACiiigAooooAKKKKACiiigAooooAKKKKACvhX/AIKhfAKy8Q/D6H4nabapHrWiPHb6i6DBuLR22qW9SjsuD/dds9BX3VXA/H7w9F4r+B/j3SZVDC60O8Rdwzh/JYo34MAfwrrwlZ0K8Zrv+BjWgqkHFn4j/AH/AJLt8Ov+xj07/wBKY6/Vz/go5/yaT4r/AOu9l/6VRV+UfwCGPjv8Oh/1Men/APpTHX6uf8FHP+TSfFf/AF3sv/SqKvp8w/3yh6r80eVh/wCBU/roflp+zN8MrX4xfHbwd4Rvw7afqF5m7WNirNBGjSyKCORlEYZ7Zr9sfA3wX8CfDWwitPDPhPSdHjjGA9var5re7SEFmPuxJr8pf+CatiLv9qzQ5SATbWN5KPxhZP8A2ev2OrgzqrL2ypp6W/zOjAwXI5W1uZ2peHNK1mFor/TLO+iYbWS4gWQEehBFfPXxs/YB+FfxZ025fTtFg8G68UPk6josQijDdvMgGEcZ68Bv9oV9LUV4VOtUovmpyaPQlCM1aSufgf8AEv4c+Lv2a/irNo2ovLpmvaTOtxZ6haOyiRQcxzwvwcHHB6ggg4IIr9eP2UPjpY/tRfA+O91SCGXVIlbS9csmUGOSTYAzbf7kisDjpyy87a8J/wCCrvw1ttU+GvhvxvDAP7R0q+FhNKvBNvMrEZ9dsiLj08xvWvEP+CVfj6XQfjfrHhiSZhZa9pjOsWeDcQMHQ/gjTfnX1GIax+BVe3vR/p/5nlU/9nr+z6Mdc/Gfxv8A8E/v2gta8Fwz3GufDxbgXNto17KWU2kvzI0DnJR1yVJHysytkHgj9NPhr8R9C+LPgrS/FXhu8F7pOoR+ZG+MMh6MjjsykEEeor4M/wCCt/gmMf8ACA+LolAlP2jS52xyw4kiH4fvfzrC/wCCUXxZurHxl4k+Hl1Ozadf2p1SzjduI54yqyBR/towJ/65CubEUI4rBrFxXvLfzto/8zSnUdKs6L26H6b15n+03qS6T+zt8SrknGPD18i/7zQOo/UivTK8D/bv1X+x/wBk74gzg4L20Nv/AN/LiKP/ANmrwsPHmrQj3a/M9Co7Qk/I/J79nD9nbxD+0l4+Tw9orLZ2kKefqGqTIWitIs4yQPvMTwq5GT3ABI/TfwD/AME3Pgv4PsYV1PR7vxXfqPnu9Uu5FBPfEcZVQPQEE+5qf/gnf8H4fhh+zxpWpzQBNZ8UY1W5kI+bymH+jrn0EeGx2MjV9P162YZhVnVcKUrRWmnU48PhoRgpSV2zxaP9jH4JRqFHw40Ygf3o2J/Mmnf8MafBP/onGif9+T/jXs9FeT9Yrfzv72dns4fyo8Y/4Y0+Cf8A0TjRP+/J/wAa/LD9ujwRoXw7/aV8SaF4b0yDR9It4bRorO2XCIWt42bA9ySfxr9tq/GX/go5/wAnbeLf+uFl/wCksVe5k9WpPENSk3o+vmjgxsIxpppdT9L/ANjP/k1n4df9gpf/AEJq/FXXY1l8d6gjjcrajICD3HmGv2q/Yz/5NZ+HX/YKX/0Jq/FfWv8Akfr7/sJP/wCjTXZlf8ev6/qzHF/w6f8AXY/apP2NPgmUX/i3GidP+eJ/xp3/AAxp8E/+icaJ/wB+T/jXssf3F+gp1fL/AFit/O/vZ6vs4fyo8Vl/Yv8AglMhVvhzowB/uxsp/MNXFeMv+CcPwR8VW0i2egXfhy5ZSBc6XfSZB7HZIXT9K+n6KqOKrxd1N/exOlTe8Ufih+1l+x5r37MGqWdw14Nd8K6i5jtNVSLy2SQDPlSrk7WxkggkMASMYIH3Z/wSyh8r9mu8b/npr9y3/kKEf0r2v9qn4aW3xY+APjPQZoRLcfYJLuzOOVuYgZIiD2yyhT7MR3ryf/gmTZG0/ZdspCP+PjVLuQfgwX/2WvYrYyWKwD5/iTSOKFFUsR7uzR9YV4D+258E7H4z/AXxAjWqya5otvJqmmTqoMiyRqWaMHriRQVI6Z2n+EV79UV1AlzbSwyKHjkQoynoQRgivCpVJUpqpHdHfOKnFxfU/nTTiRfrX7l/tGf8mm+Ov+xXn/8ARBr8RNf03+xfEeo6fkt9lupIMnvtcj+lft3+0Z/yab46/wCxXn/9EGvrc1d50H5/5HkYT4anp/mfhva20t7cxW8KNJNK4REUZLMTgAV+8P7OXwX034DfCTQ/C1jDGt3FCs2o3CDm4u2UGVye4zwPRVUdq/Gn9l7Qk8S/tE/DmwlUPC+u2kkiN0ZUkDsD9QpFfvHXPnlV+5SW25eAgvemFFFFfKnrhRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUh6GlpD0NAHxcepooPU0VBZ9LfAz/klWgf9c5P/Rj13lcH8DP+SVaB/wBc5P8A0Y9d5VkBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAVheO1DeCPEIIyDp9wCP+2bVu1h+Of8AkSfEH/YPuP8A0W1VH4kJ7H4TfAP/AJLx8O/+xj0//wBKY6/Vv/go5/yaT4r/AOu9l/6VRV+UnwD/AOS8fDv/ALGPT/8A0pjr9W/+Cjn/ACaT4r/672X/AKVRV9hmH++UPVfmjxcP/Aqf10Phr/gmIoP7UFsfTSbs/otfr/X5A/8ABMP/AJOfg/7BF3/7JX6/V5Wc/wC8/JfqdmC/hfMKKKK8I7z5d/4KTNEP2UPEIk++byyEf+956/0zX5/f8E7mlX9rzwQI/ust8H/3fsU/9cV9a/8ABV/4j2+mfDXwz4KhnH2/Vb/7fNEp5FvCrKN3oC8i49dh9K8J/wCCWHgObxB8eNS8SNFmy0DTH/e4+7PMfLQfigm/75r63CL2eWVJS63/AMjx63vYqKXS3+Z9Bf8ABWaWJfgp4TiIHnNr6sp/2RbzZ/UrXyl/wTWgnm/at0F4s+XFZXjy4H8PksOf+BFa9j/4K2eO47rxD4F8HwTAvaW8+p3MYOcGRljiz74jk/76re/4JUfBG70231/4n6lbtDFexf2VpW8Y8yMOGnkA9NyIoPqriinJUMrbl9q/4/1cJL2mL06H6HVx/wAWvhZonxp8A6l4P8RC4OkX5iM32WTy5MxyLIuGwcfMg7dM12FFfKRk4tSi9Ueu0mrMqaRpVtoWlWWm2UQgs7OFLeGJeiIihVH4ACrdFFTuMKKKKACvxl/4KOf8nbeLf+uFl/6SxV+zVfjL/wAFHP8Ak7bxb/1wsv8A0lir38l/3l+j/NHn47+EvU/S/wDYz/5NZ+HX/YKX/wBCavxX1r/kfr7/ALCT/wDo01+1H7Gf/JrPw6/7BS/+hNX4r61/yP19/wBhJ/8A0aa9HK/49f1/VnNi/wCHT/rsf0Ix/cX6CnU2P7i/QU6vjz2QooooAiubdLu2lglG6OVCjD1BGDXI/CL4T6F8E/Atl4S8OC4GlWjyyR/apPMkJdy7ZbAzyx7dK7Oiq5mo8t9BWV7hSN90/SlpG+6fpUjP59/ijGIvil4sReFXWLsD/v8ANX7R/tGf8mm+Ov8AsV5//RBr8Xvir/yVXxd/2Gbv/wBHNX7Q/tGf8mm+Ov8AsV5//RBr6/M98P6/5HjYXap/Xc/KL9iRBJ+1T8OgwyP7QJ/KNzX7h1+H37EP/J1Xw7/6/wBv/RT1+4NcWd/x4+n6s3wHwP1CiiivnT0gooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKQ9DS0h6GgD4uPU0UHqaKgs+lvgZ/ySrQP+ucn/AKMeu8rg/gZ/ySrQP+ucn/ox67yrICiiigAooooAKKKKACiiigAooooAKKKKACiiigArD8c/8iT4g/7B9x/6LatysPxz/wAiT4g/7B9x/wCi2qo/EhPY/Cb4B/8AJePh3/2Men/+lMdfq3/wUc/5NJ8V/wDXey/9Koq/KT4B/wDJePh3/wBjHp//AKUx1+rf/BRz/k0nxX/13sv/AEqir7DMP98oeq/NHi4f+BU/rofCf/BM/ULXTf2m7aS7uYbWNtLukVppAgLHbgAnv7V+wgdSMhgR7GvwN+CXwV8QfHrxk/hjwzJaJqotJbtFvZTGjhMZUMAcE54zx6kVoeN9C+LP7P8Aq66Hr0viHwnOuTCiXckcMig8tE6Nsce6k1WNwEcXXuqiUrbf0xUMQ6NPWN13P3jLAdSK8T+On7X/AMN/gRpdy2qa5b6nrqITDoemyrLcyP2DYyIx/tPjgHGTxX5eeEvhp8Xvjvo8z+GPHP8Awm8yoTcaP/wkTpdovfdDcMhZe2VyPevLvE3wy8Q/DDxDb2vj3wxrWjweZiSOWIwPKo6+VIylT9RuFcdHKaXPadS7XRaM3njJ8t4xt5nSfEjx542/a1+M8mo/YZ9T1zVZRbafpVmC4t4QTsiT0VQSSxwMlmOMmv1n/ZR/Z+tP2YPg2NOuSLvXbgHUNYubaMyF5dv+rjABZlRRtAA5O4gAtivmP9kX9pv9mb4YQR6fp+i6j4M1q4Hlz61rsa3TzZ7G4jyVXpkBETgE+tfoJomu6b4l0u21PSb+21PTrlN8N3aSrLFIvqrKSCPpWOZ4ipZUFBxgvxLwtON3UcryPgvSv2KfFX7TPxu1j4nfFuKTw14fvLkPaeHBIDeSWyALDHIVOIRtVd2DuJ3cKTmvvXRdFsfDukWel6ZaRWOnWcSwW9tAgVIo1GFVQOgAFXaK8evialeylstl0R206Uad2t2FFFFcpqFFFFABRRRQAV+Mv/BRz/k7bxb/ANcLL/0lir9mq/GX/go5/wAnbeLf+uFl/wCksVe/kv8AvL9H+aPPx38Jep+l/wCxn/yaz8Ov+wUv/oTV+K+tf8j9ff8AYSf/ANGmv2o/Yz/5NZ+HX/YKX/0Jq/FfWv8Akfr7/sJP/wCjTXo5X/Hr+v6s5sX/AA6f9dj+hGP7i/QU6mx/cX6CnV8eeyFFFFABRRRQAUjfdP0paRvun6UAfz8/FX/kqvi7/sM3f/o5q/aH9oz/AJNN8df9ivP/AOiDX4vfFX/kqvi7/sM3f/o5q/aH9oz/AJNN8df9ivP/AOiDX1+Z74f1/wAjxsLtU/ruflJ+xD/ydV8O/wDr/b/0U9fuDX4ffsQ/8nVfDv8A6/2/9FPX7g1xZ3/Hj6fqzfAfA/UKKKK+dPSCiiigAooooAKKKKACiiigAooooAKKKKACiiigAooooAKKKKACiiigApD0NLSHoaAPi49TRQepoqCz6W+Bn/JKtA/65yf+jHrvK4P4Gf8AJKtA/wCucn/ox67yrICiiigAooooAKKKKACiiigAooooAKKKKACiiigArD8c/wDIk+IP+wfcf+i2rcrD8c/8iT4g/wCwfcf+i2qo/EhPY/Cb4B/8l4+Hf/Yx6f8A+lMdfq3/AMFHP+TSfFf/AF3sv/SqKvyk+Af/ACXj4d/9jHp//pTHX6t/8FHP+TSfFf8A13sv/SqKvsMw/wB8oeq/NHi4f+BU/rofDf8AwTD/AOTn4P8AsEXf/slfqx8Qvht4Z+Kvhu40HxXo1trWlzdYbhMlG7MjD5kYdmUgj1r8p/8AgmH/AMnPwf8AYIu//ZK/X6vLzhuOKTTs7L9TrwSTo2fc/IH9qn9jvxV+yx4jTxn4Kvb+48JJOJLbU7V2W60uQn5VlZcEDPCyDAPQ4JGfaf2Zf289C+Kunw/Dr46Wmm3ouQIINav4Ea1uT0C3KEbUb0kAC+u08n9DNS0201nT7mwv7aK8srmNopredA8ciMMMrKeCCDjBr8lf23/2I7v4HajP4w8IW8t34DupMyQrl30p2PCMepiJOFc9OFbnBbpw2Jp4+KoYnSfSXX/h/wAzKrSlh37Slt1R7J+0v/wTGtLy2uvEXwik8mfBlfw3cy5jkHX/AEeVj8p/2XJB7MOBXyV8EP2iviH+yb42uLW3FzFaxT+XqvhnUwyRyEHDAqeY5B2cDPTORwfc/wBiD9vO5+HFxZeBfiHfSXXhNysNhq0xLPpp6BHPUw/qn+7wPr39q79j3wz+054a/tjSmtdN8ZxwB7DWosGO6TGVjmK/fQjGHGSvBGRlTv7eeGl9Wxy5oPZ/1/w6I9nGqva0NGuh6R8BP2gvCf7Q/g1Nd8M3X72PCXumzkC4s5CPuuvoecMODg46ED0yvwi8K+LPiJ+yH8X5ZIUn0HxJpcnk3lhcgmK5jyCUcA4eNhggg+jKc4Nfr7+zX+0z4Y/aU8GrqmjyCz1i2VV1LRpXBmtXPf8A2kPO1wOehwQQPKx2XvDfvKesH+H9dzrw+IVX3ZaSPYKKKK8Y7QooooAKKKKACvxl/wCCjn/J23i3/rhZf+ksVfs1X4y/8FHP+TtvFv8A1wsv/SWKvfyX/eX6P80efjv4S9T9L/2M/wDk1n4df9gpf/Qmr8V9a/5H6+/7CT/+jTX7UfsZ/wDJrPw6/wCwUv8A6E1fivrX/I/X3/YSf/0aa9HK/wCPX9f1ZzYv+HT/AK7H9CMf3F+gp1Nj+4v0FOr489kKKKKACiiigApG+6fpS0jfdP0oA/n5+Kv/ACVXxd/2Gbv/ANHNX7Q/tGf8mm+Ov+xXn/8ARBr8XvioQfir4uI5H9s3f/o5q/aH9oz/AJNN8df9ivP/AOiDX1+Z74f1/wAjxsLtU/ruflJ+xD/ydV8O/wDr/b/0U9fuDX4c/sUzCD9qf4dMe+pbfzRh/Wv3Grizv+PH0/Vm+A+B+oUUUV86ekFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSHoaWkPQ0AfFx6mig9TRUFn0t8DP+SVaB/1zk/8ARj13lcH8DP8AklWgf9c5P/Rj13lWQFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABXNfE25Fl8N/FVwTtEWlXUmT2xExrpa8c/bB8Xw+Cf2ZviJqEsnlmXSZbGMjr5lwPIXH4yA/hWtKLnUjFdWiJu0Wz8bfgH/wAl4+Hf/Yx6f/6Ux1+rf/BRz/k0nxX/ANd7L/0qir8o/gD/AMl2+HX/AGMenf8ApTHX6uf8FHP+TSfFf/Xey/8ASqKvrcw/3yh6r80ePh/4FT+uh8Kf8EyrkQftS6ehIzNpl2g/74Df+y1+wtfhx+xb40i8B/tP+ANTuH8u3kv/ALBIxOABcI0AJ9gZAfwr9x683OotYhS7r/M6sC702vMKq6nplprWnXNhf20V7Y3UbQz286B45UYYZWU8EEEjBq1RXz+x6J+Qv7b/AOxRd/AjVpvFnhSCW88A3kvKDLvpcjHiNz1MZPCuf91ucFtr9h79um4+EVzaeB/HV1JdeCpWCWl85LvpTE9PUw56jqvUcZFfqnrOjWPiLSbvTNTtIb/T7uJobi2uEDxyowwysDwQQa/JD9tX9iG/+A+pT+KfCkM2o+AbmTJHLyaW7HiOQ9TGTwrn2VucFvq8Ji6eOp/VcVv0f9dfzPIrUZUJe1pbf1+B9+ftQfss+Fv2qvBUN1BNbWniOGDzNI1+DDq6EblSQr9+Js54zjOV6kN+T1vcfET9kX4xEgT+HPFWkSYZG+aK4iPY9pInA+h6jBHHuf7E/wC3Rd/BG4t/B/jSae/8CyviC4AMkulsTyVHVoiTkoOR1XuG++fj5+zz4G/a8+HtnP8Aarc3Zh87RvElhtkMYYZHIOJIz3XP0IPNTCpUy2fsMQuam9n/AF+KHKMcUvaU9JIZ+y1+1t4Y/aW8Nj7O6aV4stIwdQ0SR/mXoDJET9+Mnv1XIBxkE+8V+EPxC+GvxE/ZP+JsEV99q0HWbOQzafq9i7CK4Uf8tIpONwIOCp5GcMB0r7w/Zl/4KY6H4rgtdA+KZi8P60AI012NcWdyemZQP9Sx7n7nU/IOK5sXljS9thvei/6+ZrRxV/cq6M+7qKq6bqlnrNjDe6fdwX1nOoeK4t5BJHIp6FWGQR7irVfPnohRRRQAV+LH/BQu8W8/a68dFG3LH9ijz7izhz+ua/aYnAzX4M/tM+Lo/Hf7QHj/AFuBxLbXGsXCwSKch4kcpG34qqmvo8kjetKXZfr/AMA83HP3EvM/Xz9jP/k1n4df9gpf/Qmr8U/Ecpg8banIBkpqErflIa/az9jP/k1n4df9gpf/AEJq/E7xaceLNZPpezf+hmu7K/49f1/VnPi/4dP+ux/QxbyLLBG6ncrKCCO4xUlef/s/eMoviD8EfBHiCJ/MN5pNu0pznEqoFkX8HVh+FegV8jOLhJxfQ9lO6TCiiioGFFFFABTX4VvpTq5b4p+L4vAPw28UeJJpFjTStNuLsFu7JGxUfUkAAe9VFOTSQm7K7PwT8cXqal46167Q7kn1GeVT6hpGP9a/a/8AaM/5NN8df9ivP/6INfhruLzbicktnJ+tfuV+0Z/yab46/wCxXn/9EGvr81Vp0F5/5HjYTWNT0/zPyI/ZS1NdJ/aT+Gk7HCnXrSHP+/KE/wDZq/d2v56PAmvnwp438P60Oum6hb3nH/TORX/pX9CkMizQpIjBkZQwYHIINcueRtOEvJ/1+JtgH7skPooor5g9QKKKKACvI/2kP2hLH9n/AML6ZdfYBrniDWL6PT9K0ZZ/Ka5kZgGJbaxVVB5ODyVH8Wa1/jX8fPBvwD8Ly6z4q1SO3bYxttPjYNdXbD+GKPOTzjJ4UZ5Ir87vgX4v8QftsftuaN4m16MxaL4f3apBpyMWisoIWBhQHuxmaMscfNzwAAB6eEwjqJ1qi9yOvr5HLWrcrUI/Ez9VEJKKWADEcgetOoorzDqCiiigAooooAKKKKACiiigAooooAKKKKACiiigApD0NLSHoaAPi49TRQepoqCz6W+Bn/JKtA/65yf+jHrvK4P4Gf8AJKtA/wCucn/ox67yrICiiigAooooAKKKKACiiigAooooAKKKKACiiigCOe4itYZJppEiijUs8jsAqgckknoK/LD/AIKKftc6Z8WLq1+H/g29F94c024+0ahqMDZivbgDCpGf4o0y3zdGYgjhQT9t/Gn9kbSfjvrV5deIfHnje20u4Ef/ABINN1OOLT02qFyImibJJG4kk8k9OlcJpf8AwTF+ClgB59rrepY73OokZ/79qtexgqmFw8lVqtuS6JbHFXjVqLkirI/Lz4A/8l2+HX/Yx6d/6Ux1+rn/AAUc/wCTSfFf/Xey/wDSqKtnwz+wX8D/AAlrWm6vp3g1o9T065ju7a5fVLxiksbBkbaZdpwQDgjHqK9a+I/w18OfFrwjd+GPFenf2rod0yNNa+dJDuKMHX5o2VhhlB4Pat8VmFKviKVWKdo7/f6mdLDzp05Qb3P59oZXglSWN2jkRgyspwQR0INftB+xt+1nov7QXgWxsL++htvHenwLFqFhIwVrjaMfaIgfvK2MkD7pJB4wTFcf8E6PgJNnZ4Nmg/656teH+cprIk/4JqfB6G8iu9L/AOEh0K6hYPFPp+qsrxsOhVmDEEetdGMxuExsFGV01s7L/Mzo0K1CV1Zo+rKK5T4aeAj8N/DCaKfEWu+KFSRnW+8RXYubrBx8hkCrlRjjIzz1rq6+akknZO56i21Cq+o6da6vYXFlfW0V5Z3EbRTW86B45EYYZWU8EEHBBqxRUjPy9/a+/wCCdOpeEbi98XfC2zm1TQWJlufD8QMlzZ+phHJkj/2fvL/tDJHjX7LH7ZPir9mTV20y4im1rwfLKfteiTuVaB8/NJCT9x/Vejd8HDD9p68k+Kn7KXwr+Ms8l14m8IWU+pOctqNputrlj6tJGVL/APAsivoKOZxlT9ji48y79f68zzp4VqXPRdmYukeNfgx+2t4Ck0sz2HiO0kQSy6Xdnyr6yfH3tuQ6MMkb0ODyASK+N/jP/wAEq/EmkXc998Ndag17T2Ysml6o4guox2USfck+p2fQ17w3/BLb4UwajHe6fr3jDSpY33p9k1CEbD/ssYSw+ua+jPhZ8JrP4U6ZNZ2uv+JPEBl2gz+ItXlvnULnAQMdqdedqjPGegrGOKjhHfC1G12aLdJ1tKsde6Pym8FfBT9qr4PagbfwvovizRCzktFp9wHtnb1YBjG31Oa+xfgB8GP2hvF/iLR/EHxo8d3+n6Ppc8d3B4dsp4klu5EIZPtBgATywcEqSxbGCB1r7NoqK2ZTrL4Ip97alQwsYP4nYKKK4n4t/C+P4t+F00KbxJ4g8MW/niaW48OXgtZ5lCspiZyrfId2SBjJUc+vlRSbSk7I63dLQ8H/AG2P2ydD+Cvg7U/DXh7Uob/x9fwtbxw2zh/7NDDBllI+6wByqnknBIxX49kkkk9TX7A2X/BMr4LwSGS7g13VZGO5nu9TOWPckoq1u2//AATp+AcH3/Bktx/101a8H/oMor6bCY7B4KHLG7b3dl/meXWw9avK7sjqf2M/+TWfh1/2Cl/9CavxN8Xf8jXrP/X7N/6Ga/oC8GeDNH+H3hXTvDmgWf2DRtOi8i2tvMeTy0643OSx69ya8L1b/gnp8CNXuJrh/B0sM8ztI8kWq3eSxOScGUjqfSubBY+lh6tSc07Sen3vzNa+HnVhGMeh8pf8E5v2vdJ+H9u/wz8aX6afpNxcGfSNSuG2xQSOfnhkY8KrH5gxwAxbJ5GP05ilSeNZI3WSNgGVlOQQehBr5Ovv+CYvwUu8+Vba3ZZ/54aiTj/vtWr1H4G/sy6V8AryY6F4u8W6npT2xt00XWdRWeygJZW8yOMRrtcbSMg4wx46Y58bPC15OrSbTfRo0oRq00oT1R7HRRRXkHYFFFFACE4HNfnL/wAFG/2vtI1rQpvhX4M1CPUTLKra5qFq4aJQjZFsrD7zbgpYjgbQvJLAfb/xl+ENl8a/Ci+HtS13XdE08zCWf+wrwWz3K7WHlSEq26M7sleMlR6V4rpn/BNT4G2KAT6JqWot/eudUmBP/fBWvTwU8NRmqta7a2SRy141ZrkgfjpH99fqK/cv9oz/AJNN8df9ivP/AOiDXLp/wTx+ACAf8UGWI7nV77/4/XuniPwdpHi3wlf+GdVtPtWiX1q1lcWvmOm+Fl2ldykMOOMgg+9dmOzCliZ05QT919beXmYUMPOkpKT3P55ulfZPw9/4KhfEbwV4W0vQ73QtD12PT7dLaO7nWWOeREUKpch8FsAcgDP15r7d/wCHeX7P/wD0IX/lXv8A/wCP0f8ADvL9n/8A6EL/AMq9/wD/AB+u+tmeCxCSqwbt5L/Mwhha9N3jJL+vQ+Sv+HtnjT/oSND/AO/83+NH/D2zxp/0JGh/9/5v8a+tf+HeX7P/AP0IX/lXv/8A4/R/w7y/Z/8A+hC/8q9//wDH65PrOWf8+n/X/bxr7LFfzr+vkfId1/wVp8eupFv4N8PRNjgytO4/IOK868af8FJvjZ4tgeG11bTvDUTghho9iqtj2eUyMPqCDX6A/wDDvL9n/wD6EL/yr3//AMfqGf8A4J1fAOb7ngqWH/c1a8P85TVxxmWwd1Sf3J/qJ0cU95/19x+OfiPxRrHjDVZdT13VbzWdRl/1l3fztNK31ZiTX6df8EqfhWPD/wALdd8c3MWLrxBd/ZrZiP8Al2gyCQfeRpAf+uYrs9Y/4JjfBPUgRb2mtaVnvaakWx/38V6+iPhd8ONJ+EfgDRfCGhmZtL0qHyYWuWDSvlixZyoALEkk4A5PSjH5lSr0PZUbq/5Bh8NOnU55nVUUUV8yeoFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSHoaWkPQ0AfFx6mig9TRUFn0t8DP+SVaB/1zk/8ARj13lcH8DP8AklWgf9c5P/Rj13lWQFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUh6GlpD0NAHxcepooPU0VBZ9LfAz/klWgf8AXOT/ANGPXeVwfwM/5JVoH/XOT/0Y9d5VkBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFIehpaQ9DQB8XHqaKD1NFQWfS3wM/wCSVaB/1zk/9GPXeVwfwM/5JVoH/XOT/wBGPXeVZAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABSHoaWkPQ0AfFx6mig9TRUFn0t8DP+SVaB/1zk/9GPXeVwfwM/5JVoH/AFzk/wDRj13lWQFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUh6GlpD0NAHxcepooPU0VBZ9LfAz/klWgf9c5P/AEY9d5XzN4M/aBTwB4ctvD1xobXU2ntJC00d1hX/AHjHIBT3rb/4axtv+hcl/wDAsf8AxFVcmzPfqK8B/wCGsbb/AKFyX/wLH/xFH/DWNt/0Lkv/AIFj/wCIouFme/UV4D/w1jbf9C5L/wCBY/8AiKP+Gsbb/oXJf/Asf/EUXCzPfqK8B/4axtv+hcl/8Cx/8RR/w1jbf9C5L/4Fj/4ii4WZ79RXgP8Aw1jbf9C5L/4Fj/4ij/hrG2/6FyX/AMCx/wDEUXCzPfqK8B/4axtv+hcl/wDAsf8AxFH/AA1jbf8AQuS/+BY/+IouFme/UV4D/wANY23/AELkv/gWP/iKP+Gsbb/oXJf/AALH/wARRcLM9+orwH/hrG2/6FyX/wACx/8AEUf8NY23/QuS/wDgWP8A4ii4WZ79RXgP/DWNt/0Lkv8A4Fj/AOIo/wCGsbb/AKFyX/wLH/xFFwsz36ivAf8AhrG2/wChcl/8Cx/8RR/w1jbf9C5L/wCBY/8AiKLhZnv1FeA/8NY23/QuS/8AgWP/AIij/hrG2/6FyX/wLH/xFFwsz36ivAf+Gsbb/oXJf/Asf/EUf8NY23/QuS/+BY/+IouFme/UV4D/AMNY23/QuS/+BY/+Io/4axtv+hcl/wDAsf8AxFFwsz36ivAf+Gsbb/oXJf8AwLH/AMRR/wANY23/AELkv/gWP/iKLhZnv1FeA/8ADWNt/wBC5L/4Fj/4ij/hrG2/6FyX/wACx/8AEUXCzPfqK8B/4axtv+hcl/8AAsf/ABFH/DWNt/0Lkv8A4Fj/AOIouFme/UV4D/w1jbf9C5L/AOBY/wDiKP8AhrG2/wChcl/8Cx/8RRcLM9+orwH/AIaxtv8AoXJf/Asf/EUf8NY23/QuS/8AgWP/AIii4WZ79RXgP/DWNt/0Lkv/AIFj/wCIo/4axtv+hcl/8Cx/8RRcLM9+orwH/hrG2/6FyX/wLH/xFH/DWNt/0Lkv/gWP/iKLhZnv1FeA/wDDWNt/0Lkv/gWP/iKP+Gsbb/oXJf8AwLH/AMRRcLM9+orwH/hrG2/6FyX/AMCx/wDEUf8ADWNt/wBC5L/4Fj/4ii4WZ79RXgP/AA1jbf8AQuS/+BY/+Io/4axtv+hcl/8AAsf/ABFFwsz36ivAf+Gsbb/oXJf/AALH/wARR/w1jbf9C5L/AOBY/wDiKLhZnv1FeA/8NY23/QuS/wDgWP8A4ij/AIaxtv8AoXJf/Asf/EUXCzPfqK8B/wCGsbb/AKFyX/wLH/xFH/DWNt/0Lkv/AIFj/wCIouFme/UV4D/w1jbf9C5L/wCBY/8AiKP+Gsbb/oXJf/Asf/EUXCzPfqK8B/4axtv+hcl/8Cx/8RR/w1jbf9C5L/4Fj/4ii4WZ79RXgP8Aw1jbf9C5L/4Fj/4ij/hrG2/6FyX/AMCx/wDEUXCzPfqK8B/4axtv+hcl/wDAsf8AxFH/AA1jbf8AQuS/+BY/+IouFme/UV4D/wANY23/AELkv/gWP/iKP+Gsbb/oXJf/AALH/wARRcLM9+orwH/hrG2/6FyX/wACx/8AEUf8NY23/QuS/wDgWP8A4ii4WZ79RXgP/DWNt/0Lkv8A4Fj/AOIo/wCGsbb/AKFyX/wLH/xFFwsz36ivAf8AhrG2/wChcl/8Cx/8RR/w1jbf9C5L/wCBY/8AiKLhZnv1FeA/8NY23/QuS/8AgWP/AIij/hrG2/6FyX/wLH/xFFwsz36ivAf+Gsbb/oXJf/Asf/EUf8NY23/QuS/+BY/+IouFme/Uh6GvAv8AhrG2/wChcl/8Cx/8RSH9rG2IP/FOS/8AgWP/AIii4WZ5YepormT4suiT/oEP/gSf/iKKkqx//9k=",
                            width:100,
                                    
                        } );
                        
                    },
                    orientation: "landscape",
                    pageSize: "LEGAL"
        },"excel"],
    });
    });
    </script>';
        $html .= $js;
        // dd($request->pdf);
        $return_data['html'] = $html;
        echo json_encode($return_data);
    }
    public function adminLogout()
    {
        Auth::logout();
        Session::flush();
        return redirect()->route('login');
    }
    // public function session_date(Request $request)
    // {
    //     dd($request);
    //     $date = Session::put('default_login_date', $request->date);
    //     return Response::json($date);
    // }
    function refrence_blno_id_from_bl_no_select2_source(Request $request)
    {
        $select2_data = array();
        $search = isset($request->q) ? trim($request->q) : '';
        $page = isset($request->page) ? trim($request->page) : 1;
        $clerance_id = (isset($request->clerance_id) && !empty($request->clerance_id)) ? trim($request->clerance_id) : '';
        if ($clerance_id == 'null') {
            $clerance_id = '';
        }
        $resultCount = 10;
        $offset = ($page - 1) * $resultCount;
        $query = BatchNumber::select('*');
        if (!empty($clerance_id)) {
            $query->where('id', $clerance_id)->where('batch_name', 'LIKE', "%$search%");
        } else {
            $query->where('batch_name', 'LIKE', "%$search%");
        }
        $get_data = $query->skip($offset)->take($resultCount)->get();
        if (!empty($get_data)) {
            foreach ($get_data as $row) {
                $text = $row->batch_name;
                $select2_data[] = array(
                    'id' => $row->batch_name,
                    'text' => $text,
                    'attr1' => $row->part_name,
                    'attr2' => $row->customer_name,
                    'attr3' => $row->part_type_category,
                    'attr4' => $row->batch_qty,
                );
            }
        }
        $results = array(
            "results" => $select2_data,
            "total_count" => count($get_data),
        );
        echo json_encode($results);
        exit();
    }
    function refrence_Part_n_select2_source(Request $request)
    {
        $select2_data = array();
        $search = isset($request->q) ? trim($request->q) : '';
        $page = isset($request->page) ? trim($request->page) : 1;
        $clerance_id = (isset($request->clerance_id) && !empty($request->clerance_id)) ? trim($request->clerance_id) : '';
        if ($clerance_id == 'null') {
            $clerance_id = '';
        }
        $resultCount = 10;
        $offset = ($page - 1) * $resultCount;
        $query = BatchNumber::select('*');
        if (!empty($clerance_id)) {
            $query->where('id', $clerance_id)->where('part_name', 'LIKE', "%$search%");
        } else {
            $query->where('part_name', 'LIKE', "%$search%");
        }
        $get_data = $query->skip($offset)->take($resultCount)->get();
        if (!empty($get_data)) {
            foreach ($get_data as $row) {
                $text = $row->part_name;
                $select2_data[] = array(
                    'id' => $row->part_name,
                    'text' => $text,
                    'attr1' => $row->batch_name,
                    'attr2' => $row->customer_name,
                    'attr3' => $row->part_type_category,
                    'attr4' => $row->batch_qty,
                );
            }
        }
        $results = array(
            "results" => $select2_data,
            "total_count" => count($get_data),
        );
        echo json_encode($results);
        exit();
    }
    function refrence_customer_n_select2_source(Request $request)
    {
        $select2_data = array();
        $search = isset($request->q) ? trim($request->q) : '';
        $page = isset($request->page) ? trim($request->page) : 1;
        $clerance_id = (isset($request->clerance_id) && !empty($request->clerance_id)) ? trim($request->clerance_id) : '';
        if ($clerance_id == 'null') {
            $clerance_id = '';
        }
        $resultCount = 10;
        $offset = ($page - 1) * $resultCount;
        $query = BatchNumber::select('*');
        if (!empty($clerance_id)) {
            $query->where('id', $clerance_id)->where('customer_name', 'LIKE', "%$search%");
        } else {
            $query->where('customer_name', 'LIKE', "%$search%");
        }
        $get_data = $query->skip($offset)->take($resultCount)->get();
        if (!empty($get_data)) {
            foreach ($get_data as $row) {
                $text = $row->customer_name;
                $select2_data[] = array(
                    'id' => $row->customer_name,
                    'text' => $text,
                    'attr1' => $row->part_name,
                    'attr2' => $row->batch_name,
                    'attr3' => $row->part_type_category,
                    'attr4' => $row->batch_qty,
                );
            }
        }
        $results = array(
            "results" => $select2_data,
            "total_count" => count($get_data),
        );
        echo json_encode($results);
        exit();
    }
}
